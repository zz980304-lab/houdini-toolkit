# -*- coding: utf-8 -*-
# 由节点预设库自动生成：2026-10-29 15:32:59
import hou

# 放预设时外部会塞 hou_parent（目标网络）；没有就用原来的位置
if locals().get("hou_parent") is None:
    hou_parent = hou.node('/obj/geo3/popnet') or hou.pwd()
parent = hou_parent

# Initialize parent node variable.
if locals().get("hou_parent") is None:
    hou_parent = hou.node("/obj/geo3/popnet")

# Code for /obj/geo3/popnet/del_high
hou_node = hou_parent.createNode("popwrangle", "del_high", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(1.12775, 4.04153))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setSelected(True)

hou_parm_template_group = hou.ParmTemplateGroup()
# Code for parameter template
hou_parm_template = hou.FloatParmTemplate("activate", "Activation", 1, default_value=([1]), min=0, max=1, min_is_strict=False, max_is_strict=False, look=hou.parmLook.Regular, naming_scheme=hou.parmNamingScheme.Base1)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.ToggleParmTemplate("usegroup", "Label", default_value=False)
hou_parm_template.hideLabel(True)
hou_parm_template.setJoinWithNext(True)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.StringParmTemplate("partgroup", "Group", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="import doppoptoolutils\n\nreturn doppoptoolutils.buildGroupMenu(hou.pwd())", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.StringToggle)
hou_parm_template.setConditional(hou.parmCondType.DisableWhen, "{ usegroup == 0 }")
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FolderParmTemplate("folder2", "Code", folder_type=hou.folderType.Tabs, default_value=0, ends_tab_group=False)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("snippet", "VEXpression", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="import vexpressionmenu\n\nreturn vexpressionmenu.buildSnippetMenu('popwrangle/snippet')", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.StringReplace)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "editor": "1", "editorlang": "vex", "editorlines": "8-40", "script_action": "import vexpressionmenu\n\nnode = kwargs['node']\nparmname = 'snippet'\n\nvexpressionmenu.createSpareParmsFromChCalls(node, parmname)", "script_action_help": "Creates spare parameters for each unique call of ch() ", "script_action_icon": "BUTTONS_create_parm_from_ch"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("exportlist", "Attributes to Create", 1, default_value=(["*"]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("vex_strict", "Enforce Prototypes", default_value=False, default_expression='off', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "script_callback": ""})
hou_parm_template.addParmTemplate(hou_parm_template2)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FolderParmTemplate("folder2_1", "Data Bindings", folder_type=hou.folderType.Tabs, default_value=0, ends_tab_group=False)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("autobind", "Autobind by Name", default_value=True, default_expression='on', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.FolderParmTemplate("bindings", "Attribute Bindings", folder_type=hou.folderType.MultiparmBlock, default_value=0, ends_tab_group=False)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "multistartoffset": "1"})
# Code for parameter template
hou_parm_template3 = hou.StringParmTemplate("binddata#", "Attribute Name", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.addParmTemplate(hou_parm_template3)
# Code for parameter template
hou_parm_template3 = hou.StringParmTemplate("bindparm#", "VEX Parameter", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.addParmTemplate(hou_parm_template3)
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.FolderParmTemplate("bindfield_num", "Field Bindings", folder_type=hou.folderType.MultiparmBlock, default_value=0, ends_tab_group=False)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "multistartoffset": "1"})
# Code for parameter template
hou_parm_template3 = hou.StringParmTemplate("bindfield_data#", "Field Name", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.addParmTemplate(hou_parm_template3)
# Code for parameter template
hou_parm_template3 = hou.StringParmTemplate("bindfield_parm#", "VEX Parameter", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.addParmTemplate(hou_parm_template3)
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("groupautobind", "Autobind Groups by Name", default_value=True, default_expression='on', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.FolderParmTemplate("groupbindings", "Group Bindings", folder_type=hou.folderType.MultiparmBlock, default_value=0, ends_tab_group=False)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "multistartoffset": "1"})
# Code for parameter template
hou_parm_template3 = hou.StringParmTemplate("bindgroupname#", "Group Name", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.addParmTemplate(hou_parm_template3)
# Code for parameter template
hou_parm_template3 = hou.StringParmTemplate("bindgroupparm#", "VEX Parameter", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.addParmTemplate(hou_parm_template3)
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("vex_updatenmls", "Update Normals If Displaced", default_value=False, default_expression='off', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "script_callback": ""})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("vex_precision", "VEX Precision", 1, default_value=(["auto"]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=(["auto","32","64"]), menu_labels=(["Auto","32-bit","64-bit"]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FolderParmTemplate("folder2_2", "Inputs", folder_type=hou.folderType.Tabs, default_value=0, ends_tab_group=False)
# Code for parameter template
hou_parm_template2 = hou.MenuParmTemplate("bindinputmenu1", "Input 1", menu_items=(["none","sop","dopdata","self","first","second","third","fourth","selfraw"]), menu_labels=(["None","SOP","DOP Data","Myself","First Context Geometry","Second Context Geometry","Third Context Geometry","Fourth Context Geometry","Myself (No Reads of Outputs)"]), default_value=0, icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal, menu_use_token=False, is_button_strip=False, strip_uses_icons=False)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("bindgeoinput1", "SOP Path", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.NodeReference, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu1 != sop }")
hou_parm_template2.setTags({"autoscope": "0000000000000000", "opfilter": "!!SOP!!", "oprelative": "."})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("binddopinput1", "DOP Data", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu1 != dopdata }")
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("binddopuseself1", "Use This Object's Data", default_value=False, default_expression='off', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu1 != dopdata }")
hou_parm_template2.setScriptCallbackLanguage(hou.scriptLanguage.Python)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "script_callback_language": "python"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.MenuParmTemplate("bindinputmenu2", "Input 2", menu_items=(["none","sop","dopdata","self","first","second","third","fourth","selfraw"]), menu_labels=(["None","SOP","DOP Data","Myself","First Context Geometry","Second Context Geometry","Third Context Geometry","Fourth Context Geometry","Myself (No Reads of Outputs)"]), default_value=0, icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal, menu_use_token=False, is_button_strip=False, strip_uses_icons=False)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("bindgeoinput2", "SOP Path", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.NodeReference, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu2 != sop }")
hou_parm_template2.setTags({"autoscope": "0000000000000000", "opfilter": "!!SOP!!", "oprelative": "."})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("binddopinput2", "DOP Data", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu2 != dopdata }")
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("binddopuseself2", "Use This Object's Data", default_value=False, default_expression='off', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu2 != dopdata }")
hou_parm_template2.setScriptCallbackLanguage(hou.scriptLanguage.Python)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "script_callback_language": "python"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.MenuParmTemplate("bindinputmenu3", "Input 3", menu_items=(["none","sop","dopdata","self","first","second","third","fourth","selfraw"]), menu_labels=(["None","SOP","DOP Data","Myself","First Context Geometry","Second Context Geometry","Third Context Geometry","Fourth Context Geometry","Myself (No Reads of Outputs)"]), default_value=0, icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal, menu_use_token=False, is_button_strip=False, strip_uses_icons=False)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("bindgeoinput3", "SOP Path", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.NodeReference, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu3 != sop }")
hou_parm_template2.setTags({"autoscope": "0000000000000000", "opfilter": "!!SOP!!", "oprelative": "."})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("binddopinput3", "DOP Data", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu3 != dopdata }")
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("binddopuseself3", "Use This Object's Data", default_value=False, default_expression='off', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu3 != dopdata }")
hou_parm_template2.setScriptCallbackLanguage(hou.scriptLanguage.Python)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "script_callback_language": "python"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.MenuParmTemplate("bindinputmenu4", "Input 4", menu_items=(["none","sop","dopdata","self","first","second","third","fourth","selfraw"]), menu_labels=(["None","SOP","DOP Data","Myself","First Context Geometry","Second Context Geometry","Third Context Geometry","Fourth Context Geometry","Myself (No Reads of Outputs)"]), default_value=0, icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal, menu_use_token=False, is_button_strip=False, strip_uses_icons=False)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("bindgeoinput4", "SOP Path", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.NodeReference, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu4 != sop }")
hou_parm_template2.setTags({"autoscope": "0000000000000000", "opfilter": "!!SOP!!", "oprelative": "."})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("binddopinput4", "DOP Data", 1, default_value=([""]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu4 != dopdata }")
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.ToggleParmTemplate("binddopuseself4", "Use This Object's Data", default_value=False, default_expression='off', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ bindinputmenu4 != dopdata }")
hou_parm_template2.setScriptCallbackLanguage(hou.scriptLanguage.Python)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "script_callback_language": "python"})
hou_parm_template.addParmTemplate(hou_parm_template2)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FolderParmTemplate("folder2_3", "Bindings", folder_type=hou.folderType.Tabs, default_value=0, ends_tab_group=False)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("bindgeo", "Geometry", 1, default_value=(["Geometry"]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("vex_cwdpath", "Evaluation Node Path", 1, default_value=(["."]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.NodeReference, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setTags({"autoscope": "0000000000000000", "oprelative": "."})
hou_parm_template.addParmTemplate(hou_parm_template2)
# Code for parameter template
hou_parm_template2 = hou.StringParmTemplate("vex_outputmask", "Export Parameters", 1, default_value=(["*"]), naming_scheme=hou.parmNamingScheme.Base1, string_type=hou.stringParmType.Regular, menu_items=([]), menu_labels=([]), icon_names=([]), item_generator_script="", item_generator_script_language=hou.scriptLanguage.Python, menu_type=hou.menuType.Normal)
hou_parm_template2.setTags({"autoscope": "0000000000000000"})
hou_parm_template.addParmTemplate(hou_parm_template2)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.ToggleParmTemplate("usetimestep", "Use Timestep", default_value=True, default_expression='on', default_expression_language=hou.scriptLanguage.Hscript)
hou_parm_template.setTags({"autoscope": "0000000000000000"})
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FloatParmTemplate("timescale", "Time Scale", 1, default_value=([1]), min=0, max=10, min_is_strict=False, max_is_strict=False, look=hou.parmLook.Regular, naming_scheme=hou.parmNamingScheme.Base1)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FloatParmTemplate("threshold", "Threshold 密度阈值", 1, default_value=([80]), min=0, max=10000, min_is_strict=False, max_is_strict=False, look=hou.parmLook.Regular, naming_scheme=hou.parmNamingScheme.Base1)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FloatParmTemplate("range", "Range 渐变宽度", 1, default_value=([300]), min=1, max=10000, min_is_strict=False, max_is_strict=False, look=hou.parmLook.Regular, naming_scheme=hou.parmNamingScheme.Base1)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FloatParmTemplate("maxkill", "Max Kill 概率上限", 1, default_value=([0.35]), min=0, max=1, min_is_strict=False, max_is_strict=False, look=hou.parmLook.Regular, naming_scheme=hou.parmNamingScheme.Base1)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FloatParmTemplate("curve", "Curve 曲线形状", 1, default_value=([1.5]), min=0.05, max=5, min_is_strict=False, max_is_strict=False, look=hou.parmLook.Regular, naming_scheme=hou.parmNamingScheme.Base1)
hou_parm_template_group.append(hou_parm_template)
# Code for parameter template
hou_parm_template = hou.FloatParmTemplate("protect", "Protect 新生保护", 1, default_value=([0.08]), min=0, max=1, min_is_strict=False, max_is_strict=False, look=hou.parmLook.Regular, naming_scheme=hou.parmNamingScheme.Base1)
hou_parm_template_group.append(hou_parm_template)
hou_node.setParmTemplateGroup(hou_parm_template_group)
# Code for /obj/geo3/popnet/del_high/activate parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("activate")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/usegroup parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("usegroup")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/partgroup parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("partgroup")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/folder11 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("folder11")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/snippet parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("snippet")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("// del_high —— 自适应削顶：密度越高的地方，粒子被抽走的概率越大（软上限，不是清空）\n//\n// threshold : 低于这个密度完全不删\n// range     : 从 threshold 到 threshold+range，删除概率 0 → maxkill\n// maxkill   : 概率天花板（<1，所以高密度区依然很密，只是不再失控）\n// curve     : >1 只削塔尖，<1 一过线就狠，1 = 线性\n// protect   : 生命前 protect 比例内免疫（0 = 不保护）\n\nfloat thr     = chf(\"threshold\");\nfloat range   = chf(\"range\");\nfloat maxkill = chf(\"maxkill\");\nfloat curve   = chf(\"curve\");\nfloat protect = chf(\"protect\");\n\nfloat d = @ptdensity;\nif (d <= thr) return;                                   // 阈值以下一个都不动\n\nfloat over = clamp((d - thr) / max(range, 1e-6), 0, 1); // 超出程度 0~1\nfloat p    = pow(over, max(curve, 0.01)) * maxkill;     // 删除概率\n\nif (protect > 0) p *= clamp(@nage / protect, 0, 1);     // 越年轻越不容易被删\n\n// 每帧换种子：只写 rand(@id) 的话，同一批粒子会\"注定先死\"\nif (rand(@id * 13.7 + @Time * 37.0 + 0.311) < p) @dead = 1;\n")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/exportlist parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("exportlist")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("*")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/vex_strict parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("vex_strict")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/autobind parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("autobind")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindings parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindings")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindfield_num parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindfield_num")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/groupautobind parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("groupautobind")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/groupbindings parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("groupbindings")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/vex_updatenmls parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("vex_updatenmls")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/vex_precision parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("vex_precision")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("auto")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindinputmenu1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindinputmenu1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindgeoinput1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindgeoinput1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopinput1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopinput1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopuseself1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopuseself1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindinputmenu2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindinputmenu2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindgeoinput2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindgeoinput2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopinput2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopinput2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopuseself2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopuseself2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindinputmenu3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindinputmenu3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindgeoinput3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindgeoinput3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopinput3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopinput3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopuseself3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopuseself3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindinputmenu4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindinputmenu4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindgeoinput4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindgeoinput4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopinput4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopinput4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/binddopuseself4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("binddopuseself4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/bindgeo parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("bindgeo")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("Geometry")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/vex_cwdpath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("vex_cwdpath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(".")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/vex_outputmask parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("vex_outputmask")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("*")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/usetimestep parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("usetimestep")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/timescale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("timescale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/folder21 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("folder21")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/threshold parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("threshold")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(100)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/range parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("range")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(200)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/maxkill parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("maxkill")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/curve parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("curve")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/del_high/protect parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/del_high")
hou_parm = hou_node.parm("protect")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.080000000000000002)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

# Code to establish connections for /obj/geo3/popnet/del_high
hou_node = hou_parent.node("del_high")
if hou_parent.node("Collision") is not None:
    hou_node.setInput(0, hou_parent.node("Collision"), 0)
hou_node.setUserData("___Version___", "")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("")
