# -*- coding: utf-8 -*-
# 由节点预设库自动生成：2026-11-17 18:48:47
import hou

# 放预设时外部会塞 hou_parent（目标网络）；没有就用原来的位置
if locals().get("hou_parent") is None:
    hou_parent = hou.node('/obj/geo1/dopnet1') or hou.pwd()
parent = hou_parent

# Initialize parent node variable.
if locals().get("hou_parent") is None:
    hou_parent = hou.node("/obj/geo1/dopnet1")

# Code for /obj/geo1/dopnet1/vdb_smooth_vel
hou_node = hou_parent.createNode("sopsolver::2.0", "vdb_smooth_vel", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(-1.71765, 2.16471))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setSelected(True)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_usesoppath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_usesoppath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/usesoppath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("usesoppath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_soppath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_soppath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/soppath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("soppath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_datapath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_datapath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/datapath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("datapath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("Geometry")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_doinvoke parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_doinvoke")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/doinvoke parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("doinvoke")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_primaryinputname parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_primaryinputname")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/primaryinputname parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("primaryinputname")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("data")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_numinputs parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_numinputs")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/numinputs parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("numinputs")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_numoutputs parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_numoutputs")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/numoutputs parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("numoutputs")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_transformsopoutput parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_transformsopoutput")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/transformsopoutput parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("transformsopoutput")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_solveinitframe parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_solveinitframe")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/solveinitframe parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("solveinitframe")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_numstamps parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_numstamps")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/numstamps parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("numstamps")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_usetimestep parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_usetimestep")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/usetimestep parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("usetimestep")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/parmop_timescale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("parmop_timescale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("default")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/timescale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("timescale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/defaultparmop parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("defaultparmop")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("initial")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/addaffectors parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("addaffectors")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/group parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("group")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("*")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dataname parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("dataname")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("$OS")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/uniquedataname parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("uniquedataname")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/solverperobject parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel")
hou_parm = hou_node.parm("solverperobject")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry
hou_node = hou_parent.createNode("dopimport::2.0", "dop_geometry", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(0, 0.8942))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/doppath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("doppath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("`stamps(\"..\", \"DOPNET\", \"../..\")`")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/objpattern parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("objpattern")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("`stamps(\"..\", \"OBJID\", arg(dopnodeobjs(\"..\"),0))`")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/relpattern parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("relpattern")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/donotsim parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("donotsim")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/folder_geometry parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("folder_geometry")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/importstyle parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("importstyle")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("fetch")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/pointsquicksetup parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("pointsquicksetup")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("menu")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/geodatapath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("geodatapath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("`stamps(\"..\", \"DATANAME\", chs(\"../datapath\"))`")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/pack parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("pack")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/pivot parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("pivot")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("centroid")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/viewportlod parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("viewportlod")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("full")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/adddopobjectpath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("adddopobjectpath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/adddopobjectname parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("adddopobjectname")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/dopobjectnameattrib parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("dopobjectnameattrib")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("dopobjectname")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/adddopdatapath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("adddopdatapath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/dopdatapathattrib parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("dopdatapathattrib")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("dopdatapath")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/transferattributes parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("transferattributes")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/transfergroups parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("transfergroups")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/folder_xform parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("folder_xform")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/doposxform parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("doposxform")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)

# Code for first keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for last keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/dogeoxform parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("dogeoxform")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)

# Code for first keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for last keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../transformsopoutput\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/keepworldspacepos parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("keepworldspacepos")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/pointvels parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("pointvels")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/integrateovertime parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("integrateovertime")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.041666666666666664)
hou_parm.setAutoscope(False)

# Code for first keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.setExpression("1/$FPS", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for last keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.setExpression("1/$FPS", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.setExpression("1/$FPS", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.setExpression("1/$FPS", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry/addtoexistingvel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/dop_geometry")
hou_parm = hou_node.parm("addtoexistingvel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


hou_node.setColor(hou.Color([0.6, 0.4, 1]))
hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/OUT
hou_node = hou_parent.createNode("output", "OUT", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(0, -11))
hou_node.bypass(False)
hou_node.setDisplayFlag(True)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(True)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/OUT/outputidx parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/OUT")
hou_parm = hou_node.parm("outputidx")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1
hou_node = hou_parent.createNode("compile_begin", "compile_begin1", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(0, 0.0945))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1/blockpath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1")
hou_parm = hou_node.parm("blockpath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("../compile_end1")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1/name parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1")
hou_parm = hou_node.parm("name")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("data")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1/optional parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1")
hou_parm = hou_node.parm("optional")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1/createbeginblock parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1")
hou_parm = hou_node.parm("createbeginblock")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("0")
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1
hou_node = hou_parent.createNode("compile_end", "compile_end1", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(0, -10))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1/docompile parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_end1")
hou_parm = hou_node.parm("docompile")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1/unload parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_end1")
hou_parm = hou_node.parm("unload")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("always")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1/primarypath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_end1")
hou_parm = hou_node.parm("primarypath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1/forcerecompile parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_end1")
hou_parm = hou_node.parm("forcerecompile")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("0")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1/delayillegal parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_end1")
hou_parm = hou_node.parm("delayillegal")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1/fallback parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/compile_end1")
hou_parm = hou_node.parm("fallback")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1
hou_node = hou_parent.createNode("vdb", "vdb1", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(4.6, -1.31))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/ngrids parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("ngrids")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/source1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("source1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/voxelsize parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("voxelsize")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.01)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/size parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm_tuple = hou_node.parmTuple("size")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((1, 1, 1))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/center parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm_tuple = hou_node.parmTuple("center")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 0, 0))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/taper parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("taper")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/camera parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("camera")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/zmin parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("zmin")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/zmax parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("zmax")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(2)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/usecamwindow parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("usecamwindow")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/winx parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm_tuple = hou_node.parmTuple("winx")
hou_parm_tuple.lock((False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 1))
hou_parm_tuple.setAutoscope((False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/winy parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm_tuple = hou_node.parmTuple("winy")
hou_parm_tuple.lock((False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 1))
hou_parm_tuple.setAutoscope((False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/uniformsamples parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("uniformsamples")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("maxaxis")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/samplediv parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("samplediv")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("10")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/divs parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm_tuple = hou_node.parmTuple("divs")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((10, 10, 10))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/divsize parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("divsize")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.10000000000000001)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/zscale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("zscale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/stdswitcher11 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("stdswitcher11")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/enable1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("enable1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/name1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("name1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("density")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/class1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("class1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("fog volume")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/type1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("type1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("float")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/precision1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("precision1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("single")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/vectype1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("vectype1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("invariant")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/bgfloat1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("bgfloat1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/bgint1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("bgint1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/bgbool1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("bgbool1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/bgvec3s1 parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm_tuple = hou_node.parmTuple("bgvec3s1")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 0, 0))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/bgvec3i1 parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm_tuple = hou_node.parmTuple("bgvec3i1")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 0, 0))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/vdbvis1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("vdbvis1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("fromtype")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/vdbvisiso1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("vdbvisiso1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb1/vdbvisdensity1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb1")
hou_parm = hou_node.parm("vdbvisdensity1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2
hou_node = hou_parent.createNode("vdb", "vdb2", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(7.16, -1.32))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/ngrids parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("ngrids")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/source1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("source1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/voxelsize parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("voxelsize")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.01)
hou_parm.setAutoscope(False)

# Code for first keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for last keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/size parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm_tuple = hou_node.parmTuple("size")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((1, 1, 1))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/center parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm_tuple = hou_node.parmTuple("center")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 0, 0))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/taper parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("taper")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/camera parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("camera")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/zmin parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("zmin")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/zmax parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("zmax")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(2)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/usecamwindow parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("usecamwindow")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/winx parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm_tuple = hou_node.parmTuple("winx")
hou_parm_tuple.lock((False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 1))
hou_parm_tuple.setAutoscope((False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/winy parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm_tuple = hou_node.parmTuple("winy")
hou_parm_tuple.lock((False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 1))
hou_parm_tuple.setAutoscope((False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/uniformsamples parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("uniformsamples")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("maxaxis")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/samplediv parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("samplediv")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("10")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/divs parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm_tuple = hou_node.parmTuple("divs")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((10, 10, 10))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/divsize parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("divsize")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.10000000000000001)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/zscale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("zscale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/stdswitcher11 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("stdswitcher11")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/enable1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("enable1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/name1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("name1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("v")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/class1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("class1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("fog volume")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/type1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("type1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("vecfloat")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/precision1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("precision1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("single")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/vectype1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("vectype1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("invariant")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/bgfloat1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("bgfloat1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/bgint1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("bgint1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/bgbool1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("bgbool1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/bgvec3s1 parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm_tuple = hou_node.parmTuple("bgvec3s1")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 0, 0))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/bgvec3i1 parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm_tuple = hou_node.parmTuple("bgvec3i1")
hou_parm_tuple.lock((False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 0, 0))
hou_parm_tuple.setAutoscope((False, False, False))


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/vdbvis1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("vdbvis1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("fromtype")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/vdbvisiso1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("vdbvisiso1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/vdb2/vdbvisdensity1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/vdb2")
hou_parm = hou_node.parm("vdbvisdensity1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1
hou_node = hou_parent.createNode("attribdelete", "attribdelete1", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(1.3, -1.28))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/usereference parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("usereference")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/negate parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("negate")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/doptdel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("doptdel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/ptdel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("ptdel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("v")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/dovtxdel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("dovtxdel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/vtxdel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("vtxdel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/doprimdel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("doprimdel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/primdel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("primdel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/dodtldel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("dodtldel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/dtldel parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("dtldel")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1/updatevar parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1")
hou_parm = hou_node.parm("updatevar")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("")
# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1
hou_node = hou_parent.createNode("volumerasterizeparticles", "volumerasterizeparticles1", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(2.19, -3.76))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/group parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("group")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/points parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("points")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/filter parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("filter")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("gauss")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/densityattrib parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("densityattrib")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("density")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/densityscale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("densityscale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/particlescale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("particlescale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.01)
hou_parm.setAutoscope(False)

# Code for first keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for last keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/minfilter parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("minfilter")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.75)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/velocityblur parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("velocityblur")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/shutter parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("shutter")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.5)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/shutteroffset parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("shutteroffset")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/blursamples parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("blursamples")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(4)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/normalize parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("normalize")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1/attribrules parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1")
hou_parm = hou_node.parm("attribrules")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2
hou_node = hou_parent.createNode("volumerasterizeparticles", "volumerasterizeparticles2", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(6.019, -3.76))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/group parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("group")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/points parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("points")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/filter parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("filter")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("gauss")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/densityattrib parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("densityattrib")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("density")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/densityscale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("densityscale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/particlescale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("particlescale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.01)
hou_parm.setAutoscope(False)

# Code for first keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for last keyframe.
# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)

# Code for keyframe.
hou_keyframe = hou.Keyframe()
hou_keyframe.setTime(0)
hou_keyframe.setValue(0)
hou_keyframe.setInValue(0)
hou_keyframe.useValue(False)
hou_keyframe.setSlope(0)
hou_keyframe.setInSlope(0)
hou_keyframe.useSlope(False)
hou_keyframe.setAccel(0)
hou_keyframe.useAccel(False)
hou_keyframe.interpretAccelAsRatio(False)
hou_keyframe.setExpression("ch(\"../vdb1/voxelsize\")", hou.exprLanguage.Hscript)
hou_parm.setKeyframe(hou_keyframe)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/minfilter parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("minfilter")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.75)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/velocityblur parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("velocityblur")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/shutter parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("shutter")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0.5)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/shutteroffset parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("shutteroffset")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/blursamples parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("blursamples")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(4)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/normalize parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("normalize")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2/attribrules parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2")
hou_parm = hou_node.parm("attribrules")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "20.5.410")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel
hou_node = hou_parent.createNode("attribwrangle", "blend_vel", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(0.132, -6.879))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setHighlightFlag(False)
hou_node.setHardLocked(False)
hou_node.setSoftLocked(False)
hou_node.setSelectableTemplateFlag(False)
hou_node.setSelected(False)
hou_node.setRenderFlag(False)
hou_node.setTemplateFlag(False)
hou_node.setUnloadFlag(False)

# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/folder01 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("folder01")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/group parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("group")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/grouptype parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("grouptype")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("guess")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/class parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("class")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("point")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_numcount parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_numcount")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(10)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_threadjobsize parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_threadjobsize")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1024)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/snippet parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("snippet")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("@ptdensity = volumesample(1,0,@P);\n\nfloat ratio = fit(@nage,0.5,1,0.5,0.1);\n\n@v = lerp(@v,volumesamplev(2,0,@P),ratio);\n")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/exportlist parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("exportlist")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("*")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_strict parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_strict")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/autobind parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("autobind")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/bindings parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("bindings")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/groupautobind parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("groupautobind")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/groupbindings parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("groupbindings")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_cwdpath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_cwdpath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(".")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_outputmask parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_outputmask")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("*")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_updatenmls parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_updatenmls")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_matchattrib parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_matchattrib")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("id")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_inplace parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_inplace")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_selectiongroup parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_selectiongroup")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel/vex_precision parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo1/dopnet1/vdb_smooth_vel/blend_vel")
hou_parm = hou_node.parm("vex_precision")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("auto")
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___toolcount___", "2")
hou_node.setUserData("___Version___", "")
hou_node.setUserData("___toolid___", "Smooth_vdb")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("")
# Code to establish connections for /obj/geo1/dopnet1/vdb_smooth_vel/OUT
hou_node = hou_parent.node("OUT")
if hou_parent.node("compile_end1") is not None:
    hou_node.setInput(0, hou_parent.node("compile_end1"), 0)
# Code to establish connections for /obj/geo1/dopnet1/vdb_smooth_vel/compile_begin1
hou_node = hou_parent.node("compile_begin1")
if hou_parent.node("dop_geometry") is not None:
    hou_node.setInput(0, hou_parent.node("dop_geometry"), 0)
# Code to establish connections for /obj/geo1/dopnet1/vdb_smooth_vel/compile_end1
hou_node = hou_parent.node("compile_end1")
if hou_parent.node("blend_vel") is not None:
    hou_node.setInput(0, hou_parent.node("blend_vel"), 0)
# Code to establish connections for /obj/geo1/dopnet1/vdb_smooth_vel/attribdelete1
hou_node = hou_parent.node("attribdelete1")
if hou_parent.node("compile_begin1") is not None:
    hou_node.setInput(0, hou_parent.node("compile_begin1"), 0)
# Code to establish connections for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles1
hou_node = hou_parent.node("volumerasterizeparticles1")
if hou_parent.node("vdb1") is not None:
    hou_node.setInput(0, hou_parent.node("vdb1"), 0)
if hou_parent.node("attribdelete1") is not None:
    hou_node.setInput(1, hou_parent.node("attribdelete1"), 0)
# Code to establish connections for /obj/geo1/dopnet1/vdb_smooth_vel/volumerasterizeparticles2
hou_node = hou_parent.node("volumerasterizeparticles2")
if hou_parent.node("vdb2") is not None:
    hou_node.setInput(0, hou_parent.node("vdb2"), 0)
if hou_parent.node("attribdelete1") is not None:
    hou_node.setInput(1, hou_parent.node("attribdelete1"), 0)
# Code to establish connections for /obj/geo1/dopnet1/vdb_smooth_vel/blend_vel
hou_node = hou_parent.node("blend_vel")
if hou_parent.node("compile_begin1") is not None:
    hou_node.setInput(0, hou_parent.node("compile_begin1"), 0)
if hou_parent.node("volumerasterizeparticles1") is not None:
    hou_node.setInput(1, hou_parent.node("volumerasterizeparticles1"), 0)
if hou_parent.node("volumerasterizeparticles2") is not None:
    hou_node.setInput(2, hou_parent.node("volumerasterizeparticles2"), 0)

# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()
