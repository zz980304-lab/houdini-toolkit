# -*- coding: utf-8 -*-
# 由节点预设库自动生成：2026-10-19 13:37:11
import hou

# 放预设时外部会塞 hou_parent（目标网络）；没有就用原来的位置
if locals().get("hou_parent") is None:
    hou_parent = hou.node('/obj/geo3/popnet') or hou.pwd()
parent = hou_parent

# Initialize parent node variable.
if locals().get("hou_parent") is None:
    hou_parent = hou.node("/obj/geo3/popnet")

# Code for /obj/geo3/popnet/Collision
hou_node = hou_parent.createNode("popwrangle", "Collision", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(1.12775, 5.71212))
hou_node.bypass(False)
hou_node.setDisplayFlag(False)
hou_node.hide(False)
hou_node.setSelected(True)

# Code for /obj/geo3/popnet/Collision/activate parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("activate")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/usegroup parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("usegroup")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/partgroup parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("partgroup")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/folder11 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("folder11")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/snippet parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("snippet")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("@depth = volumesample(0,'surface',@P);\n\nif (@depth<0)\n{\n    vector grad = normalize(volumegradient(0,'surface',@P));\n    \n    @P -= grad * @depth;\n    \n    vector collisionvel = volumesamplev(0, 'vel', @P)*0.2;\n    \n    vector reflvel = reflect(@v,@grad);\n    reflvel -= grad * dot(grad,reflvel)*0.95;\n    \n    float bias = fit(rand(@id*3),0,1,0.1,0.2);\n    \n    @v = lerp(reflvel, collisionvel, bias);\n}    ")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/exportlist parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("exportlist")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("*")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/vex_strict parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("vex_strict")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/autobind parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("autobind")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindings parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindings")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindfield_num parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindfield_num")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/groupautobind parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("groupautobind")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/groupbindings parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("groupbindings")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/vex_updatenmls parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("vex_updatenmls")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/vex_precision parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("vex_precision")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("auto")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindinputmenu1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindinputmenu1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("sop")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindgeoinput1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindgeoinput1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("/obj/geo3/Collision")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopinput1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopinput1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopuseself1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopuseself1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindinputmenu2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindinputmenu2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindgeoinput2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindgeoinput2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopinput2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopinput2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopuseself2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopuseself2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindinputmenu3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindinputmenu3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindgeoinput3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindgeoinput3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopinput3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopinput3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopuseself3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopuseself3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindinputmenu4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindinputmenu4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("none")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindgeoinput4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindgeoinput4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopinput4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopinput4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/binddopuseself4 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("binddopuseself4")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/bindgeo parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("bindgeo")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("Geometry")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/vex_cwdpath parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("vex_cwdpath")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(".")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/vex_outputmask parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("vex_outputmask")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("*")
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/usetimestep parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("usetimestep")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/geo3/popnet/Collision/timescale parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/geo3/popnet/Collision")
hou_parm = hou_node.parm("timescale")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


hou_node.setColor(hou.Color([1, 0.725, 0]))
hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

# Code to establish connections for /obj/geo3/popnet/Collision
hou_node = hou_parent.node("Collision")
if hou_parent.node("popforce1") is not None:
    hou_node.setInput(0, hou_parent.node("popforce1"), 0)
hou_node.setUserData("___Version___", "")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("")
