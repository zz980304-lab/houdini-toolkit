# -*- coding: utf-8 -*-
# 由节点预设库自动生成：2026-10-19 16:23:32
import hou

# 放预设时外部会塞 hou_parent（目标网络）；没有就用原来的位置
if locals().get("hou_parent") is None:
    hou_parent = hou.node('/obj/Mat') or hou.pwd()
parent = hou_parent

# Initialize parent node variable.
if locals().get("hou_parent") is None:
    hou_parent = hou.node("/obj/Mat")

# Code for /obj/Mat/Cryptomatte
hou_node = hou_parent.createNode("arnold_materialbuilder", "Cryptomatte", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(-9.21413, 2.71822))
hou_node.setDebugFlag(False)
hou_node.setDetailLowFlag(False)
hou_node.setDetailMediumFlag(False)
hou_node.setDetailHighFlag(True)
hou_node.bypass(False)
hou_node.setCompressFlag(True)
hou_node.hide(False)
hou_node.setSelected(True)
hou_node.setColor(hou.Color([0.29, 0.565, 0.886]))
hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___Version___", "20.5.410")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node

# Code for /obj/Mat/Cryptomatte/OUT_aov
hou_node = hou_parent.createNode("arnold_aov", "OUT_aov", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(0.223529, -0.892941))
hou_node.setDebugFlag(False)
hou_node.setDetailLowFlag(False)
hou_node.setDetailMediumFlag(False)
hou_node.setDetailHighFlag(True)
hou_node.bypass(False)
hou_node.setCompressFlag(True)
hou_node.hide(False)
hou_node.setSelected(False)
hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___Version___", "20.5.410")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code for /obj/Mat/Cryptomatte/cryptomatte1
hou_node = hou_parent.createNode("arnold::cryptomatte", "cryptomatte1", run_init_scripts=False, load_contents=True, exact_type_name=True)
hou_node.move(hou.Vector2(-4.57647, 0.518824))
hou_node.setDebugFlag(False)
hou_node.setDetailLowFlag(False)
hou_node.setDetailMediumFlag(False)
hou_node.setDetailHighFlag(True)
hou_node.bypass(False)
hou_node.setCompressFlag(True)
hou_node.hide(False)
hou_node.setSelected(False)

# Code for /obj/Mat/Cryptomatte/cryptomatte1/cryptomatte_depth parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("cryptomatte_depth")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(6)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/sidecar_manifests parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("sidecar_manifests")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/strip_obj_namespaces parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("strip_obj_namespaces")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/strip_mat_namespaces parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("strip_mat_namespaces")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/aov_crypto_asset parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("aov_crypto_asset")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("crypto_asset")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/aov_crypto_object parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("aov_crypto_object")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("crypto_object")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/aov_crypto_material parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("aov_crypto_material")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("crypto_material")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/preview_in_exr parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("preview_in_exr")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/custom_output_driver parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("custom_output_driver")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/create_depth_outputs parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("create_depth_outputs")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/process_maya parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("process_maya")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/process_paths parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("process_paths")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/process_obj_path_pipes parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("process_obj_path_pipes")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/process_mat_path_pipes parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("process_mat_path_pipes")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/process_legacy parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("process_legacy")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(1)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_aov_0 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_aov_0")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("cry")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_src_0 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_src_0")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("cry")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_aov_1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_aov_1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_src_1 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_src_1")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_aov_2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_aov_2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_src_2 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_src_2")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_aov_3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_aov_3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/user_crypto_src_3 parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("user_crypto_src_3")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set("")
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/rgba parm tuple
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm_tuple = hou_node.parmTuple("rgba")
hou_parm_tuple.lock((False, False, False, False))
hou_parm_tuple.deleteAllKeyframes()
hou_parm_tuple.set((0, 0, 0, 0))
hou_parm_tuple.setAutoscope((False, False, False, False))


# Code for /obj/Mat/Cryptomatte/cryptomatte1/r parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("r")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/g parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("g")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/b parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("b")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


# Code for /obj/Mat/Cryptomatte/cryptomatte1/a parm 
if locals().get("hou_node") is None:
    hou_node = hou.node("/obj/Mat/Cryptomatte/cryptomatte1")
hou_parm = hou_node.parm("a")
hou_parm.lock(False)
hou_parm.deleteAllKeyframes()
hou_parm.set(0)
hou_parm.setAutoscope(False)


hou_node.setExpressionLanguage(hou.exprLanguage.Hscript)

hou_node.setUserData("___Version___", "20.5.410")
if hasattr(hou_node, "syncNodeVersionIfNeeded"):
    hou_node.syncNodeVersionIfNeeded("20.5.410")
# Update the parent node.
hou_parent = hou_node


# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()

# Code to establish connections for /obj/Mat/Cryptomatte/OUT_aov
hou_node = hou_parent.node("OUT_aov")
if hou_parent.node("cryptomatte1") is not None:
    hou_node.setInput(0, hou_parent.node("cryptomatte1"), 0)

# Restore the parent and current nodes.
hou_parent = hou_parent.parent()
hou_node = hou_node.parent()
