MARKER = "imported from N:/Houdini_path/python3.11libs"
