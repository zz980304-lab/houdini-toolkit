# -*- coding: utf-8 -*-
"""控制器：把「界面 / 磁盘 / Houdini」三边接起来。

它是唯一知道"做了什么要调谁"的地方：

    界面发信号 → controller → store 落盘 + bridge 动节点 → 回头刷新界面

不 import hou（用 houdini_bridge），也不自己画控件（用 ui）。
想加新功能，基本就是在这里加一个"信号 → 方法"的分支。
"""

import os
import time
import traceback

from . import houdini_bridge as bridge
from . import model, paths, pinyin_index
from . import store as store_mod
from .folder_dialog import FolderDialog
from .name_dialog import NameDialog
from .qt import QtCore, QtGui, QtWidgets, Qt, Signal, enum_of, exec_box
from .ui import NodePresetWindow
from .widgets import DragGhost

_LEFT_BUTTON = enum_of(Qt, "LeftButton")


class Controller(QtCore.QObject):
    """一个窗口一个控制器。"""

    statusMessage = Signal(str)          # 给外面挂日志用（可选）

    def __init__(self, window=None, store=None, parent=None):
        super(Controller, self).__init__(parent)
        self.store = store or store_mod.Store()
        self.store.ensure()
        self.win = window or NodePresetWindow(parent)
        self.presets = []
        self.folders = []
        self._pending_patch = {}
        self._patch_timer = None
        self._dragging = False
        self._wire_hooks()
        self._wire_signals()
        self.reload()

    # ================================================================ 装配
    def _wire_hooks(self):
        """界面不认识 hou，靠这几个 hook 反过来问我们。"""
        self.win.context_provider = self.detect_context
        self.win.screenshot_provider = self.take_screenshot
        self.win.can_create = self.can_create

    def _wire_signals(self):
        win = self.win
        win.createRequested.connect(self.on_create)
        win.editRequested.connect(self.on_edit)
        win.filesDropped.connect(self.on_files_dropped)
        win.presetActivated.connect(self.on_activate)
        win.presetDragOut.connect(self.on_drag_out)
        win.presetContextMenu.connect(self.on_preset_menu)
        win.actionRequested.connect(self.on_action)
        win.nameEdited.connect(self.on_name_edited)
        win.descEdited.connect(self.on_desc_edited)
        win.tagsEdited.connect(self.on_tags_edited)
        win.favoriteToggled.connect(self.on_favorite)
        win.newFolderRequested.connect(self.create_folder)
        win.folderMoved.connect(self.on_folder_moved)
        win.treeContextMenu.connect(self.on_tree_menu)
        win.folderRenamed.connect(self.on_folder_renamed)
        win.settingsAction.connect(self.on_settings)

        timer = QtCore.QTimer(self)
        timer.setSingleShot(True)
        timer.setInterval(450)
        timer.timeout.connect(self._flush_patch)
        self._patch_timer = timer

    # ================================================================ 读库
    def reload(self, select_id=""):
        """重扫磁盘 → 灌给界面。"""
        select_id = select_id or self.win.current_preset_id()
        try:
            self.presets, self.folders = self.store.scan()
        except Exception:                                 # noqa: BLE001
            self.presets, self.folders = [], []
        self._refresh_pinyin(self.presets)
        items = [model.to_ui(meta, self.store.preset_dir(meta["id"]))
                 for meta in self.presets]
        self.win.set_catalog(self.folders)
        self.win.set_presets(items)
        if select_id:
            self.win.select_preset(select_id)
        self.win.set_status("共 %d 个预设 · 库：%s"
                            % (len(items), self.store.root()))
        return items

    def _refresh_pinyin(self, presets):
        """老预设的拼音索引是"数字被吃掉"的版本（「测试2」存成了 "cs"）。

        补一遍再存回去；一致的不动，所以只会在升级后各写一次。
        （即便不补也能搜到 —— `pinyin_index.seq_match` 是现算的 ——
        但索引对了排序才准、导出给别人才是对的。）
        """
        for meta in presets or []:
            try:
                name = str(meta.get("name") or "")
                if meta.get("py_abbr") == pinyin_index.abbr(name):
                    continue
                pinyin_index.build(meta)
                self.store.write_meta(
                    self.store.preset_dir(meta.get("id") or ""), meta)
            except Exception:                             # noqa: BLE001
                continue

    def find_meta(self, preset_id):
        for meta in self.presets:
            if meta.get("id") == preset_id:
                return meta
        return self.store.read_meta(preset_id)

    # ================================================================ Houdini 侧
    def detect_context(self):
        """当前网络层级的 category（创建框默认选它）。"""
        if not bridge.available():
            return ""
        nodes = bridge.selected_nodes()
        if nodes:
            info = bridge.describe(nodes)
            if info.get("context"):
                return info["context"]
        network = bridge.current_network()
        if network is None:
            return ""
        try:
            category = network.childTypeCategory()
            return category.name() if category else ""
        except Exception:                                 # noqa: BLE001
            return ""

    def can_create(self):
        """点「＋ 新建」之前先确认有选中节点，免得填完框才发现没东西可存。"""
        if not bridge.available():
            return True
        if bridge.selected_nodes():
            return True
        self.warn("没有选中的节点。\n先在网络编辑器里选中要保存的节点，"
                  "再点「＋ 新建」或把节点拖进来。")
        return False

    def take_screenshot(self, path):
        """创建框里点「截视口」时调这里。"""
        try:
            return bridge.screenshot_viewport(path, width=640)
        except Exception:                                 # noqa: BLE001
            return ""

    # ================================================================ 新建
    def on_create(self, values):
        values = dict(values or {})
        nodes = bridge.selected_nodes()
        if not nodes:
            self.warn("没有选中的节点。\n先在网络编辑器里选中要保存的节点，"
                      "再拖进来或点「＋ 新建」。")
            return
        info = bridge.describe(nodes)
        if not values.get("context"):
            values["context"] = info.get("context") or ""

        # 文件夹必须和预设属于同一层级，不然树里会找不到
        folder_id = values.get("folder_id") or ""
        if folder_id:
            folder = self._folder(folder_id)
            if folder is None or folder.get("context") != values["context"]:
                values["folder_id"] = ""

        preset_id = model.new_preset_id()
        try:
            preset_dir = self.store.new_preset_dir(preset_id)
        except Exception as exc:                          # noqa: BLE001
            self.warn("建目录失败：%r" % exc)
            return

        saved = bridge.save_nodes(nodes, preset_dir)
        if saved.get("error"):
            self.store.delete_preset(preset_id, to_trash=False)
            self.warn(saved["error"])
            return

        meta = model.build_meta(values, saved, preset_id)
        pinyin_index.build(meta)
        self.store.write_meta(preset_dir, meta)

        preview = values.get("preview") or ""
        if preview:
            self.store.set_preview(preset_id, preview)

        self.reload(preset_id)
        self.message("已存为预设「%s」（%d 个节点）"
                     % (meta["name"], meta.get("node_count") or 0))

    def on_edit(self, values):
        """创建框跑「编辑已有预设」模式：只改元信息，节点内容不动。"""
        values = dict(values or {})
        preset_id = str(values.get("id") or "")
        meta = self.find_meta(preset_id)
        if meta is None:
            return
        changes = {}
        for key in ("name", "desc", "tags", "context"):
            if key in values:
                changes[key] = values[key]
        if "folder_id" in values:
            folder_id = values.get("folder_id") or ""
            folder = self._folder(folder_id) if folder_id else None
            # 文件夹必须和预设同层级，不然树里找不到
            if folder_id and folder is None:
                folder_id = ""
            if folder_id and folder.get("context") != (
                    values.get("context") or meta.get("context")):
                folder_id = ""
            changes["folder_id"] = folder_id or None
        if changes.get("name") or changes.get("tags") is not None:
            probe = dict(meta)
            probe.update(changes)
            pinyin_index.build(probe)
            changes["py_abbr"] = probe.get("py_abbr", "")
            changes["py_full"] = probe.get("py_full", "")
            changes["py_abbr_tags"] = probe.get("py_abbr_tags", "")
        if changes:
            self.store.patch(preset_id, changes)
        preview = values.get("preview") or ""
        if preview:
            self.store.set_preview(preset_id, preview)
            self.win.previews.clear()
        self.reload(preset_id)
        self.message("已更新「%s」的信息" % (changes.get("name")
                                       or meta.get("name") or preset_id))

    def on_files_dropped(self, paths):
        """从资源管理器拖文件进来：.npreset 走导入，图片给当前预设当预览图。"""
        paths = [p for p in (paths or []) if p and os.path.isfile(p)]
        if not paths:
            return
        packs = [p for p in paths
                 if p.lower().endswith(store_mod.NP_EXT)]
        if packs:
            total = 0
            last = ""
            for path in packs:
                ids, error = self.store.import_presets(path)
                if error:
                    self.warn(error)
                elif ids:
                    total += len(ids)
                    last = ids[0]
            self.reload(last)
            self.message("导入了 %d 个预设" % total)
            return
        images = [p for p in paths
                  if os.path.splitext(p.lower())[1]
                  in (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")]
        if not images:
            self.message("这些文件用不了（只认 .npreset 和图片）")
            return
        preset_id = self.win.current_preset_id()
        if not preset_id:
            self.warn("先在中间选中一个预设，再拖图片进来当预览图。")
            return
        if self.store.set_preview(preset_id, images[0]):
            self.win.previews.clear()
            self.reload(preset_id)
            self.message("预览图已换成：%s" % os.path.basename(images[0]))
        else:
            self.warn("这张图存不进去：%s" % images[0])

    # ================================================================ 应用
    def on_activate(self, preset_id):
        """双击卡片：放到当前网络，位置放在网络编辑器看得见的地方。"""
        spot = bridge.current_view_spot()
        if spot is None:
            self.apply_preset(preset_id)
            return
        network, position = spot
        self.apply_preset(preset_id, network, position)

    def apply_preset(self, preset_id, parent=None, position=None):
        meta = self.find_meta(preset_id)
        if meta is None:
            return False
        preset_dir = self.store.preset_dir(preset_id)
        # 把预设自己的层级一起给 bridge：GEO 的预设放进 OBJ 会失败，
        # 那边提前比对并说人话，比 Houdini 那句"没新增节点"好懂得多
        nodes, error = bridge.load_preset(preset_dir, parent,
                                          meta.get("context") or "",
                                          position)
        if nodes:
            self.store.bump_use(preset_id)
            self.reload(preset_id)
            where = ""
            try:
                if parent is not None:
                    where = " → %s" % parent.path()
            except Exception:                             # noqa: BLE001
                where = ""
            self.message("已放入 %d 个节点%s：%s"
                         % (len(nodes), where,
                            " ".join(n.name() for n in nodes[:4])))
            return True
        if error:
            self.warn("放不进去：%s" % error)
        return False

    def _over_own_window(self, point):
        """鼠标还在本工具窗口里吗？在的话一律不算落点（松手=取消）。"""
        try:
            top = self.win.window()
            if top is None:
                return False
            return top.geometry().contains(point)
        except Exception:                                 # noqa: BLE001
            return False

    def _sample_drop_spot(self, point):
        """问一次"现在松手会放到哪"。在自己窗口上 / 桌面 / 别的面板 → None。"""
        if self._over_own_window(point):
            return None
        try:
            return bridge.drop_spot(point)
        except Exception:                                 # noqa: BLE001
            return None

    def on_drag_out(self, preset_id):
        """从卡片拖出去：残影跟着鼠标，松手落在**鼠标下的网络、鼠标的位置**。

        两条硬规则（用户明确要求）：
        1. 松手的地方不是网络编辑器 → **什么都不放**，直接取消。
           （旧版会退回"当前网络"，结果怎么拖都会建出节点。）
        2. 放到网络编辑器里时，节点落在鼠标落点，不是它保存时的坐标。
        """
        if self._dragging:            # 残影轮询里会 processEvents，防重入
            return
        meta = self.find_meta(preset_id)
        if meta is None:
            return
        self._dragging = True
        ui_item = None
        try:
            ui_item = model.to_ui(meta, self.store.preset_dir(preset_id))
        except Exception:                                 # noqa: BLE001
            ui_item = {}
        pixmap = None
        try:
            pixmap = self.win.previews.pixmap(ui_item.get("preview") or "",
                                              180, 112)
        except Exception:                                 # noqa: BLE001
            pixmap = None

        ghost = None
        app = QtWidgets.QApplication.instance()
        start = QtGui.QCursor.pos()
        spot = None              # 最后一次有效落点 (network, (x, y))
        spot_stamp = 0.0
        timed_out = False
        try:
            ghost = DragGhost()
            ghost.set_content(pixmap, meta.get("name") or "")
            ghost.follow(start)
            ghost.show()

            deadline = time.time() + 30.0
            last_sample = 0.0
            while True:
                now = time.time()
                if now > deadline:
                    timed_out = True
                    break
                if app is not None:
                    app.processEvents()
                point = QtGui.QCursor.pos()
                ghost.follow(point)
                buttons = app.mouseButtons() if app is not None else 0
                try:
                    pressed = bool(int(buttons) & int(_LEFT_BUTTON))
                except Exception:                         # noqa: BLE001
                    pressed = False
                if not pressed:
                    break
                # 采样不用每帧都做：问 hou 要落点要走遍所有网络编辑器
                if now - last_sample >= 0.08:
                    last_sample = now
                    found = self._sample_drop_spot(point)
                    if found is not None:
                        spot = found
                        spot_stamp = now
                        try:
                            ghost.set_hint("松手放到 %s" % found[0].path(),
                                           True)
                        except Exception:                 # noqa: BLE001
                            pass
                    else:
                        try:
                            ghost.set_hint("松开鼠标 = 取消\n"
                                           "（要放到网络编辑器里）", False)
                        except Exception:                 # noqa: BLE001
                            pass
                time.sleep(0.01)
        finally:
            try:
                if ghost is not None:
                    ghost.hide()
                    ghost.deleteLater()
            except Exception:                             # noqa: BLE001
                pass
            try:
                self.win.view._drag_done = True
            except Exception:                             # noqa: BLE001
                pass
            self._dragging = False

        if timed_out:
            self.message("拖太久了，已取消（什么都没放）")
            return

        # 松手瞬间再问一次，以这一刻为准
        end = QtGui.QCursor.pos()
        fresh = self._sample_drop_spot(end)
        if fresh is not None:
            spot = fresh
        elif spot is not None and time.time() - spot_stamp > 0.6:
            spot = None                                   # 缓存太旧，不认
        if spot is None:
            self.message("已取消：松手的地方不是网络编辑器，什么都没放")
            return

        # 几乎没挪动过（按下就松开）→ 当成点击，别放
        try:
            if (start - end).manhattanLength() < 8:
                return
        except Exception:                                 # noqa: BLE001
            pass

        network, position = spot
        done = self.apply_preset(preset_id, network, position)
        if done:
            try:
                self.message("放到 %s 的鼠标落点" % network.path())
            except Exception:                             # noqa: BLE001
                pass

    # ================================================================ 卡片菜单
    def on_preset_menu(self, preset_id, pos):
        self._settle()
        key = self.win.preset_menu(preset_id, pos)
        if not key:
            return
        if key == "rename":
            self.rename_preset(preset_id)
            return
        if key == "edit":
            data = self.win.current_preset()
            if data:
                self.win.open_create_dialog(preset=data)
            return
        if key == "preview_clip":
            self.apply_clipboard_preview(preset_id)
            return
        if key == "update_content":
            self.update_content(preset_id)
            return
        if key == "reveal":
            bridge.reveal_in_explorer(self.store.preset_dir(preset_id))
            return
        if key == "move_to":
            self.choose_folder_for(preset_id)
            return
        if key == "favorite":
            meta = self.find_meta(preset_id) or {}
            self.on_favorite(preset_id, not meta.get("favorite"))
            return
        self.on_action(key, preset_id)

    def _target_ids(self, preset_id):
        """右键操作作用于哪些预设：它被多选包着就整组，否则只它一个。"""
        try:
            selected = [i for i in (self.win.selected_ids() or []) if i]
        except Exception:                                     # noqa: BLE001
            selected = []
        if preset_id in selected and len(selected) > 1:
            return selected
        return [preset_id]

    def on_action(self, action, preset_id):
        if not preset_id:
            return
        self._settle()
        if action == "apply":
            self.apply_preset(preset_id)
        elif action == "preview_file":
            self.choose_preview_file(preset_id)
        elif action == "preview_shot":
            self.shoot_preview(preset_id)
        elif action == "export":
            self.export_presets(self._target_ids(preset_id))
        elif action == "duplicate":
            new_id = self.store.duplicate_preset(preset_id)
            if new_id:
                self.reload(new_id)
                self.message("已复制副本")
        elif action == "delete":
            self.delete_presets(self._target_ids(preset_id))
        elif action == "apply_to":
            self.apply_preset(preset_id)

    # ---------------------------------------------------------------- 详情编辑
    def on_name_edited(self, preset_id, text):
        meta = self.find_meta(preset_id)
        if meta is None:
            return
        text = str(text or "").strip()
        if not text or text == meta.get("name"):
            return
        meta["name"] = text
        pinyin_index.build(meta)
        self._queue_patch(preset_id, {"name": text,
                                      "py_abbr": meta["py_abbr"],
                                      "py_full": meta["py_full"],
                                      "py_abbr_tags": meta["py_abbr_tags"]})

    def on_desc_edited(self, preset_id, text):
        self._queue_patch(preset_id, {"desc": str(text or "")})

    def on_tags_edited(self, preset_id, tags):
        tags = [str(t) for t in (tags or [])]
        meta = self.find_meta(preset_id) or {}
        meta["tags"] = tags
        pinyin_index.build(meta)
        self._queue_patch(preset_id, {"tags": tags,
                                      "py_abbr_tags": meta.get("py_abbr_tags", "")})

    def on_favorite(self, preset_id, checked):
        self.store.patch(preset_id, {"favorite": bool(checked)})
        self.reload(preset_id)

    def on_folder_moved(self, preset_id, folder_id):
        self.store.patch(preset_id, {"folder_id": folder_id or None})
        self.reload(preset_id)

    def _queue_patch(self, preset_id, changes):
        """简介是逐字触发的，攒一下再落盘（450ms 防抖）。"""
        bucket = self._pending_patch.setdefault(preset_id, {})
        bucket.update(changes or {})
        if self._patch_timer is not None:
            self._patch_timer.start()

    def _settle(self):
        """把还没落盘的编辑先落盘（改名 / 简介有 450ms 防抖）。

        不这么做的话：改完名字立刻右键「复制副本」，复制到的还是旧名字。
        """
        if not self._pending_patch:
            return
        if self._patch_timer is not None:
            try:
                self._patch_timer.stop()
            except Exception:                             # noqa: BLE001
                pass
        self._flush_patch()

    def _flush_patch(self):
        pending = self._pending_patch
        self._pending_patch = {}
        if not pending:
            return
        for preset_id, changes in pending.items():
            try:
                self.store.patch(preset_id, changes)
            except Exception:                             # noqa: BLE001
                pass
        self.reload()

    # ================================================================ 预览图
    def choose_preview_file(self, preset_id):
        start = ""
        meta = self.find_meta(preset_id) or {}
        preview = meta.get("preview") or ""
        if preview:
            start = os.path.dirname(
                os.path.join(self.store.preset_dir(preset_id), preview))
        path, _filter = QtWidgets.QFileDialog.getOpenFileName(
            self.win, "挑一张预览图", start,
            "图片 (*.png *.jpg *.jpeg *.gif *.webp *.bmp)")
        if path:
            self.store.set_preview(preset_id, path)
            self.win.previews.clear()
            self.reload(preset_id)
            self.message("预览图已更新")

    def apply_clipboard_preview(self, preset_id):
        clipboard = QtWidgets.QApplication.clipboard()
        image = clipboard.image() if clipboard is not None else None
        if image is None or image.isNull():
            self.warn("剪贴板里没有图片")
            return
        tmp = os.path.join(paths.cache_dir(), "clip_%d.png"
                           % int(QtCore.QDateTime.currentMSecsSinceEpoch()))
        try:
            if not os.path.isdir(paths.cache_dir()):
                os.makedirs(paths.cache_dir())
            image.save(tmp, "PNG")
        except Exception as exc:                          # noqa: BLE001
            self.warn("存临时图失败：%r" % exc)
            return
        self.store.set_preview(preset_id, tmp)
        self.win.previews.clear()
        self.reload(preset_id)
        self.message("已从剪贴板贴上预览图")

    def shoot_preview(self, preset_id):
        tmp = os.path.join(paths.cache_dir(), "shot_%d.png"
                           % int(QtCore.QDateTime.currentMSecsSinceEpoch()))
        path = self.take_screenshot(tmp)
        if not path:
            self.warn("截不到视口。\n确认 SceneViewer 开着；"
                      "如果视口被别的窗口挡住，截到的会是挡住它的窗口。")
            return
        self.store.set_preview(preset_id, path)
        self.win.previews.clear()
        self.reload(preset_id)
        self.message("已截取当前视口当预览")

    # ================================================================ 内容更新
    def update_content(self, preset_id):
        """用当前选中的节点覆盖这个预设的内容（名字/简介/分类都不动）。"""
        nodes = bridge.selected_nodes()
        if not nodes:
            self.warn("先选中节点，再来点「用当前选择更新内容」。")
            return
        preset_dir = self.store.preset_dir(preset_id)
        saved = bridge.save_nodes(nodes, preset_dir)
        if saved.get("error"):
            self.warn(saved["error"])
            return
        meta = self.find_meta(preset_id) or {}
        old_context = meta.get("context") or ""
        new_context = saved.get("context") or old_context
        # 新节点的层级变了，原文件夹是挂在旧层级下的，留着会让这个预设"消失"
        note = ""
        if (new_context and old_context and new_context != old_context
                and meta.get("folder_id")):
            folder = self._folder(meta["folder_id"])
            if folder is None or folder.get("context") != new_context:
                meta["folder_id"] = None
                note = "（层级变了，已退回未分类）"
        meta.update({
            "context": new_context,
            "node_types": saved.get("node_types") or [],
            "node_names": saved.get("node_names") or [],
            "node_count": saved.get("node_count") or 0,
            "source_path": saved.get("source_path") or "",
        })
        pinyin_index.build(meta)
        self.store.write_meta(preset_dir, meta)
        self.reload(preset_id)
        self.message("内容已更新（%d 个节点）%s"
                     % (saved.get("node_count") or 0, note))

    # ================================================================ 删除 / 导出
    def delete_presets(self, preset_ids):
        preset_ids = [p for p in (preset_ids or []) if p]
        if not preset_ids:
            return
        self._settle()
        names = []
        for preset_id in preset_ids[:3]:
            meta = self.find_meta(preset_id) or {}
            names.append(meta.get("name") or preset_id)
        text = "确定删掉 %d 个预设？\n%s" % (
            len(preset_ids), "\n".join(names) + (" …" if len(preset_ids) > 3 else ""))
        box = QtWidgets.QMessageBox(self.win)
        box.setWindowTitle("删除预设")
        box.setText(text)
        box.setInformativeText("文件会移到 library/_trash，不是立刻销毁。")
        box.setStandardButtons(
            enum_of(QtWidgets.QMessageBox, "Yes")
            | enum_of(QtWidgets.QMessageBox, "No"))
        if exec_box(box) != enum_of(QtWidgets.QMessageBox, "Yes"):
            return
        for preset_id in preset_ids:
            self.store.delete_preset(preset_id)
        self.reload()
        self.message("删了 %d 个预设" % len(preset_ids))

    def export_presets(self, preset_ids):
        preset_ids = [p for p in (preset_ids or []) if p]
        if not preset_ids:
            return
        self._settle()
        default = os.path.join(self.store.root(),
                               "%s.npreset" % (self.find_meta(preset_ids[0]) or {})
                               .get("name", "preset"))
        path, _filter = QtWidgets.QFileDialog.getSaveFileName(
            self.win, "导出预设", default, "节点预设 (*.npreset)")
        if not path:
            return
        if not path.lower().endswith(store_mod.NP_EXT):
            path += store_mod.NP_EXT
        if self.store.export_presets(preset_ids, path):
            self.message("已导出：%s" % os.path.basename(path))
        else:
            self.warn("导出失败")

    def import_presets(self):
        path, _filter = QtWidgets.QFileDialog.getOpenFileName(
            self.win, "导入 .npreset", self.store.root(),
            "节点预设 (*.npreset)")
        if not path:
            return
        ids, error = self.store.import_presets(path)
        self.reload(ids[0] if ids else "")
        if error:
            self.warn(error)
        else:
            self.message("导入 %d 个预设" % len(ids))

    # ================================================================ 文件夹
    def _folder(self, folder_id):
        for folder in self.folders:
            if folder.get("id") == folder_id:
                return folder
        return None

    def on_tree_menu(self, kind, value, pos):
        if kind == "folder":
            key = self.win.folder_menu(pos)
            if key:
                self._folder_action(key, value)
            return
        if kind == "context":
            key = self.win.context_menu(pos)
            if key == "new_folder":
                self.create_folder(context=value)
            return
        if kind in ("all", "fav", "recent"):
            key = self.win.context_menu(pos)
            if key == "new_folder":
                self.create_folder(context=self.detect_context())
            return
        if kind == "unfiled":
            # 「未分类」不是真文件夹（没法改名/删除），但在这里也让人能建文件夹
            key = self.win.context_menu(pos)
            if key == "new_folder":
                self.create_folder(context=value or self.detect_context())

    def _folder_action(self, key, folder_id):
        folder = self._folder(folder_id) or {}
        if key == "new_sub":
            self.create_folder(context=folder.get("context") or "",
                               parent=folder_id)
        elif key == "rename":
            self.rename_folder(folder_id)
        elif key == "appearance":
            self.edit_folder(folder_id)
        elif key == "delete":
            self.delete_folder(folder_id)

    def rename_preset(self, preset_id):
        """卡片右键「重命名」→ 弹一个小框。

        以前只是把焦点丢给右侧的名字输入框，用户根本看不出发生了什么
        （反馈太弱，表现为"右键重命名没反应"）。现在弹框，回车即生效。
        """
        self._settle()
        meta = self.find_meta(preset_id)
        if meta is None:
            return
        name = NameDialog.ask(self.win, title="重命名预设", label="名字",
                              value=meta.get("name") or "",
                              hint="回车确定；搜索用的拼音索引会自动跟着更新")
        if not name or name == meta.get("name"):
            return
        self.on_name_edited(preset_id, name)
        self._settle()
        self.reload(preset_id)
        self.message("已改名为「%s」" % name)

    def rename_folder(self, folder_id):
        """右键「重命名」→ 直接在树上就地改；树里没那一行才退成小框。"""
        self._settle()
        if folder_id and self.win.start_rename(folder_id):
            return
        folder = self._folder(folder_id) or {}
        name = NameDialog.ask(self.win, title="重命名文件夹", label="名字",
                              value=folder.get("name") or "")
        if not name:
            return
        self.store.update_folder(folder_id, {"name": name})
        self.reload()
        self.message("文件夹已改名为「%s」" % name)

    def on_folder_renamed(self, folder_id, name):
        """双击 / 就地改名提交。"""
        folder = self._folder(folder_id)
        if folder is None:
            return
        name = str(name or "").strip()
        if not name:
            return
        if name == (folder.get("name") or ""):
            return
        self.store.update_folder(folder_id, {"name": name})
        self.reload()
        self.message("文件夹改名为「%s」" % name)

    def edit_folder(self, folder_id):
        folder = self._folder(folder_id)
        if folder is None:
            return
        dialog = FolderDialog(self.win, folders=self.folders,
                              context=folder.get("context") or "",
                              parent_id=folder.get("parent") or "",
                              folder=folder, title="编辑文件夹")
        if not dialog.exec_dialog():
            return
        values = dialog.values()
        self.store.update_folder(folder_id, {
            "name": values["name"], "color": values["color"],
            "shape": values["shape"], "parent": values["parent"],
        })
        self.reload()
        self.message("文件夹已更新")

    def delete_folder(self, folder_id):
        """删文件夹：默认按钮是「取消」，防止回车/手滑把整棵子树删掉。"""
        folder = self._folder(folder_id) or {}
        try:
            self.win.end_rename()
        except Exception:                                     # noqa: BLE001
            pass
        box = QtWidgets.QMessageBox(self.win)
        box.setWindowTitle("删除文件夹")
        box.setIcon(enum_of(QtWidgets.QMessageBox, "Warning"))
        box.setText("确定删除文件夹「%s」？" % (folder.get("name") or ""))
        box.setInformativeText(
            "子文件夹会一起删掉；里面的预设不会被删，会退回「未分类」。")
        delete_btn = box.addButton("删除", enum_of(QtWidgets.QMessageBox,
                                                 "DestructiveRole"))
        cancel_btn = box.addButton("取消", enum_of(QtWidgets.QMessageBox,
                                                 "RejectRole"))
        box.setDefaultButton(cancel_btn)
        box.setEscapeButton(cancel_btn)
        exec_box(box)
        if box.clickedButton() is not delete_btn:
            return
        self.store.delete_folder(folder_id)
        self.reload()
        self.message("文件夹已删除")

    def create_folder(self, context="", parent=""):
        dialog = FolderDialog(self.win, folders=self.folders,
                              context=context or self.detect_context(),
                              parent_id=parent, title="新建文件夹")
        if not dialog.exec_dialog():
            return
        values = dialog.values()
        folder = self.store.add_folder(values["name"], values["context"],
                                       values["parent"], values["color"],
                                       values["shape"])
        self.reload()
        # 建完要在树上选中它 —— 不然用户看不见自己刚建的东西，
        # 也就会以为"右键没有重命名"（真出过：层级没预设时整行都不显示）
        self.win.select_folder(folder.get("id") or "")
        self.message("新建文件夹「%s」" % folder.get("name"))

    def choose_folder_for(self, preset_id):
        meta = self.find_meta(preset_id) or {}
        context = meta.get("context") or ""
        menu = QtWidgets.QMenu(self.win)
        actions = {"": menu.addAction("（未分类）")}
        for folder in self.folders:
            if folder.get("context") != context:
                continue
            actions[folder["id"]] = menu.addAction(folder.get("name") or "?")
        picked = None
        for name in ("exec_", "exec"):
            method = getattr(menu, name, None)
            if method is None:
                continue
            try:
                picked = method(QtGui.QCursor.pos())
                break
            except TypeError:
                continue
        for folder_id, action in actions.items():
            if action is picked:
                self.store.patch(preset_id, {"folder_id": folder_id or None})
                self.reload(preset_id)
                return

    # ================================================================ 设置菜单
    def on_settings(self, key):
        if key == "library_dir":
            path = QtWidgets.QFileDialog.getExistingDirectory(
                self.win, "选预设库目录", self.store.root())
            if path:
                paths.set_library_dir(path)
                self.store.set_root(path)
                self.reload()
                self.message("预设库改到：%s" % path)
        elif key == "backup":
            path = self.store.backup()
            if path:
                self.message("已备份：%s" % os.path.basename(path))
            else:
                self.warn("备份失败")
        elif key == "import":
            self.import_presets()
        elif key == "clear_cache":
            removed = self.store.clear_cache()
            self.win.previews.clear()
            self.reload()
            self.message("清了 %d 个缓存文件" % removed)
        elif key == "publish":
            self.publish()
        elif key == "check_update":
            self.check_update()

    def publish(self):
        try:
            from . import publisher
        except Exception as exc:                          # noqa: BLE001
            self.warn("发布模块还没装好：%r" % exc)
            return
        publisher.publish_from_ui(self)

    def check_update(self):
        try:
            from . import updater
        except Exception as exc:                          # noqa: BLE001
            self.warn("更新模块还没装好：%r" % exc)
            return
        updater.check_from_ui(self)

    # ================================================================ 小工具
    def message(self, text):
        self.win.set_status(str(text))
        bridge.status_text(text)
        self.statusMessage.emit(str(text))

    def warn(self, text):
        self.win.set_status(str(text))
        box = QtWidgets.QMessageBox(self.win)
        box.setIcon(enum_of(QtWidgets.QMessageBox, "Warning"))
        box.setWindowTitle("节点预设库")
        box.setText(str(text))
        exec_box(box)


__all__ = ["Controller"]
