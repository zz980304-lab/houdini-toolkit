# -*- coding: utf-8 -*-
"""Houdini 层级（node type category）→ 界面显示用的简名与颜色。

用户要求：层级名字别复杂，就 OBJ / GEO / DOP / ROP / PDG / Mat / Chop 这种。

category 是 Houdini 内部名（20.5 实测 18 个）：
    Chop ChopNet Cop Cop2 CopNet Data Director Dop Driver Lop Manager
    Object Shop Sop Top TopNet Vop VopNet

各网络路径实际对应（hython 实测）：
    /obj     → Object      /out   → Driver（就是 ROP！）
    /stage   → Lop         /tasks → TopNet（PDG）
    /mat     → Vop         /vex   → VopNet
    /ch      → ChopNet     /img   → CopNet
    /shop    → Shop        /      → Manager
    geo 内部  → Sop

**界面不写死清单**：预设里存的是原始 category，这里只做"认得出来的"映射，
认不出来的显示原始名并归到「其它」。这样 H21 新增类别也不用改代码。
"""

#: category → 显示名（简短，跟网络编辑器里的习惯对齐）
LABELS = {
    "Sop": "GEO",
    "Object": "OBJ",
    "Dop": "DOP",
    "Driver": "ROP",
    "Top": "PDG",
    "TopNet": "PDG",
    "Vop": "Mat",
    "VopNet": "Mat",
    "Chop": "Chop",
    "ChopNet": "Chop",
    "Lop": "LOP",
    "Cop": "COP",
    "Cop2": "COP",
    "CopNet": "COP",
    "Shop": "SHOP",
}

#: 认不出来的 category 归到这里
OTHER = "其它"

#: 显示顺序（数组里的排前面，没列出的按字母排在其后）
ORDER = ["Sop", "Object", "Dop", "Driver", "Top", "Vop", "Chop",
         "Lop", "Cop", "Shop"]

#: 层级默认色（树里的圆点，跟 Houdini 网络框的色感对齐；用户不可改）
COLORS = {
    "Sop": "#4C9A5A",
    "Object": "#4A90D9",
    "Dop": "#E08A3C",
    "Driver": "#8A8F98",
    "Top": "#9B6BD6",
    "Vop": "#D0A03C",
    "Chop": "#3CB8A0",
    "Lop": "#5A7FB8",
    "Cop": "#C2694A",
    "Shop": "#8C8C8C",
    OTHER: "#6E7480",
}

DEFAULT_COLOR = "#6E7480"


def label_of(category):
    """category → 简名；认不出来返回原始名。"""
    if not category:
        return OTHER
    return LABELS.get(str(category), str(category))


def key_of(category):
    """把 category 归并到它的显示分组（Top/TopNet 都算 Top）。"""
    text = str(category or "")
    for real, shown in LABELS.items():
        if shown == label_of(text) and real in ORDER:
            return real
    return text or OTHER


def color_of(category):
    return COLORS.get(key_of(category), COLORS.get(OTHER, DEFAULT_COLOR))


def is_other(category):
    return key_of(category) not in ORDER


def sort_key(category):
    """树里的排序：ORDER 里按下标，其它往后排。"""
    key = key_of(category)
    try:
        return (0, ORDER.index(key))
    except ValueError:
        return (1, label_of(category))


__all__ = ["LABELS", "ORDER", "COLORS", "OTHER", "DEFAULT_COLOR",
           "label_of", "key_of", "color_of", "is_other", "sort_key"]
