# -*- coding: utf-8 -*-
"""输入法守卫（IME guard）—— Houdini 里 Qt 输入框打不了中文的通用解法。

背景（踩过的坑）
---------------
Houdini 自己的 Qt 事件循环会把部分控件的 `WA_InputMethodEnabled` 关掉
（或者说：嵌在 Houdini 主窗口里的 Qt 窗口，输入法上下文不跟着走）。
这个属性关着，中文/日文输入法的候选框就根本不出来 —— 不是乱码，是**敲不进去**。
表现就是：拼音敲一串，框里一个字都没有。

解法：给窗口 + 窗口里所有可输入控件把这个属性补成 True。
只补一次不够（show/激活之后 Houdini 又给你关回去），所以还要挂个定时器复查。

为什么单独一个文件
------------------
这套逻辑原来散在 ui.py / create_dialog.py / name_dialog.py 里各抄了一遍，
结果 folder_dialog.py 忘了抄 —— 于是「新建文件夹」打不了中文（老问题）。
现在统一到这一个模块，**任何需要能打中文的窗口都调 `install_ime_guard()`**，
以后再加新框只要记得这一行就行。

用法
----
    from .ime import install_ime_guard
    class MyDialog(QtWidgets.QDialog):
        def __init__(self, parent=None):
            ...
            install_ime_guard(self)          # 建完所有控件之后调一次

    # 单个输入框也能用：
    install_ime_guard(self.edit)
"""

from .qt import QtCore, QtWidgets, Qt, enum_of

__all__ = ["enable_ime", "ime_widgets", "install_ime_guard", "ImeGuard"]

#: 会被补属性的控件类型（够用就行，别把 QComboBox 之类也算进来）
_EDIT_CLASSES = ("QLineEdit", "QTextEdit", "QPlainTextEdit")

_GUARD_ATTR = "_ime_guard_obj"


def _attr():
    return enum_of(Qt, "WA_InputMethodEnabled")


def ime_widgets(root):
    """root 自己 + 它下面所有可输入控件 + 它所在的顶层窗口。

    顶层窗口也算上：光给输入框补、窗口本身没补，输入法上下文照样起不来。
    """
    widgets = [root]
    try:
        window = root.window()
        if window is not None and window is not root:
            widgets.append(window)
    except Exception:                                     # noqa: BLE001
        pass
    for name in _EDIT_CLASSES:
        klass = getattr(QtWidgets, name, None)
        if klass is None:
            continue
        try:
            widgets.extend(root.findChildren(klass))
        except Exception:                                 # noqa: BLE001
            pass
    return widgets


def enable_ime(widgets):
    """把 `WA_InputMethodEnabled` 补成 True。返回实际补了几个。"""
    attr = _attr()
    done = 0
    for widget in widgets:
        try:
            if not widget.testAttribute(attr):
                widget.setAttribute(attr, True)
                done += 1
        except Exception:                                 # noqa: BLE001
            pass
    return done


class ImeGuard(QtCore.QObject):
    """盯着一个控件树，谁的输入法属性被关了就给谁补回来。

    两道保险：
      1. 事件过滤 —— 窗口 Show / WindowActivate 的瞬间补一次（反应最快）；
      2. 定时器   —— 每 500ms 复查一次（Houdini 事后偷偷关掉的情况靠它）。
    """

    def __init__(self, root, interval=500):
        super(ImeGuard, self).__init__(root)
        self._root = root
        self.enable()
        try:
            root.installEventFilter(self)
        except Exception:                                 # noqa: BLE001
            pass
        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(int(interval) if interval else 500)
        self._timer.timeout.connect(self.tick)
        self._timer.start()

    # ------------------------------------------------------------ 动作
    def enable(self):
        try:
            enable_ime(ime_widgets(self._root))
        except Exception:                                 # noqa: BLE001
            pass

    def tick(self):
        root = self._root
        try:
            if not root.isVisible():
                return
        except Exception:                                 # noqa: BLE001
            return
        if enable_ime(ime_widgets(root)):
            # 补过了：说明 Houdini 又关了一次，顺手再补一遍窗口本身
            self.enable()

    # ------------------------------------------------------------ 过滤
    def eventFilter(self, watched, event):                # noqa: N802
        try:
            kind = event.type()
            show = enum_of(QtCore.QEvent, "Show")
            activate = enum_of(QtCore.QEvent, "WindowActivate")
            if kind in (show, activate):
                self.enable()
        except Exception:                                 # noqa: BLE001
            pass
        return False


def install_ime_guard(root, interval=500):
    """给 root 装输入法守卫（同一个 root 装多次只有第一次生效）。

    返回 ImeGuard 实例（基本用不到，留着方便调试 / 手动 tick）。
    """
    if root is None:
        return None
    old = getattr(root, _GUARD_ATTR, None)
    if old is not None:
        return old
    try:
        guard = ImeGuard(root, interval=interval)
    except Exception:                                     # noqa: BLE001
        return None
    try:
        setattr(root, _GUARD_ATTR, guard)
    except Exception:                                     # noqa: BLE001
        pass
    return guard
