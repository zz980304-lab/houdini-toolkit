# -*- coding: utf-8 -*-
"""节点预设库 —— 界面层。

铁律：**这个文件不 import hou**，也不认识 store / 磁盘上的任何东西。
数据一律靠 set_presets() / set_catalog() 灌进来，想干什么只发信号，
由 controller 去接。这样脱离 Houdini 也能把界面跑起来看（_preview.py）。

布局
    顶栏  搜索 / 排序 / 网格·列表 / 新建 / 设置菜单
    左    分类树：全部 · 收藏 · 最近使用 → 层级（GEO/OBJ/DOP/ROP/PDG/Mat/Chop…）
          → 层级下你自己的彩色文件夹
    中    预设卡片（网格缩略图 / 列表）
    右    详情：大预览(GIF 会动) + 名字/简介/标签/分类/统计 + 一排按钮
    底    状态栏

拖拽：**整个窗口任何位置都能接**（靠 QApplication 事件过滤器，不吃子控件的
acceptDrops 设置），拖进来时会盖一层遮罩提示，松手弹 CreatePresetDialog
填名字/简介/分类。不再有底部那条横幅。
"""

import os
import time

from . import contexts, icons
from .create_dialog import CreatePresetDialog
from .ime import enable_ime, ime_widgets, install_ime_guard
from .qt import (QtCore, QtGui, QtWidgets, Qt, Signal, enum_of, event_pos)
from .widgets import (DropOverlay, InlineRename, PresetDelegate, PresetView,
                      PreviewLabel, PreviewStore, TagBar)

_USER_ROLE = int(enum_of(Qt, "UserRole"))
_ROLE_DATA = _USER_ROLE
_ROLE_KIND = _USER_ROLE + 1
_ROLE_VALUE = _USER_ROLE + 2

_ALIGN_LEFT = enum_of(Qt, "AlignLeft")
_ALIGN_VCENTER = enum_of(Qt, "AlignVCenter")
_ALIGN_CENTER = enum_of(Qt, "AlignCenter")

_UNFILED = "__unfiled__"

#: 本工具自己拖拽卡片时用的 MIME（以后"拖到树上归类"用），事件过滤器会放行
_MIME_PRESET = "application/x-node-preset-id"

SORTS = [
    ("recent", "最近修改"),
    ("name", "名字 A→Z"),
    ("used", "用得最多"),
    ("created", "最近创建"),
]

THUMB_SIZES = [("S", 118, 76), ("M", 150, 96), ("L", 190, 122)]

#: 窗口标题（想改署名就改这里，别散在各处）
WINDOW_TITLE = "节点预设库 —— 阿龙制作"


def exec_menu(menu, pos):
    """弹出菜单：Qt5 叫 exec_()，Qt6 叫 exec()。"""
    for name in ("exec_", "exec"):
        method = getattr(menu, name, None)
        if method is None:
            continue
        try:
            return method(pos)
        except (TypeError, AttributeError):                   # noqa: BLE001
            continue
    return None


def human_time(value):
    """把时间戳 / 字符串变成 '10-18 18:30' 这种短格式。"""
    if not value:
        return "—"
    if isinstance(value, (int, float)):
        try:
            value = time.strftime("%m-%d %H:%M", time.localtime(float(value)))
        except Exception:                                     # noqa: BLE001
            value = str(value)
    text = str(value)
    return text.replace("T", " ")[:16]


# ================================================================ 主窗口
class NodePresetWindow(QtWidgets.QMainWindow):
    """节点预设库主窗口。"""

    # ---- 搜索 / 过滤 / 视图
    searchChanged = Signal(str)
    sortChanged = Signal(str)
    viewModeChanged = Signal(str)
    scopeChanged = Signal(dict)
    # ---- 预设操作
    presetActivated = Signal(str)            # 双击 = 放到当前层级
    presetDragOut = Signal(str)              # 从列表拖出去
    presetContextMenu = Signal(str, QtCore.QPoint)
    actionRequested = Signal(str, str)       # (动作, 预设id)
    # ---- 编辑
    nameEdited = Signal(str, str)
    descEdited = Signal(str, str)
    tagsEdited = Signal(str, list)
    favoriteToggled = Signal(str, bool)
    folderMoved = Signal(str, str)           # (预设id, 文件夹id)
    # ---- 保存
    createRequested = Signal(dict)           # 创建框点了保存（含名字/简介/分类/预览）
    editRequested = Signal(dict)             # 编辑框点了保存（多一个 "id"，改的是已有预设）
    filesDropped = Signal(list)              # 从资源管理器拖文件进来（.npreset / 图片…）
    # ---- 分类树
    treeContextMenu = Signal(str, str, QtCore.QPoint)   # (kind, id, 全局坐标)
    newFolderRequested = Signal()                       # 树上「＋ 文件夹」按钮
    folderRenamed = Signal(str, str)                    # (文件夹id, 新名字)
    # ---- 设置菜单
    settingsAction = Signal(str)

    def __init__(self, parent=None):
        super(NodePresetWindow, self).__init__(parent)
        self.setWindowTitle(WINDOW_TITLE)
        self.resize(1080, 700)
        self.setMinimumSize(900, 600)

        self.previews = PreviewStore()
        self._presets = []
        self._folders = []
        self._scope = {"kind": "all", "value": ""}
        self._sort = "recent"
        self._grid = True
        self._search = ""
        self._show_empty = False
        self._thumb_index = 1
        self._updating = False
        self.filter_fn = None                # controller 可以塞自己的搜索实现
        self.context_provider = None         # controller 塞一个"当前层级是什么"的函数
        self.can_create = None               # controller 塞一个"现在能不能存"的检查
        self.screenshot_provider = None      # controller 塞"截当前视口"的实现
        self.suggested_context = ""          # controller 可以设（当前 pwd 的层级）
        self.suggested_folder = ""           # 同上（想默认归到某个文件夹）
        self._drop_busy = False              # 防抖：一次拖拽只弹一次框
        self._last_drag_formats = []         # 上一次拖拽带的 MIME（排错用）
        self._renaming = None                # 树上正在用的就地改名框

        self._build_ui()
        self._connect()
        self.view.set_grid(True)
        self._refresh_view()

    # ============================================================ 构建
    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root = QtWidgets.QVBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 6)
        root.setSpacing(6)

        root.addLayout(self._build_top_bar())

        splitter = QtWidgets.QSplitter(enum_of(Qt, "Horizontal"))
        splitter.addWidget(self._build_tree())
        splitter.addWidget(self._build_center())
        splitter.addWidget(self._build_detail())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 0)
        splitter.setSizes([180, 600, 300])
        self.splitter = splitter
        root.addWidget(splitter, 1)

        self.status = QtWidgets.QLabel("")
        self.status.setObjectName("Hint")
        self.version_label = QtWidgets.QLabel("—")
        self.version_label.setObjectName("Hint")
        bar = QtWidgets.QHBoxLayout()
        bar.addWidget(self.status, 1)
        bar.addWidget(self.version_label, 0)
        root.addLayout(bar)

        # 拖拽提示层盖在 central 上，随窗口尺寸走（resizeEvent 里摆）
        self.drop_overlay = DropOverlay(central)
        self.drop_overlay.setGeometry(central.rect())
        self._install_drop_filter()
        self.setAcceptDrops(True)
        central.setAcceptDrops(True)

    # ---------------------------------------------------------- 顶栏
    def _build_top_bar(self):
        layout = QtWidgets.QHBoxLayout()
        layout.setSpacing(6)

        self.new_btn = QtWidgets.QToolButton()
        self.new_btn.setToolButtonStyle(
            enum_of(Qt, "ToolButtonTextBesideIcon"))
        self.new_btn.setIcon(icons.icon("plus", "#7FD3A0", 16, ui=True))
        self.new_btn.setIconSize(QtCore.QSize(16, 16))
        self.new_btn.setText("新建")
        self.new_btn.setMinimumWidth(78)
        self.new_btn.setToolTip(
            "把当前选中的节点存成预设（也可以直接把节点拖进这个窗口）")
        layout.addWidget(self.new_btn, 0)

        self.search_edit = QtWidgets.QLineEdit()
        self.search_edit.setPlaceholderText(
            "搜索名字 / 简介 / 标签 / 节点类型（拼音也行：ps 破碎、cs2 测试2）")
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.setMinimumWidth(320)
        layout.addWidget(self.search_edit, 1)

        self.sort_combo = QtWidgets.QComboBox()
        for key, text in SORTS:
            self.sort_combo.addItem(text, key)
        self.sort_combo.setFixedWidth(104)
        layout.addWidget(self.sort_combo)

        self.grid_btn = QtWidgets.QToolButton()
        self.grid_btn.setIcon(icons.icon("grid", "#C9D2DC", 18, ui=True))
        self.grid_btn.setToolTip("缩略图视图")
        self.grid_btn.setCheckable(True)
        self.grid_btn.setChecked(True)
        self.list_btn = QtWidgets.QToolButton()
        self.list_btn.setIcon(icons.icon("list", "#C9D2DC", 18, ui=True))
        self.list_btn.setToolTip("列表视图")
        self.list_btn.setCheckable(True)
        layout.addWidget(self.grid_btn)
        layout.addWidget(self.list_btn)

        self.settings_btn = QtWidgets.QToolButton()
        self.settings_btn.setIcon(icons.icon("settings", "#C9D2DC", 18, ui=True))
        self.settings_btn.setToolTip("设置 / 发布 / 更新")
        self.settings_btn.setPopupMode(
            enum_of(QtWidgets.QToolButton, "InstantPopup"))
        self.settings_btn.setMenu(self._build_settings_menu())
        layout.addWidget(self.settings_btn)
        return layout

    def _build_settings_menu(self):
        menu = QtWidgets.QMenu(self)
        items = [
            ("library_dir", "预设库目录…"),
            ("sep1", None),
            ("thumb_s", "缩略图：小"),
            ("thumb_m", "缩略图：中"),
            ("thumb_l", "缩略图：大"),
            ("toggle_empty", "显示空的层级"),
            ("sep2", None),
            ("publish", "发布到 Git…"),
            ("check_update", "检查更新"),
            ("sep3", None),
            ("backup", "备份整个预设库…"),
            ("import", "导入 .npreset…"),
            ("clear_cache", "清空缩略图缓存"),
        ]
        self._settings_actions = {}
        for key, text in items:
            if text is None:
                menu.addSeparator()
                continue
            action = menu.addAction(text)
            action.triggered.connect(
                lambda _c=False, k=key: self._on_settings_action(k))
            self._settings_actions[key] = action
        self._settings_actions["toggle_empty"].setCheckable(True)
        return menu

    def _on_settings_action(self, key):
        if key == "toggle_empty":
            self._show_empty = not self._show_empty
            self._settings_actions[key].setChecked(self._show_empty)
            self._rebuild_tree()
            return
        if key in ("thumb_s", "thumb_m", "thumb_l"):
            self._thumb_index = {"thumb_s": 0, "thumb_m": 1,
                                 "thumb_l": 2}[key]
            PresetDelegate.THUMB_W = THUMB_SIZES[self._thumb_index][1]
            PresetDelegate.THUMB_H = THUMB_SIZES[self._thumb_index][2]
            self.view.set_grid(self._grid)
            self._refresh_view()
            return
        self.settingsAction.emit(key)

    # ---------------------------------------------------------- 左：分类树
    def _build_tree(self):
        box = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(box)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        # 一个看得见的「新建文件夹」入口。以前只能靠右键层级行，
        # 库里还没文件夹时没人找得到（用户就是在这儿卡住的）。
        head = QtWidgets.QHBoxLayout()
        head.setContentsMargins(0, 0, 0, 0)
        head.setSpacing(4)
        head.addWidget(QtWidgets.QLabel("分类"), 1)
        new_folder = QtWidgets.QToolButton()
        new_folder.setText("＋ 文件夹")
        new_folder.setToolTip("在当前层级下新建一个文件夹（建完可以直接双击改名）")
        new_folder.setMinimumWidth(72)
        new_folder.clicked.connect(lambda: self.newFolderRequested.emit())
        head.addWidget(new_folder, 0)
        layout.addLayout(head)
        self.new_folder_button = new_folder

        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.setRootIsDecorated(True)
        self.tree.setIndentation(14)
        self.tree.setIconSize(QtCore.QSize(16, 16))
        # 第一列铺满宽度：不然只有文字那么宽算"行内"，点右边空白处右键
        # itemAt() 会返回 None，菜单（含「重命名」）就不弹了。
        try:
            self.tree.header().setStretchLastSection(True)
            self.tree.header().setSectionResizeMode(
                0, enum_of(QtWidgets.QHeaderView, "Stretch"))
        except Exception:                                     # noqa: BLE001
            pass
        # ⚠️ contextMenuPolicy 必须装在 QTreeWidget 自己身上。QAbstractScrollArea
        # 会把 viewport 收到的右键事件**转发给 scroll area**，所以装在 viewport 上
        # 反而不触发（实测）。信号里的 pos 是 viewport 坐标，itemAt(pos) 对得上。
        self.tree.setContextMenuPolicy(
            enum_of(Qt, "CustomContextMenu"))
        self.tree.customContextMenuRequested.connect(self._on_tree_menu)
        self.tree.setEditTriggers(
            enum_of(QtWidgets.QAbstractItemView, "NoEditTriggers"))
        self.tree.itemDoubleClicked.connect(self._on_tree_double_click)
        self.tree.setAcceptDrops(True)
        self.tree.setDragEnabled(True)
        self.tree.setDropIndicatorShown(True)
        self.tree.setSelectionMode(
            enum_of(QtWidgets.QAbstractItemView, "SingleSelection"))
        # 滚动了就把改名框收掉，别让它飘在别的行上
        try:
            self.tree.verticalScrollBar().valueChanged.connect(
                lambda _v: self.end_rename())
        except Exception:                                     # noqa: BLE001
            pass
        layout.addWidget(self.tree, 1)
        return box

    def _on_tree_menu(self, pos):
        item = self.tree.itemAt(pos)
        if item is None:
            return
        kind = item.data(0, _ROLE_KIND) or ""
        value = item.data(0, _ROLE_VALUE) or ""
        self.treeContextMenu.emit(kind, value,
                                  self.tree.viewport().mapToGlobal(pos))

    def _on_tree_double_click(self, item, _column):
        """双击文件夹 = 就地改名（用户要的）；双击别的行保持展开/收起。"""
        if item is None:
            return
        if (item.data(0, _ROLE_KIND) or "") != "folder":
            return
        self.start_rename(item.data(0, _ROLE_VALUE) or "")

    # ---------------------------------------------------------- 就地改名
    def find_tree_item(self, kind, value):
        root = self.tree.invisibleRootItem()

        def walk(parent):
            for index in range(parent.childCount()):
                child = parent.child(index)
                if ((child.data(0, _ROLE_KIND) or "") == kind
                        and str(child.data(0, _ROLE_VALUE) or "") == str(value or "")):
                    return child
                found = walk(child)
                if found is not None:
                    return found
            return None

        return walk(root)

    def select_folder(self, folder_id):
        """树上选中并展开这个文件夹（刚建完时让人一眼看见它）。"""
        if not folder_id:
            return False
        item = self.find_tree_item("folder", folder_id)
        if item is None:
            return False
        try:
            parent = item.parent()
            while parent is not None:
                parent.setExpanded(True)
                parent = parent.parent()
            self.tree.setCurrentItem(item)
            self.tree.scrollToItem(item)
            return True
        except Exception:                                 # noqa: BLE001
            return False

    def start_rename(self, folder_id):
        """在树上给这个文件夹开一个改名框。找不到（或已经在改）返回 False。"""
        if not folder_id:
            return False
        item = self.find_tree_item("folder", folder_id)
        if item is None:
            return False
        name = ""
        for folder in self._folders:
            if folder.get("id") == folder_id:
                name = folder.get("name") or ""
                break
        if not name:
            # 树上的文字是「名字 (数量)」，退化情况把尾巴去掉
            text = item.text(0) or ""
            name = text.rsplit(" (", 1)[0] if text.endswith(")") else text
        return self._begin_inline_rename(item, folder_id, name)

    def _begin_inline_rename(self, item, folder_id, name):
        self.end_rename()
        try:
            self.tree.scrollToItem(item)
            rect = self.tree.visualItemRect(item)
        except Exception:                                     # noqa: BLE001
            return False
        if rect.width() <= 0 or rect.height() <= 0:
            return False
        try:
            editor = InlineRename(self.tree.viewport())
            editor.setGeometry(rect.adjusted(2, 0, -4, 0))
            editor.setText(name)
            editor.setToolTip("回车确认，Esc 取消")
            # 跟主题走：用控件自己的调色板，深色/浅色都对得上，别用写死的颜色
            try:
                palette = self.tree.palette()
                base = palette.color(enum_of(QtGui.QPalette, "Base")).name()
                text = palette.color(enum_of(QtGui.QPalette, "Text")).name()
                accent = palette.color(
                    enum_of(QtGui.QPalette, "Highlight")).name()
                editor.setStyleSheet(
                    "QLineEdit{background:%s;color:%s;border:1px solid %s;"
                    "border-radius:3px;padding:0 3px;}" % (base, text, accent))
            except Exception:                                 # noqa: BLE001
                pass
            editor.committed.connect(
                lambda text, fid=folder_id: self._commit_rename(fid, text))
            editor.cancelled.connect(self._clear_rename)
            editor.show()
            editor.raise_()
            editor.setFocus()
            editor.selectAll()
            self._renaming = editor
        except Exception:                                     # noqa: BLE001
            return False
        return True

    def _commit_rename(self, folder_id, text):
        self._renaming = None
        text = str(text or "").strip()
        if text:
            self.folderRenamed.emit(folder_id, text)

    def _clear_rename(self, *_args):
        self._renaming = None

    def end_rename(self):
        """收起正在用的改名框（树要重建 / 换选中项时调用）。"""
        editor = getattr(self, "_renaming", None)
        self._renaming = None
        if editor is None:
            return
        try:
            editor.cancel()
        except Exception:                                     # noqa: BLE001
            pass

    # ---------------------------------------------------------- 中：卡片
    def _build_center(self):
        box = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(box)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self.view = PresetView()
        self.view.previews = self.previews
        self.view.delegate.previews = self.previews
        layout.addWidget(self.view, 1)
        return box

    # ---------------------------------------------------------- 右：详情
    def _build_detail(self):
        box = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(box)
        layout.setContentsMargins(0, 0, 4, 0)
        layout.setSpacing(8)

        self.detail_preview = PreviewLabel()
        self.detail_preview.setFixedHeight(164)
        layout.addWidget(self.detail_preview)

        layout.addWidget(QtWidgets.QLabel("名字"))
        self.detail_name = QtWidgets.QLineEdit()
        self.detail_name.setPlaceholderText("给这个预设起个名字")
        layout.addWidget(self.detail_name)

        layout.addWidget(QtWidgets.QLabel("简介"))
        self.detail_desc = QtWidgets.QPlainTextEdit()
        self.detail_desc.setPlaceholderText("这堆节点是干嘛的、怎么用、注意什么…")
        self.detail_desc.setFixedHeight(96)
        layout.addWidget(self.detail_desc)

        layout.addWidget(QtWidgets.QLabel("标签"))
        self.detail_tags = TagBar()
        layout.addWidget(self.detail_tags)

        row = QtWidgets.QHBoxLayout()
        row.setSpacing(6)
        self.detail_dot = QtWidgets.QLabel("")
        self.detail_dot.setFixedSize(18, 18)
        self.detail_context = QtWidgets.QLabel("—")
        row.addWidget(self.detail_dot)
        row.addWidget(self.detail_context, 1)
        self.detail_folder = QtWidgets.QComboBox()
        self.detail_folder.setMinimumWidth(120)
        self.detail_folder.setToolTip("这个预设归到哪个文件夹（按层级过滤）")
        row.addWidget(self.detail_folder)
        layout.addLayout(row)

        self.detail_meta = QtWidgets.QLabel("—")
        self.detail_meta.setObjectName("Hint")
        self.detail_meta.setWordWrap(True)
        layout.addWidget(self.detail_meta)

        self.fav_btn = QtWidgets.QPushButton("☆ 收藏")
        self.fav_btn.setCheckable(True)
        layout.addWidget(self.fav_btn)

        grid = QtWidgets.QGridLayout()
        grid.setSpacing(4)
        self.btn_apply = QtWidgets.QPushButton("放到当前层级")
        self.btn_apply.setObjectName("Accent")
        self.btn_preview = QtWidgets.QPushButton("改预览图")
        self.btn_shot = QtWidgets.QPushButton("截当前视口")
        self.btn_shot.setToolTip(
            "抓 SceneViewer 那块屏幕像素存成预览图。\n"
            "视口被别的窗口挡住时会连挡住的东西一起截进去（Houdini 前台时最准）。")
        self.btn_export = QtWidgets.QPushButton("导出")
        self.btn_dup = QtWidgets.QPushButton("复制副本")
        self.btn_del = QtWidgets.QPushButton("删除")
        grid.addWidget(self.btn_apply, 0, 0, 1, 2)
        grid.addWidget(self.btn_preview, 1, 0)
        grid.addWidget(self.btn_shot, 1, 1)
        grid.addWidget(self.btn_export, 2, 0)
        grid.addWidget(self.btn_dup, 2, 1)
        grid.addWidget(self.btn_del, 3, 0, 1, 2)
        layout.addLayout(grid)
        layout.addStretch(1)
        return box

    # ============================================================ 信号连线
    def _connect(self):
        self.search_edit.textChanged.connect(self._on_search)
        self.sort_combo.currentIndexChanged.connect(self._on_sort)
        self.grid_btn.toggled.connect(self._on_grid_toggled)
        self.list_btn.toggled.connect(self._on_list_toggled)

        self.tree.itemSelectionChanged.connect(self._on_tree_select)
        self.view.itemSelectionChanged.connect(self._on_view_select)
        self.view.itemDoubleClicked.connect(self._on_view_activate)
        self.view.dragOut.connect(self.presetDragOut.emit)
        self.view.contextMenu.connect(self.presetContextMenu.emit)

        self.new_btn.clicked.connect(lambda: self.open_create_dialog())

        self.detail_name.editingFinished.connect(self._on_name_edited)
        self.detail_desc.textChanged.connect(self._on_desc_edited)
        self.detail_tags.tagsChanged.connect(self._on_tags_edited)
        self.detail_folder.currentIndexChanged.connect(self._on_folder_combo)
        self.fav_btn.toggled.connect(self._on_fav_toggled)

        self.btn_apply.clicked.connect(
            lambda: self._emit_action("apply"))
        self.btn_preview.clicked.connect(
            lambda: self._emit_action("preview_file"))
        self.btn_shot.clicked.connect(
            lambda: self._emit_action("preview_shot"))
        self.btn_export.clicked.connect(lambda: self._emit_action("export"))
        self.btn_dup.clicked.connect(lambda: self._emit_action("duplicate"))
        self.btn_del.clicked.connect(lambda: self._emit_action("delete"))

    def _emit_action(self, action):
        pid = self.current_preset_id()
        if pid:
            self.actionRequested.emit(action, pid)

    # ============================================================ 整窗接拖拽
    def _install_drop_filter(self):
        """在 QApplication 上挂事件过滤器。

        为什么不用逐个子控件的 setAcceptDrops：
        界面里控件太多（树、卡片视图、标签…），逐个开太脆，而且 Houdini 拖出来
        的拖拽在子控件上常常直接被拒。挂到 app 层后，只要落在本窗口范围内就拦下，
        跟具体是哪个控件无关 —— 这就是用户要的"拖到哪里都算"。
        """
        app = QtWidgets.QApplication.instance()
        if app is None:
            self._drop_app = None
            return
        try:
            app.installEventFilter(self)
        except Exception:                                     # noqa: BLE001
            pass
        self._drop_app = app

    def _drag_event_types(self):
        cached = getattr(self, "_drag_types", None)
        if cached is not None:
            return cached
        try:
            types = tuple(enum_of(QtCore.QEvent, name) for name in
                          ("DragEnter", "DragMove", "DragLeave", "Drop"))
        except Exception:                                     # noqa: BLE001
            types = ()
        self._drag_types = types
        return types

    def _owns_drop_target(self, widget):
        """这个控件是不是本窗口里的（对话框是独立窗口，不算）。"""
        if widget is None:
            return False
        try:
            if widget.window() is not self:
                return False
            return widget is self or self.isAncestorOf(widget)
        except Exception:                                     # noqa: BLE001
            return False

    def _drop_passthrough(self, widget):
        """分类树现在也能接拖拽了（落在文件夹上就默认归那个文件夹），
        所以不再按控件排除；只在"这是本工具自己的卡片拖拽"时才放行给控件自己处理。"""
        return False

    def _is_internal_drag(self, event):
        """本工具自己发起的拖拽（比如以后把卡片拖到树上归类）走 MIME，别拦。"""
        try:
            mime = event.mimeData()
        except Exception:                                     # noqa: BLE001
            return False
        try:
            return bool(mime) and mime.hasFormat(_MIME_PRESET)
        except Exception:                                     # noqa: BLE001
            return False

    @staticmethod
    def _mime_formats(event):
        """这次拖拽带了哪些 MIME 格式（调试/识别用）。"""
        try:
            mime = event.mimeData()
        except Exception:                                     # noqa: BLE001
            return []
        if mime is None:
            return []
        try:
            return [str(f) for f in mime.formats()]
        except Exception:                                     # noqa: BLE001
            return []

    def _dropped_files(self, event):
        """拖进来的是不是文件（从资源管理器拖的）。返回本地路径列表。

        这条必须判在"当成节点拖进来"之前：不然往窗口里拖一个 .npreset，
        会当成"拖节点进来"弹创建框，用户一脸问号。

        ⚠️ 但反过来更危险：Houdini 从网络编辑器往外拖节点时也**可能**带
        uri-list（拖到桌面能存成 .cpio 的就是它）。所以先扫一遍 MIME 里有没有
        houdini 字样的格式，有就老老实实当节点拖放处理。
        """
        formats = self._mime_formats(event)
        self._last_drag_formats = formats
        if any("houdini" in f.lower() for f in formats):
            return []
        try:
            mime = event.mimeData()
        except Exception:                                     # noqa: BLE001
            return []
        if mime is None:
            return []
        try:
            if not mime.hasUrls():
                return []
        except Exception:                                     # noqa: BLE001
            return []
        paths = []
        try:
            for url in mime.urls():
                local = url.toLocalFile() if hasattr(url, "toLocalFile") else ""
                if local:
                    paths.append(str(local))
        except Exception:                                     # noqa: BLE001
            return []
        return paths

    def _file_drop_hint(self, paths):
        """拖进来的文件 → 该显示什么提示。返回 (主文案, 副文案, 要不要接)。"""
        if not paths:
            return "", "", False
        lower = [p.lower() for p in paths]
        if any(p.endswith(".npreset") for p in lower):
            return ("松开鼠标，导入这些预设", "会解包进当前预设库，不会覆盖同名的", True)
        images = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")
        if any(p.endswith(images) for p in lower):
            if self.current_preset_id():
                return ("松开鼠标，当预览图",
                        "会给当前选中的那个预设换预览图", True)
            return ("松开鼠标，当预览图",
                    "还没选预设，松手后会提示你先选一张卡片", True)
        # 认不出来的文件：**不拦**，交给下面的"当成 Houdini 节点拖放"处理。
        # 宁可让用户多看到一个创建框，也不能把"从 Houdini 拖节点进来"这条主路堵死。
        return "", "", False

    def _tree_hint(self):
        """拖放落点在分类树上时，取出对应的层级 / 文件夹，作为创建框的默认值。"""
        try:
            pos = self.tree.viewport().mapFromGlobal(QtGui.QCursor.pos())
            item = self.tree.itemAt(pos)
        except Exception:                                     # noqa: BLE001
            return "", ""
        if item is None:
            return "", ""
        kind = item.data(0, _ROLE_KIND) or ""
        value = item.data(0, _ROLE_VALUE) or ""
        if kind == "context":
            return value, ""
        if kind == "folder":
            return "", value
        return "", ""

    def eventFilter(self, obj, event):                        # noqa: N802
        try:
            etype = event.type()
        except Exception:                                     # noqa: BLE001
            return False
        types = self._drag_event_types()
        if not types or etype not in types:
            return False
        if not isinstance(obj, QtWidgets.QWidget):
            return False
        if not self._owns_drop_target(obj) or self._drop_passthrough(obj):
            return False
        if self._is_internal_drag(event):
            return False

        # ---- 从资源管理器拖文件进来：走导入 / 换预览图，别当成"拖节点"
        files = self._dropped_files(event)
        title, sub, is_file = self._file_drop_hint(files)
        if files and is_file:
            if etype == leave:
                self._set_drop_hot(False)
                return True
            self._set_drop_hot(True)
            try:
                self.drop_overlay.set_text(title, sub)
            except Exception:                                 # noqa: BLE001
                pass
            self._accept_drag(event)
            if etype == drop:
                self._set_drop_hot(False)
                self._reset_drop_text()
                QtCore.QTimer.singleShot(
                    0, lambda: self.filesDropped.emit(files))
            return True

        enter, move, leave, drop = types
        if etype == enter:
            self._set_drop_hot(True)
            self._accept_drag(event)
            return True
        if etype == move:
            self._set_drop_hot(True)
            self._accept_drag(event)
            return True
        if etype == leave:
            self._set_drop_hot(False)
            return True

        # ---- Drop：**不要**在这里同步弹模态框
        # Windows 上拖拽还处在 OLE 的拖拽循环里，drop 里直接 exec 模态框会把
        # 整个拖拽循环卡住（表现为界面假死）。丢给事件循环下一步再弹。
        self._set_drop_hot(False)
        self._accept_drag(event)
        context, folder_id = self._tree_hint()
        self._queue_create_from_drop(context, folder_id)
        return True

    def _accept_drag(self, event):
        for name in ("acceptProposedAction", "accept"):
            method = getattr(event, name, None)
            if method is None:
                continue
            try:
                method()
                return
            except Exception:                                 # noqa: BLE001
                continue

    def _set_drop_hot(self, hot):
        overlay = getattr(self, "drop_overlay", None)
        if overlay is None:
            return
        try:
            overlay.setGeometry(self.centralWidget().rect())
            overlay.set_hot(hot)
        except Exception:                                     # noqa: BLE001
            pass

    def _reset_drop_text(self):
        """把遮罩文案恢复成默认的（拖节点进来那句）。"""
        overlay = getattr(self, "drop_overlay", None)
        if overlay is None:
            return
        try:
            overlay.set_text("松开鼠标，保存为预设",
                             "接着会弹出一个框，填名字 / 简介 / 放到哪个分类")
        except Exception:                                     # noqa: BLE001
            pass

    def _queue_create_from_drop(self, context="", folder_id=""):
        if self._drop_busy:
            return
        self._drop_busy = True

        def run():
            self._drop_busy = False
            self.open_create_dialog(context=context, folder_id=folder_id,
                                    from_drop=True)

        try:
            QtCore.QTimer.singleShot(0, run)
        except Exception:                                     # noqa: BLE001
            run()

    def resizeEvent(self, event):                             # noqa: N802
        try:
            super(NodePresetWindow, self).resizeEvent(event)
        except Exception:                                     # noqa: BLE001
            pass
        overlay = getattr(self, "drop_overlay", None)
        central = self.centralWidget()
        if overlay is not None and central is not None:
            overlay.setGeometry(central.rect())

    # ============================================================ 创建框
    def _scope_context(self):
        """当前树的选中位置 → 建议的层级 / 文件夹。"""
        scope = dict(self._scope or {})
        kind = scope.get("kind")
        value = scope.get("value") or ""
        if kind == "context":
            return value, ""
        if kind == "unfiled":
            return value, ""
        if kind == "folder":
            for folder in self._folders:
                if folder.get("id") == value:
                    return contexts.key_of(folder.get("context")), value
        return "", ""

    def open_create_dialog(self, context=None, folder_id=None,
                          hint="", from_drop=False, preset=None):
        """弹创建框；返回填好的 dict（取消则返回 None）。"""
        scope_context, scope_folder = self._scope_context()
        if not context and self.context_provider is not None:
            try:
                context = self.context_provider() or ""
            except Exception:                                 # noqa: BLE001
                context = ""
        if not context:
            context = self.suggested_context or scope_context
        if not folder_id:
            folder_id = self.suggested_folder or scope_folder
        if not preset and not from_drop and self.can_create is not None:
            try:
                if not self.can_create():
                    return None
            except Exception:                                 # noqa: BLE001
                pass
        if not hint:
            if preset:
                hint = "改完点保存，节点内容不会动"
            elif from_drop:
                hint = "刚拖进来的节点会被存进这个预设"
            else:
                hint = "当前选中的节点会被存进这个预设"

        dialog = CreatePresetDialog(self, folders=self._folders,
                                    context=context, folder_id=folder_id,
                                    hint=hint,
                                    screenshot_provider=self.screenshot_provider,
                                    title="编辑预设信息" if preset else "保存为预设")
        if preset:
            dialog.set_values(preset)
        accepted = dialog.exec_dialog()
        data = dialog.values() if accepted else None
        try:
            dialog.deleteLater()
        except Exception:                                     # noqa: BLE001
            pass
        if not data:
            self.set_status("取消创建")
            return None
        if preset and (preset.get("id") or ""):
            data["id"] = preset["id"]
            self.editRequested.emit(data)
        else:
            self.createRequested.emit(data)
        return data

    # ============================================================ 对外数据接口
    def set_presets(self, presets):
        """灌入预设列表（每项是一个 dict）。"""
        self._presets = [p for p in (presets or []) if isinstance(p, dict)]
        for item in self._presets:
            item["context_label"] = contexts.label_of(item.get("context"))
        self._rebuild_tree()
        self._refresh_view()

    def set_catalog(self, folders):
        """灌入自定义文件夹列表（每项 dict：id/name/context/parent/color/shape）。"""
        self._folders = [f for f in (folders or []) if isinstance(f, dict)]
        self._rebuild_tree()

    def set_status(self, text):
        self.status.setText(str(text or ""))

    def set_version(self, text):
        self.version_label.setText(str(text or "—"))

    def set_detail_enabled(self, enabled):
        for widget in (self.detail_name, self.detail_desc, self.detail_tags,
                       self.detail_folder, self.fav_btn, self.btn_apply,
                       self.btn_preview, self.btn_shot, self.btn_export,
                       self.btn_dup, self.btn_del):
            widget.setEnabled(bool(enabled))

    # ============================================================ 分类树
    def _rebuild_tree(self):
        self.end_rename()                # 树要重建了，改名框先收掉（否则挂在旧行上）
        sel = self._scope
        self._updating = True
        try:
            self.tree.blockSignals(True)
            self.tree.clear()

            total = len(self._presets)
            fav = len([p for p in self._presets if p.get("favorite")])
            self._add_tree_item("全部 (%d)" % total, "all", "",
                                icons.icon("dots", "#C9D2DC", 16))
            self._add_tree_item("★ 收藏 (%d)" % fav, "fav", "",
                                icons.icon("star", "#F2C94C", 16))
            self._add_tree_item("最近使用", "recent", "",
                                icons.icon("bolt", "#8FB7E8", 16))

            groups = {}
            for item in self._presets:
                key = contexts.key_of(item.get("context"))
                groups.setdefault(key, []).append(item)
            # ⚠️ 光有文件夹、还没预设的层级也必须出现。
            # 否则：在 GEO 下新建文件夹 → 库里还没有 GEO 预设 → 整个 GEO 行不显示
            # → 用户刚建的文件夹凭空消失，右键也找不到它（出过这个 bug）。
            for folder in self._folders or []:
                key = contexts.key_of(folder.get("context"))
                if key not in groups:
                    groups[key] = []

            keys = sorted(groups.keys(), key=contexts.sort_key)
            if self._show_empty:
                for key in contexts.ORDER:
                    if key not in keys:
                        keys.append(key)
                keys = sorted(keys, key=contexts.sort_key)

            for key in keys:
                items = groups.get(key, [])
                color = contexts.COLORS.get(key, contexts.DEFAULT_COLOR)
                node = self._add_tree_item(
                    "%s (%d)" % (contexts.label_of(key), len(items)),
                    "context", key, icons.icon("cube", color, 14))
                for folder in self._folders_of(key, None):
                    count = self._count_in_folder(folder["id"])
                    child = self._add_tree_item(
                        "%s (%d)" % (folder.get("name") or "?", count),
                        "folder", folder["id"],
                        icons.icon(folder.get("shape") or "folder",
                                   folder.get("color") or "#7C8794", 14),
                        parent=node)
                    self._add_subfolders(child, key, folder["id"])
                unfiled = len([p for p in items
                               if not (p.get("folder_id") or "")])
                if unfiled:
                    self._add_tree_item(
                        "未分类 (%d)" % unfiled, "unfiled", key,
                        icons.icon("folder", "#5C6672", 14), parent=node)
                node.setExpanded(True)

            self._restore_tree_selection(sel)
        finally:
            self.tree.blockSignals(False)
            self._updating = False

    def _add_subfolders(self, parent_item, context, parent_id):
        for folder in self._folders_of(context, parent_id):
            count = self._count_in_folder(folder["id"])
            child = self._add_tree_item(
                "%s (%d)" % (folder.get("name") or "?", count),
                "folder", folder["id"],
                icons.icon(folder.get("shape") or "folder",
                           folder.get("color") or "#7C8794", 14),
                parent=parent_item)
            self._add_subfolders(child, context, folder["id"])

    def _folders_of(self, context, parent_id):
        out = []
        for folder in self._folders:
            if contexts.key_of(folder.get("context")) != context:
                continue
            if (folder.get("parent") or "") != (parent_id or ""):
                continue
            out.append(folder)
        out.sort(key=lambda f: (int(f.get("order") or 0),
                                str(f.get("name") or "")))
        return out

    def _count_in_folder(self, folder_id):
        ids = self._folder_ids_below(folder_id)
        return len([p for p in self._presets
                    if (p.get("folder_id") or "") in ids])

    def _folder_ids_below(self, folder_id):
        ids = {folder_id}
        for folder in self._folders:
            if (folder.get("parent") or "") == folder_id:
                ids |= self._folder_ids_below(folder["id"])
        return ids

    def _add_tree_item(self, text, kind, value, icon=None, parent=None):
        item = QtWidgets.QTreeWidgetItem([text])
        item.setData(0, _ROLE_KIND, kind)
        item.setData(0, _ROLE_VALUE, value)
        if icon is not None:
            item.setIcon(0, icon)
        # 提示语：这两条是"用户找不到入口"的直接解药
        tips = {
            "folder": "双击改名（回车确认，Esc 取消）· 右键：重命名 / 删除",
            "unfiled": "没放进任何文件夹的预设（这不是文件夹，不能改名）",
            "context": "右键可以在这个层级下新建文件夹",
        }
        tip = tips.get(kind, "")
        if tip:
            item.setToolTip(0, tip)
        if parent is None:
            self.tree.addTopLevelItem(item)
        else:
            parent.addChild(item)
        return item

    def _restore_tree_selection(self, scope):
        target = None
        root = self.tree.invisibleRootItem()

        def walk(parent):
            for idx in range(parent.childCount()):
                child = parent.child(idx)
                if (child.data(0, _ROLE_KIND) == scope.get("kind")
                        and child.data(0, _ROLE_VALUE) == scope.get("value")):
                    return child
                found = walk(child)
                if found is not None:
                    return found
            return None

        target = walk(root)
        if target is None:
            first = self.tree.topLevelItem(0)
            if first is not None:
                target = first
                self._scope = {"kind": "all", "value": ""}
        if target is not None:
            self.tree.setCurrentItem(target)

    def _on_tree_select(self):
        if self._updating:
            return
        item = self.tree.currentItem()
        if item is None:
            return
        kind = item.data(0, _ROLE_KIND) or "all"
        value = item.data(0, _ROLE_VALUE) or ""
        self._scope = {"kind": kind, "value": value}
        self._refresh_view()
        self.scopeChanged.emit(dict(self._scope))

    # ============================================================ 过滤 / 排序
    def _on_search(self, text):
        self._search = str(text or "")
        self._refresh_view()
        self.searchChanged.emit(self._search)

    def _on_sort(self, _index):
        self._sort = self.sort_combo.currentData() or "recent"
        self._refresh_view()
        self.sortChanged.emit(self._sort)

    def _on_grid_toggled(self, checked):
        if self._updating:
            return
        self._updating = True
        self.list_btn.setChecked(not checked)
        self._updating = False
        self._grid = bool(checked)
        self.view.set_grid(self._grid)
        self._refresh_view()
        self.viewModeChanged.emit("grid" if self._grid else "list")

    def _on_list_toggled(self, checked):
        if self._updating:
            return
        self._updating = True
        self.grid_btn.setChecked(not checked)
        self._updating = False
        self._grid = not checked
        self.view.set_grid(self._grid)
        self._refresh_view()
        self.viewModeChanged.emit("grid" if self._grid else "list")

    def _in_scope(self, item):
        scope = self._scope
        kind = scope.get("kind")
        value = scope.get("value")
        if kind == "fav":
            return bool(item.get("favorite"))
        if kind == "recent":
            return (item.get("use_count") or 0) > 0
        if kind == "context":
            return contexts.key_of(item.get("context")) == value
        if kind == "folder":
            return (item.get("folder_id") or "") in self._folder_ids_below(value)
        if kind == "unfiled":
            return (not (item.get("folder_id") or "")
                    and contexts.key_of(item.get("context")) == value)
        return True

    def _matches(self, item, query):
        """本地兜底搜索。controller 可以通过 ui.filter_fn 换成 store 的实现。"""
        if not query:
            return 0
        query = query.strip().lower()
        if not query:
            return 0
        words = [w for w in query.split() if w]
        if not words:
            return 0
        score = 0
        for word in words:
            hit = 0
            for field, weight in (("name", 10), ("tags", 6),
                                  ("node_types", 4), ("desc", 2)):
                raw = item.get(field)
                if isinstance(raw, (list, tuple)):
                    text = " ".join(str(x) for x in raw)
                else:
                    text = str(raw or "")
                if word in text.lower():
                    hit = max(hit, weight)
            for field, weight in (("py_abbr", 8), ("py_full", 8),
                                  ("py_abbr_tags", 5)):
                text = str(item.get(field) or "").lower()
                if text and word in text:
                    hit = max(hit, int(weight * 0.8))
            # 逐字匹配：跟 pinyin_index._word_hit 保持同一套（数字/英文要能中）
            if hit < 8:
                try:
                    from . import pinyin_index
                    if pinyin_index.seq_match(str(item.get("name") or ""),
                                              word):
                        hit = max(hit, 8)
                except Exception:                         # noqa: BLE001
                    pass
            if not hit:
                return 0
            score += hit
        return score

    def _sorted(self, items):
        key = self._sort
        if key == "name":
            return sorted(items, key=lambda p: str(p.get("name") or "").lower())
        if key == "used":
            return sorted(items, key=lambda p: -(int(p.get("use_count") or 0)))
        if key == "created":
            return sorted(items, key=lambda p: str(p.get("created") or ""),
                          reverse=True)
        return sorted(items, key=lambda p: str(p.get("modified") or ""),
                      reverse=True)

    def _visible_items(self):
        items = [p for p in self._presets if self._in_scope(p)]
        if self.filter_fn is not None:
            try:
                items = [p for p in items if self.filter_fn(p, self._search)]
            except Exception:                                 # noqa: BLE001
                pass
        else:
            scored = []
            for item in items:
                score = self._matches(item, self._search)
                if score:
                    scored.append((score, item))
            items = [item for _s, item in sorted(
                scored, key=lambda pair: -pair[0])] if self._search else items
        return self._sorted(items)

    def _refresh_view(self):
        items = self._visible_items()
        self.view.blockSignals(True)
        try:
            self.view.clear()
            for item in items:
                entry = QtWidgets.QListWidgetItem()
                entry.setData(_ROLE_DATA, item)
                entry.setSizeHint(QtCore.QSize(
                    PresetDelegate.THUMB_W + 12,
                    PresetDelegate.CARD_H if self._grid
                    else PresetDelegate.ROW_H))
                entry.setToolTip(self._tooltip(item))
                self.view.addItem(entry)
        finally:
            self.view.blockSignals(False)
        if self._presets:
            self.view.empty_text = ("没有符合条件的预设。\n换个关键词，"
                                    "或者点左边的「全部」。")
        else:
            self.view.empty_text = ("还没有预设。\n把网络编辑器里选中的节点拖进这个窗口，"
                                    "或者点左上角「＋ 新建」。")
        self.view.viewport().update()
        self.status.setText("共 %d 个预设，当前显示 %d 个"
                            % (len(self._presets), len(items)))
        # 刷新 = 重建列表，之前的选中对象已经没了。要么重新选中，要么把右侧清掉，
        # 不然会出现"列表里没选中任何东西，右边却还显示着上一个预设"的鬼影。
        if not items or self.view.currentItem() is None:
            self._show_detail(None)

    def _tooltip(self, item):
        lines = [item.get("name") or "(未命名)"]
        if item.get("context_label"):
            lines.append("层级：%s · %d 个节点"
                         % (item["context_label"], item.get("node_count") or 0))
        types = item.get("node_types") or []
        if types:
            lines.append("类型：" + ", ".join(str(t) for t in types[:6])
                         + (" …" if len(types) > 6 else ""))
        if item.get("desc"):
            lines.append("")
            lines.append(str(item["desc"])[:200])
        return "\n".join(lines)

    # ============================================================ 选中 / 详情
    def current_preset_id(self):
        item = self.view.currentItem()
        if item is None:
            return ""
        data = item.data(_ROLE_DATA)
        return (data or {}).get("id", "") if isinstance(data, dict) else ""

    def current_preset(self):
        item = self.view.currentItem()
        if item is None:
            return None
        data = item.data(_ROLE_DATA)
        return data if isinstance(data, dict) else None

    def selected_ids(self):
        """当前选中的卡片 id 列表（按住 Shift 拖动框选时会有多个）。"""
        ids = []
        for item in self.view.selectedItems():
            data = item.data(_ROLE_DATA)
            if isinstance(data, dict) and data.get("id"):
                ids.append(data["id"])
        if not ids:
            current = self.current_preset_id()
            if current:
                ids.append(current)
        return ids

    def select_preset(self, preset_id):
        """按 id 选中一张卡片（建完预设 / 刷新后回到原选中项用）。"""
        if not preset_id:
            return False
        for index in range(self.view.count()):
            item = self.view.item(index)
            data = item.data(_ROLE_DATA)
            if isinstance(data, dict) and data.get("id") == preset_id:
                self.view.setCurrentItem(item)
                self.view.scrollToItem(item)
                return True
        return False

    def _on_view_select(self):
        self._show_detail(self.current_preset())

    def _on_view_activate(self, _item):
        pid = self.current_preset_id()
        if pid:
            self.presetActivated.emit(pid)

    def _show_detail(self, data):
        self._updating = True
        try:
            self.detail_preview.set_preview((data or {}).get("preview"))
            self.detail_name.setText((data or {}).get("name") or "")
            self.detail_desc.setPlainText((data or {}).get("desc") or "")
            self.detail_tags.set_tags((data or {}).get("tags") or [])
            self.fav_btn.setChecked(bool((data or {}).get("favorite")))

            key = contexts.key_of((data or {}).get("context"))
            color = contexts.COLORS.get(key, contexts.DEFAULT_COLOR)
            self.detail_dot.setPixmap(icons.pixmap("cube", color, 16))
            self.detail_context.setText(contexts.label_of(key))

            self.detail_folder.blockSignals(True)
            self.detail_folder.clear()
            self.detail_folder.addItem("（未分类）", "")
            for folder in self._folders:
                if contexts.key_of(folder.get("context")) != key:
                    continue
                self.detail_folder.addItem(
                    icons.icon(folder.get("shape") or "folder",
                               folder.get("color") or "#7C8794", 14),
                    folder.get("name") or "?", folder.get("id"))
            current = (data or {}).get("folder_id") or ""
            index = self.detail_folder.findData(current)
            self.detail_folder.setCurrentIndex(index if index >= 0 else 0)
            self.detail_folder.blockSignals(False)

            if data:
                types = data.get("node_types") or []
                self.detail_meta.setText(
                    "类型：%s\n来自：%s\n用了 %s 次 · 改于 %s"
                    % (", ".join(str(t) for t in types[:8]) or "—",
                       data.get("source_path") or "—",
                       data.get("use_count") or 0,
                       human_time(data.get("modified"))))
            else:
                self.detail_meta.setText("—")
            self.set_detail_enabled(bool(data))
        finally:
            self._updating = False

    # ============================================================ 详情编辑
    def _on_name_edited(self):
        if self._updating:
            return
        pid = self.current_preset_id()
        if pid:
            self.nameEdited.emit(pid, self.detail_name.text().strip())

    def _on_desc_edited(self):
        if self._updating:
            return
        pid = self.current_preset_id()
        if pid:
            self.descEdited.emit(pid, self.detail_desc.toPlainText())

    def _on_tags_edited(self, tags):
        if self._updating:
            return
        pid = self.current_preset_id()
        if pid:
            self.tagsEdited.emit(pid, list(tags))

    def _on_folder_combo(self, _index):
        if self._updating:
            return
        pid = self.current_preset_id()
        if pid:
            self.folderMoved.emit(pid, self.detail_folder.currentData() or "")

    def _on_fav_toggled(self, checked):
        if self._updating:
            return
        pid = self.current_preset_id()
        if pid:
            self.favoriteToggled.emit(pid, bool(checked))

    # ============================================================ 输入法
    # Houdini 会把 WA_InputMethodEnabled 关掉（关着就打不了中文）。
    # 具体原理和守卫实现都在 ime.py，这里只是接到主窗口（搜索框、
    # 右侧详情里的名字 / 简介 / 标签）上 —— 别再各写一份了。
    def _ime_widgets(self):
        return ime_widgets(self)

    def _enable_ime(self):
        enable_ime(ime_widgets(self))

    def _start_ime_guard(self):
        """show()/激活之后 Houdini 又会关掉，交给 ime.ImeGuard 盯着。"""
        install_ime_guard(self)

    def _on_ime_tick(self):
        guard = getattr(self, "_ime_guard_obj", None)
        if guard is not None:
            guard.tick()

    def showEvent(self, event):                               # noqa: N802
        try:
            super(NodePresetWindow, self).showEvent(event)
        except Exception:                                     # noqa: BLE001
            pass
        self._enable_ime()
        self._start_ime_guard()

    def event(self, ev):
        try:
            if ev.type() == enum_of(QtCore.QEvent, "WindowActivate"):
                self._enable_ime()
        except Exception:                                     # noqa: BLE001
            pass
        return super(NodePresetWindow, self).event(ev)

    # ============================================================ 杂项
    def preset_menu(self, preset_id, global_pos):
        """弹出卡片的右键菜单，返回被点的动作名（空串 = 没点）。"""
        # 右键点在"多选里的一张"时，删除/导出作用于整组
        try:
            selected = self.selected_ids()
        except Exception:                                     # noqa: BLE001
            selected = []
        batch = len(selected) if (preset_id in selected
                                  and len(selected) > 1) else 1
        if batch > 1:
            export_text = "导出选中的 %d 个为 .npreset" % batch
            delete_text = "删除选中的 %d 个" % batch
        else:
            export_text = "导出为 .npreset"
            delete_text = "删除"
        menu = QtWidgets.QMenu(self)
        actions = [
            ("apply", "放到当前层级"),
            ("apply_to", "放到…"),
            ("sep", None),
            ("rename", "重命名"),
            ("edit", "编辑信息…"),
            ("preview_file", "改预览图（选文件）"),
            ("preview_clip", "从剪贴板粘贴图片"),
            ("preview_shot", "截取当前视口"),
            ("sep", None),
            ("favorite", "收藏 / 取消收藏"),
            ("move_to", "移动到文件夹…"),
            ("update_content", "用当前选择更新内容"),
            ("sep", None),
            ("duplicate", "复制副本"),
            ("export", export_text),
            ("reveal", "在资源管理器中打开"),
            ("sep", None),
            ("delete", delete_text),
        ]
        table = {}
        for key, text in actions:
            if text is None:
                menu.addSeparator()
                continue
            table[key] = menu.addAction(text)
        picked = exec_menu(menu, global_pos)
        for key, action in table.items():
            if action is picked:
                return key
        return ""

    def folder_menu(self, global_pos):
        """文件夹的右键菜单。重命名 / 删除放最前面，别让人找。"""
        menu = QtWidgets.QMenu(self)
        table = {}
        for key, text in (("rename", "重命名"),
                          ("delete", "删除文件夹"),
                          ("sep", None),
                          ("new_sub", "新建子文件夹…"),
                          ("appearance", "改颜色 / 图标…")):
            if text is None:
                menu.addSeparator()
                continue
            table[key] = menu.addAction(text)
        picked = exec_menu(menu, global_pos)
        for key, action in table.items():
            if action is picked:
                return key
        return ""

    def context_menu(self, global_pos):
        menu = QtWidgets.QMenu(self)
        action = menu.addAction("新建文件夹")
        picked = exec_menu(menu, global_pos)
        return "new_folder" if picked is action else ""


__all__ = ["NodePresetWindow", "human_time", "SORTS", "THUMB_SIZES"]
