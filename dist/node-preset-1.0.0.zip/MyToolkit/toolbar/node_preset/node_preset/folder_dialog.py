# -*- coding: utf-8 -*-
"""文件夹编辑框（新建 / 改名 / 改色 / 改图标）。纯界面，不 import hou。

用户要求：文件夹可以自己创建、自己命名、可以加图标、可以换颜色，
图标统一形状只是颜色不同 —— 这里就是那个编辑器。
"""

from . import contexts, icons
from .ime import install_ime_guard
from .qt import QtCore, QtGui, QtWidgets, Qt, enum_of

_ALIGN_CENTER = enum_of(Qt, "AlignCenter")

#: 调色板（12 色，取 Houdini 节点色的手感）
PALETTE = [
    "#E0574A", "#E08A3C", "#D7B93C", "#8FB93C", "#4C9A5A", "#3CB8A0",
    "#4A90D9", "#5A7FB8", "#9B6BD6", "#C2699B", "#8A8F98", "#C9D2DC",
]


class FolderDialog(QtWidgets.QDialog):
    """返回 dict: name / context / parent / color / shape。"""

    def __init__(self, parent=None, folders=None, context="", parent_id="",
                 folder=None, title="新建文件夹", lock_context=False):
        super(FolderDialog, self).__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(380)
        self.setModal(True)
        self._folders = [f for f in (folders or []) if isinstance(f, dict)]
        self._folder = dict(folder or {})
        self._lock_context = lock_context or bool(folder)
        self._color = self._folder.get("color") or PALETTE[6]
        self._shape = self._folder.get("shape") or "folder"

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 10)
        layout.setSpacing(8)

        row = QtWidgets.QHBoxLayout()
        row.setSpacing(8)
        self.preview = QtWidgets.QLabel("")
        self.preview.setFixedSize(24, 24)
        row.addWidget(self.preview)
        self.name_edit = QtWidgets.QLineEdit(self._folder.get("name") or "")
        self.name_edit.setPlaceholderText("文件夹名字，比如：破碎 / 解算 / 输出")
        row.addWidget(self.name_edit, 1)
        layout.addLayout(row)

        form = QtWidgets.QGridLayout()
        form.setHorizontalSpacing(8)
        form.setVerticalSpacing(6)

        form.addWidget(QtWidgets.QLabel("层级"), 0, 0)
        self.context_combo = QtWidgets.QComboBox()
        for key in contexts.ORDER:
            self.context_combo.addItem(
                icons.icon("cube", contexts.COLORS.get(key, contexts.DEFAULT_COLOR), 14),
                contexts.label_of(key), key)
        index = self.context_combo.findData(contexts.key_of(context))
        self.context_combo.setCurrentIndex(max(0, index))
        self.context_combo.setEnabled(not self._lock_context)
        form.addWidget(self.context_combo, 0, 1)

        form.addWidget(QtWidgets.QLabel("上级"), 1, 0)
        self.parent_combo = QtWidgets.QComboBox()
        form.addWidget(self.parent_combo, 1, 1)
        layout.addLayout(form)

        layout.addWidget(QtWidgets.QLabel("颜色"))
        grid = QtWidgets.QGridLayout()
        grid.setSpacing(4)
        self._color_buttons = []
        for i, color in enumerate(PALETTE):
            button = QtWidgets.QToolButton()
            button.setFixedSize(24, 24)
            button.setCheckable(True)
            button.setToolTip(color)
            button.setStyleSheet(
                "QToolButton{background:%s;border:1px solid #20242A;border-radius:4px;}"
                "QToolButton:checked{border:2px solid #F0F6F0;}" % color)
            button.clicked.connect(lambda _c=False, col=color: self._set_color(col))
            grid.addWidget(button, i // 6, i % 6)
            self._color_buttons.append((color, button))
        self.custom_btn = QtWidgets.QToolButton()
        self.custom_btn.setText("自定义…")
        self.custom_btn.clicked.connect(self._pick_color)
        grid.addWidget(self.custom_btn, 2, 0, 1, 2)
        layout.addLayout(grid)

        layout.addWidget(QtWidgets.QLabel("图标"))
        self.shape_combo = QtWidgets.QComboBox()
        for key in icons.shapes():
            self.shape_combo.addItem(icons.icon(key, self._color, 14), key, key)
        index = self.shape_combo.findData(self._shape)
        self.shape_combo.setCurrentIndex(max(0, index))
        self.shape_combo.currentIndexChanged.connect(self._on_shape_changed)
        layout.addWidget(self.shape_combo)

        buttons = QtWidgets.QHBoxLayout()
        buttons.addStretch(1)
        self.cancel_btn = QtWidgets.QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        self.ok_btn = QtWidgets.QPushButton("保存")
        self.ok_btn.setObjectName("Accent")
        self.ok_btn.setDefault(True)
        self.ok_btn.clicked.connect(self._on_accept)
        buttons.addWidget(self.cancel_btn)
        buttons.addWidget(self.ok_btn)
        layout.addLayout(buttons)

        self._reload_parents(parent_id)
        self.context_combo.currentIndexChanged.connect(
            lambda _i: self._reload_parents(self.parent_combo.currentData() or ""))
        self._refresh_preview()
        self.name_edit.textChanged.connect(self._refresh_preview)

        # 输入法：Houdini 会把 WA_InputMethodEnabled 关掉，不补就打不了中文
        # （「新建文件夹」框打不了中文就是漏了这一行，别再删）
        install_ime_guard(self)

    # ---------------------------------------------------------- 内部
    def current_context(self):
        return self.context_combo.currentData() or ""

    def _reload_parents(self, keep):
        context = self.current_context()
        self.parent_combo.blockSignals(True)
        self.parent_combo.clear()
        self.parent_combo.addItem("（直接放在层级下）", "")
        skip = set()
        if self._folder.get("id"):
            skip = {self._folder["id"]}
            skip |= self._descendants(self._folder["id"])
        for folder, depth in self._walk(context):
            if folder.get("id") in skip:
                continue
            self.parent_combo.addItem(
                icons.icon(folder.get("shape") or "folder",
                           folder.get("color") or "#7C8794", 14),
                "%s%s" % ("　" * depth, folder.get("name") or "?"),
                folder.get("id"))
        index = self.parent_combo.findData(keep or "")
        self.parent_combo.setCurrentIndex(max(0, index))
        self.parent_combo.blockSignals(False)

    def _walk(self, context, parent_id="", depth=0, out=None):
        out = [] if out is None else out
        children = [f for f in self._folders
                    if contexts.key_of(f.get("context")) == context
                    and (f.get("parent") or "") == (parent_id or "")]
        children.sort(key=lambda f: (int(f.get("order") or 0),
                                     str(f.get("name") or "")))
        for folder in children:
            out.append((folder, depth))
            self._walk(context, folder.get("id"), depth + 1, out)
        return out

    def _descendants(self, folder_id):
        ids = set()
        changed = True
        while changed:
            changed = False
            for folder in self._folders:
                if folder.get("parent") == folder_id and folder["id"] not in ids:
                    ids.add(folder["id"])
                    changed = True
        return ids

    def _set_color(self, color):
        self._color = color
        self._refresh_preview()
        self._refresh_shape_icons()

    def _pick_color(self):
        color = QtWidgets.QColorDialog.getColor(QtGui.QColor(self._color), self,
                                                "挑一个颜色")
        if color.isValid():
            self._set_color(color.name())

    def _on_shape_changed(self, _index):
        self._shape = self.shape_combo.currentData() or "folder"
        self._refresh_preview()

    def _refresh_shape_icons(self):
        for index in range(self.shape_combo.count()):
            key = self.shape_combo.itemData(index)
            self.shape_combo.setItemIcon(
                index, icons.icon(key, self._color, 14))

    def _refresh_preview(self):
        name = self.name_edit.text().strip() or "?"
        self.preview.setPixmap(icons.pixmap(self._shape, self._color, 22))
        self.preview.setToolTip(name)
        for color, button in self._color_buttons:
            button.setChecked(color.lower() == self._color.lower())

    # ---------------------------------------------------------- 结果
    def _on_accept(self):
        if not self.name_edit.text().strip():
            self.name_edit.setFocus()
            return
        self.accept()

    def values(self):
        return {
            "name": self.name_edit.text().strip(),
            "context": self.current_context(),
            "parent": self.parent_combo.currentData() or "",
            "color": self._color,
            "shape": self.shape_combo.currentData() or "folder",
        }

    def exec_dialog(self):
        for name in ("exec_", "exec"):
            method = getattr(self, name, None)
            if method is None:
                continue
            try:
                return bool(method())
            except TypeError:
                continue
        return False


__all__ = ["FolderDialog", "PALETTE"]
