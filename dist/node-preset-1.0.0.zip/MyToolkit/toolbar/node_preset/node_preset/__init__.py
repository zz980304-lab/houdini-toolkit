# -*- coding: utf-8 -*-
"""节点预设库 node_preset。

位置：<任意 HOUDINI_PATH 目录>/toolbar/node_preset/node_preset/
    自包含，整个拷到别的机器 / 别的盘都能用，内部不写任何绝对路径，
    靠 HOUDINI_PATH 相对定位（详见同目录 维护白皮书.md）。

在 Houdini 里用：
    from node_preset import show
    show()

模块分工（各管一摊，互不塞；改哪块先看 维护白皮书.md）
    qt.py             Qt 绑定兼容层（PySide2 / PySide6，20.5 与 21 通用）
    ime.py            输入法守卫：Houdini 里能打中文全靠它（新框务必装）
    icons.py          内嵌 SVG 图标 + 任意着色
    contexts.py       Houdini 层级 → 简名（GEO / OBJ / DOP / ROP / PDG / Mat / Chop…）
    paths.py          库目录 / 配置解析（零绝对路径）
    model.py          预设 / 文件夹的数据形状 + meta.json 规则
    store.py          磁盘层：扫描、增删改、导入导出、备份（不 import hou）
    pinyin_index.py   拼音索引与打分（vendor 了 pypinyin，可降级）
    houdini_bridge.py **唯一 import hou 的地方**：存/取节点、截视口
    widgets.py        卡片委托、GIF 预览、拖拽残影/提示层、标签条
    ui.py             界面（不 import hou，只发信号）
    create_dialog.py  创建/编辑预设的框
    folder_dialog.py  文件夹编辑框（名字/颜色/图标）
    controller.py     把上面全部接起来（信号 → 落盘 + 动节点 → 刷新）
    updater.py / publisher.py  [P4] 自动更新 / 发布到 Git

数据在 library/ 下（一个预设一个文件夹，见 store.py 文件头）。
"""

from .qt import BINDING as QT_BINDING                       # noqa: F401
from .ui import NodePresetWindow                            # noqa: F401

__version__ = "1.0.7"
__all__ = ["show", "NodePresetWindow", "QT_BINDING", "close_all",
           "reload_package", "controller_of", "__version__"]

#: 已经打开过的窗口，避免被 Python 垃圾回收掉
_WINDOWS = []
#: 控制器也必须挂住，否则界面成空壳（信号没人接）
_CONTROLLERS = []


def controller_of(window=None):
    """拿到活着的控制器（脚本/调试用）。"""
    for controller in _CONTROLLERS:
        try:
            if window is None or controller.win is window:
                return controller
        except RuntimeError:                  # 窗口已经被 C++ 侧销毁
            continue
    return None


def show(parent=None):
    """以独立窗口打开；已经开着就把它提到前面来。"""
    from .qt import QtCore, enum_of

    for win in list(_WINDOWS):
        try:
            if win.isVisible():
                win.raise_()
                win.activateWindow()
                return win
        except RuntimeError:                  # 窗口已经被 C++ 侧销毁
            _WINDOWS.remove(win)

    if parent is None:
        try:
            import hou
            parent = hou.qt.mainWindow()      # 跟着 Houdini 主窗口
        except Exception:                     # noqa: BLE001
            parent = None

    from .controller import Controller

    win = NodePresetWindow(parent)
    win.setWindowFlags(enum_of(QtCore.Qt, "Window"))
    controller = Controller(win, parent=win)
    _CONTROLLERS.append(controller)
    try:
        win.set_version("v%s" % __version__)
    except Exception:                                     # noqa: BLE001
        pass
    win.show()
    win.raise_()
    win.activateWindow()
    try:
        win._enable_ime()          # show + 激活之后 Houdini 会把输入法开关关掉
    except Exception:                                      # noqa: BLE001
        pass
    _WINDOWS.append(win)
    return win


def close_all():
    """关掉本工具开过的所有窗口。"""
    for win in list(_WINDOWS):
        try:
            win.close()
        except Exception:                     # noqa: BLE001
            pass
    _WINDOWS[:] = []
    _CONTROLLERS[:] = []


def reload_package():
    """把 node_preset 及子模块从 sys.modules 踢掉。

    Houdini 的 Python 会话是常驻的，改了磁盘上的代码它不会自己重新读，
    点工具架按钮拿到的还是内存里那份旧的。这个函数是解药：
    下次 import 会重新读磁盘。
    """
    import sys

    close_all()
    keys = [k for k in sys.modules
            if k == "node_preset" or k.startswith("node_preset.")]
    for key in keys:
        sys.modules.pop(key, None)
    return bool(keys)
