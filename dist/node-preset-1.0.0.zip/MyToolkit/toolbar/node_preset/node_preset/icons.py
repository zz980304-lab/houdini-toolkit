# -*- coding: utf-8 -*-
"""图标：全部是内嵌的 SVG 字符串，运行时按颜色渲染成 QIcon / QPixmap。

为什么这么做：
- 用户要"文件夹统一图标、只是颜色不同"，还要"能换图标" —— 那就得能任意着色。
- SVG 源码直接写在代码里（不是一堆 png 文件）：零外部文件依赖、换电脑不会丢、
  换颜色不用重新出图。这也是"代码里不准出现绝对路径"那条规矩的自然结果。
- QSvgRenderer 在 Qt5 / Qt6 里用法一致，所以这套东西 20.5 / 21 都能跑。
  万一某个环境没编 QtSvg，会退化成纯 QPainter 画的色块（形状丑点但不会崩）。
"""

from .qt import QtCore, QtGui, QtSvg, enum_of

_AA = enum_of(QtCore.Qt, "transparent")

_SVG_HEAD = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" '
    'width="24" height="24">'
)


def _gear_body():
    """齿轮：一个中心圆 + 8 个绕圈的小方齿（用旋转变换生成，避免手写长路径）。"""
    parts = ['<circle cx="12" cy="12" r="4.6"/>']
    for i in range(8):
        angle = i * 45
        parts.append(
            '<rect x="10.7" y="1.4" width="2.6" height="3.9" rx="1.2" '
            'transform="rotate(%d 12 12)"/>' % angle)
    return "".join(parts)


#: 文件夹 / 分类用的形状库（单色，只用 fill，不描边）
SHAPES = {
    "folder": (
        '<path d="M3 7c0-1.1.9-2 2-2h3.6c.6 0 1.15.28 1.52.77l.98 1.23H19'
        'c1.1 0 2 .9 2 2v8c0 1.1-.9 2-2 2H5c-1.1 0-2-.9-2-2V7z"/>'
    ),
    "star": (
        '<path d="M12 2.6l2.9 5.9 6.5.95-4.7 4.58 1.11 6.47L12 17.4l-5.81 3.1'
        'L7.3 14.03 2.6 9.45l6.5-.95L12 2.6z"/>'
    ),
    "bolt": (
        '<path d="M12.7 2L4 14h5.6L8.6 22 20 9.2h-6.2L12.7 2z"/>'
    ),
    "flask": (
        '<path d="M8.6 2h6.8c.5 0 .9.4.9.9v2c0 .3-.13.58-.36.78l-1.02.9v4.3'
        'c0 .35-.08.7-.23 1.01l-4.3 7.44a1.9 1.9 0 0 1-1.7 1.07'
        'c-.72 0-1.38-.41-1.7-1.07l-4.3-7.44a2.1 2.1 0 0 1-.23-1.01V6.58'
        'l-1.02-.9A1.2 1.2 0 0 1 7.7 4.9v-2c0-.5.4-.9.9-.9z"/>'
    ),
    "cube": (
        '<path d="M12 2.4l8.4 4.7v9.3L12 21.1 3.6 16.4V7.1L12 2.4z"/>'
    ),
    "flame": (
        '<path d="M12 2s5.2 4.6 5.2 9.2A5.2 5.2 0 0 1 6.8 11.2'
        'c0-2.1 1.1-3.6 2.4-4.7 0 1.6 1.1 2.7 2.3 2.7 1.6 0 2.1-1.6.9-5.1'
        'c.4-.6.6-.9.6-.1z"/>'
    ),
    "drop": (
        '<path d="M12 2.4c3.6 4.1 5.6 6.9 5.6 9.8a5.6 5.6 0 1 1-11.2 0'
        'c0-2.9 2-5.7 5.6-9.8z"/>'
    ),
    "gear": _gear_body(),
    "tag": (
        '<path d="M3.4 11.4V5a1.6 1.6 0 0 1 1.6-1.6h6.4L20.8 12.8 12.6 21.6'
        ' 3.4 11.4z"/><circle cx="7.6" cy="7.6" r="1.7" fill="#000" '
        'fill-opacity="0.28"/>'
    ),
    "dots": (
        '<circle cx="5.6" cy="8.4" r="2.5"/>'
        '<circle cx="12" cy="14.4" r="2.5"/>'
        '<circle cx="18.4" cy="9.2" r="2.5"/>'
    ),
}

#: 界面按钮用的图标
UI_SHAPES = {
    "grid": (
        '<rect x="3" y="3" width="7.6" height="7.6" rx="1.8"/>'
        '<rect x="13.4" y="3" width="7.6" height="7.6" rx="1.8"/>'
        '<rect x="3" y="13.4" width="7.6" height="7.6" rx="1.8"/>'
        '<rect x="13.4" y="13.4" width="7.6" height="7.6" rx="1.8"/>'
    ),
    "list": (
        '<rect x="3" y="4" width="18" height="3.2" rx="1.6"/>'
        '<rect x="3" y="10.4" width="18" height="3.2" rx="1.6"/>'
        '<rect x="3" y="16.8" width="18" height="3.2" rx="1.6"/>'
    ),
    "search": (
        '<path d="M10.4 3a7.4 7.4 0 1 0 4.6 13.2l4.2 4.2a1.2 1.2 0 0 0 1.7-1.7'
        'l-4.2-4.2A7.4 7.4 0 0 0 10.4 3zm0 2.6a4.8 4.8 0 1 1 0 9.6'
        ' 4.8 4.8 0 0 1 0-9.6z"/>'
    ),
    "plus": (
        '<path d="M11 3.8h2.4v6.8H20v2.4h-6.6V20H11v-7H4.4v-2.4H11V3.8z"/>'
    ),
    "trash": (
        '<path d="M9 3h6l.8 1.6H20v2.2H4V4.6h4.2L9 3zm-3 4.4h12l-.9 12.2'
        'A1.8 1.8 0 0 1 15.3 21H8.7a1.8 1.8 0 0 1-1.8-1.4L6 7.4z"/>'
    ),
    "settings": _gear_body(),
}

DEFAULT_SHAPE = "folder"
DEFAULT_COLOR = "#7C8794"

_CACHE = {}


def shapes():
    """可选的形状名列表（界面里挑图标用）。"""
    return list(SHAPES.keys())


def svg_text(body, color):
    return '%s<g fill="%s">%s</g></svg>' % (_SVG_HEAD, color or DEFAULT_COLOR, body)


def _body_of(shape, ui=False):
    table = UI_SHAPES if ui else SHAPES
    return table.get(shape, table.get(DEFAULT_SHAPE) if not ui else table["settings"])


def pixmap(shape, color=DEFAULT_COLOR, size=16, ui=False):
    """把形状渲染成 QPixmap（透明底）。"""
    key = (shape, str(color), int(size), bool(ui))
    cached = _CACHE.get(key)
    if cached is not None and not cached.isNull():
        return cached

    pm = QtGui.QPixmap(int(size), int(size))
    pm.fill(_AA)
    painter = QtGui.QPainter(pm)
    try:
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        if QtSvg is not None:
            data = QtCore.QByteArray(
                svg_text(_body_of(shape, ui), color).encode("utf-8"))
            renderer = QtSvg.QSvgRenderer(data)
            if renderer.isValid():
                renderer.render(painter)
            else:
                _draw_fallback(painter, size, color)
        else:
            _draw_fallback(painter, size, color)
    finally:
        painter.end()

    _CACHE[key] = pm
    return pm


def _draw_fallback(painter, size, color):
    """没有 QtSvg 时的退化画法：一个该颜色的圆角块。"""
    painter.setBrush(QtGui.QColor(color or DEFAULT_COLOR))
    painter.setPen(enum_of(QtCore.Qt, "NoPen"))
    painter.drawRoundedRect(1, 1, max(1, int(size) - 2), max(1, int(size) - 2),
                            size * 0.25, size * 0.25)


def icon(shape, color=DEFAULT_COLOR, size=16, ui=False):
    """把形状渲染成 QIcon。"""
    return QtGui.QIcon(pixmap(shape, color, size, ui))


def tinted(color, shape=DEFAULT_SHAPE, size=16):
    """分类文件夹用的图标（统一形状 + 指定颜色）。"""
    return icon(shape, color, size)


__all__ = ["SHAPES", "UI_SHAPES", "DEFAULT_SHAPE", "DEFAULT_COLOR",
           "shapes", "pixmap", "icon", "tinted", "svg_text"]
