# -*- coding: utf-8 -*-
"""自动更新：从 Git（Cloudflare Pages / GitHub Pages）拉新版本代码。

**只更新代码，绝不碰你的 library/**（预设数据）。

流程
    1. 拉 manifest.json（CF Pages 优先，失败退 GitHub Pages）
    2. 找 modules[id=node-preset]，和 <库>/.update/installed.json 里的版本比
    3. 有新版本 → 下载 parts → 逐个校验 sha256
    4. 把当前工具目录备份到 <库>/_backup/tool_<时间戳>/
    5. 解压覆盖（zip 里的路径形如 MyToolkit/toolbar/node_preset/…，
       只认带 toolbar/node_preset/ 的那几条，别的忽略）
    6. 写 installed.json；提示重开窗口（reload_package 能热重载，不保证干净）

⚠️ Cloudflare 对 Python-urllib 的 UA 直接返 403，所以必须自己带 User-Agent。
⚠️ 本机装得是不是最新，靠 installed.json 而不是代码里写版本号 ——
   写死在代码里会跟着代码一起被覆盖，永远等于最新，比不出来。
"""

import hashlib
import json
import os
import shutil
import time
import urllib.error
import urllib.request
import zipfile

from . import paths
from .qt import QtCore, QtWidgets, Qt, enum_of, exec_box

MODULE_ID = "node-preset"
USER_AGENT = "node-preset-updater/1.0 (+houdini)"
MANIFEST_URLS = [
    "https://houdini-toolkit.pages.dev/manifest.json",
    "https://zz980304-lab.github.io/houdini-toolkit/manifest.json",
]
MARKER = "toolbar/node_preset"
TOOLKIT_ROOT = "MyToolkit"

_OK = enum_of(QtWidgets.QMessageBox, "Ok")
_WARNING = enum_of(QtWidgets.QMessageBox, "Warning")
_INFORMATION = enum_of(QtWidgets.QMessageBox, "Information")


# ------------------------------------------------------------------ 网络
def _request(url, timeout=10):
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    return urllib.request.urlopen(request, timeout=timeout)


def _fetch_json(url, timeout=10):
    with _request(url, timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_manifest():
    """返回 (manifest, base_url, 错误)。base_url 用来拼 parts 的相对路径。"""
    errors = []
    for url in MANIFEST_URLS:
        base = url.rsplit("/", 1)[0] + "/"
        try:
            data = _fetch_json(url, timeout=8)
            if isinstance(data, dict) and data.get("modules"):
                return data, base, ""
            errors.append("%s：内容不像 manifest" % url)
        except Exception as exc:                          # noqa: BLE001
            errors.append("%s：%r" % (url, exc))
    return None, "", "；".join(errors)


# ------------------------------------------------------------------ 版本
def _version_tuple(text):
    parts = []
    for chunk in str(text or "0").split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def installed_info():
    path = paths.installed_path()
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except Exception:                                     # noqa: BLE001
        pass
    return {}


def installed_version():
    info = installed_info().get(MODULE_ID) or {}
    return str(info.get("version") or "")


def save_installed(version, extra=None):
    info = installed_info()
    record = {"version": str(version),
              "installed": time.strftime("%Y-%m-%d %H:%M:%S")}
    record.update(extra or {})
    info[MODULE_ID] = record
    path = paths.installed_path()
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(info, handle, ensure_ascii=False, indent=2)
    return record


def module_info(manifest):
    for module in (manifest or {}).get("modules") or []:
        if module.get("id") == MODULE_ID:
            return module
    return None


# ------------------------------------------------------------------ 下载
def _download(url, dst_path, timeout=60):
    with _request(url, timeout) as response, open(dst_path, "wb") as handle:
        shutil.copyfileobj(response, handle)
    return dst_path


def _sha256(path, bufsize=1 << 20):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(bufsize)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


# ------------------------------------------------------------------ 备份 / 解压
def _backup_tool_dir():
    """把工具目录备份一份（跳过 library / _cache / __pycache__）。"""
    from .paths import tool_dir
    source = tool_dir()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = os.path.join(paths.backup_dir(), "tool_%s" % stamp)
    skip = {"library", "_cache", "_backup", ".update", "__pycache__", ".git"}
    try:
        if not os.path.isdir(paths.backup_dir()):
            os.makedirs(paths.backup_dir())
        if os.path.isdir(target):
            shutil.rmtree(target, ignore_errors=True)
        # dirs_exist_ok 是 3.8+ 才有的；先清空再用老写法，兼顾 3.7
        shutil.copytree(source, target,
                        ignore=shutil.ignore_patterns(*skip))
        return target
    except Exception:                                     # noqa: BLE001
        return ""


def _extract_parts(part_paths, replace=False):
    """解压并覆盖到工具目录，只处理 toolbar/node_preset/ 下的条目。

    返回 (写入文件数, 跳过条目数, 错误)
    """
    from .paths import tool_dir
    target_root = tool_dir()
    written = 0
    skipped = 0
    try:
        for part in part_paths:
            with zipfile.ZipFile(part, "r") as archive:
                for name in archive.namelist():
                    if name.endswith("/"):
                        continue
                    normalized = name.replace("\\", "/")
                    if "__pycache__" in normalized or normalized.endswith(".pyc"):
                        skipped += 1
                        continue
                    index = normalized.find(MARKER + "/")
                    if index < 0:
                        skipped += 1
                        continue
                    relative = normalized[index + len(MARKER) + 1:]
                    if not relative:
                        skipped += 1
                        continue
                    # 防 zip slip：条目里带 .. 或绝对路径的一律跳过
                    chunks = [c for c in relative.split("/") if c]
                    if not chunks or any(c == ".." for c in chunks):
                        skipped += 1
                        continue
                    dst = os.path.join(target_root, *chunks)
                    if not os.path.abspath(dst).startswith(
                            os.path.abspath(target_root)):
                        skipped += 1
                        continue
                    parent = os.path.dirname(dst)
                    if parent and not os.path.isdir(parent):
                        os.makedirs(parent)
                    with archive.open(name, "r") as src, open(dst, "wb") as out:
                        shutil.copyfileobj(src, out)
                    written += 1
    except Exception as exc:                              # noqa: BLE001
        return written, skipped, "%r" % exc
    _ = replace
    return written, skipped, ""


# ------------------------------------------------------------------ 入口
def check_from_ui(controller, quiet=False):
    """设置 ▸「检查更新」。返回 True = 已更新。"""
    win = getattr(controller, "win", None)
    local_version = installed_version()
    manifest, base, error = fetch_manifest()
    if manifest is None:
        if not quiet:
            _box(win, "检查更新失败", "拉不到版本清单：\n%s\n\n"
                       "（本机直连 GitHub 常常不通，挂上代理再试）" % error,
                 _WARNING)
        return False

    module = module_info(manifest)
    if module is None:
        if not quiet:
            _box(win, "检查更新", "服务器上没有 node-preset 这个模块，\n"
                       "说明还没发布过（先跑一次「发布到 Git」）。", _INFORMATION)
        return False

    remote_version = str(module.get("version") or "")
    if local_version and _version_tuple(remote_version) <= _version_tuple(local_version):
        if not quiet:
            _box(win, "检查更新",
                 "已经是最新：\n本机 v%s\n线上 v%s" % (local_version, remote_version),
                 _INFORMATION)
        return False

    parts = module.get("parts") or []
    total = sum(int(p.get("size") or 0) for p in parts)
    if not _confirm(win, "发现新版本 v%s" % remote_version,
                    "本机：%s\n线上：%s\n\n共 %d 个文件，%.1f MB。\n"
                    "只更新代码，预设库（library/）一个字节都不动。\n现在更新？"
                    % (local_version or "（没记录）", remote_version,
                       len(parts), total / 1048576.0)):
        return False

    cache = os.path.join(paths.update_dir(), "download")
    if not os.path.isdir(cache):
        os.makedirs(cache)
    downloaded = []
    try:
        for index, part in enumerate(parts):
            url = part.get("url") or ""
            if not url.startswith("http"):
                url = base + url
            dst = os.path.join(cache, os.path.basename(url) or ("part%d.zip" % index))
            if hasattr(controller, "message"):
                controller.message("下载中 %d/%d：%s"
                                   % (index + 1, len(parts), os.path.basename(dst)))
            QtWidgets.QApplication.processEvents()
            _download(url, dst)
            expect = str(part.get("sha256") or "")
            if expect and _sha256(dst) != expect:
                raise RuntimeError("sha256 不符：%s" % os.path.basename(dst))
            downloaded.append(dst)
    except Exception as exc:                              # noqa: BLE001
        _box(win, "下载失败", "%r" % exc, _WARNING)
        return False

    backup = _backup_tool_dir()
    written, skipped, error = _extract_parts(downloaded)
    if error:
        _box(win, "解压失败",
             "%s\n\n备份在：%s\n可以用它手动还原。" % (error, backup or "（没备份成功）"),
             _WARNING)
        return False

    save_installed(remote_version, {"parts": len(downloaded),
                                    "backup": backup or "",
                                    "skipped": skipped})
    if hasattr(controller, "message"):
        controller.message("已更新到 v%s（写入 %d 个文件）" % (remote_version, written))

    reloaded = False
    try:
        from . import reload_package
        reload_package()
        reloaded = True
    except Exception:                                     # noqa: BLE001
        reloaded = False
    _box(win, "更新完成",
         "已更新到 v%s，写入 %d 个文件。\n备份：%s\n\n%s"
         % (remote_version, written, backup or "（无）",
            "已尝试热重载，重新点一次工具架按钮即可。"
            if reloaded else "关掉窗口再点工具架按钮生效。"),
         _INFORMATION)
    return True


def _box(parent, title, text, icon):
    box = QtWidgets.QMessageBox(parent)
    box.setWindowTitle(title)
    box.setIcon(icon)
    box.setText(text)
    box.setStandardButtons(_OK)
    return exec_box(box)


def _confirm(parent, title, text):
    box = QtWidgets.QMessageBox(parent)
    box.setWindowTitle(title)
    box.setIcon(_INFORMATION)
    box.setText(text)
    box.setStandardButtons(enum_of(QtWidgets.QMessageBox, "Yes")
                           | enum_of(QtWidgets.QMessageBox, "No"))
    return exec_box(box) == enum_of(QtWidgets.QMessageBox, "Yes")


__all__ = ["check_from_ui", "fetch_manifest", "installed_version",
           "save_installed", "MODULE_ID", "MANIFEST_URLS"]
