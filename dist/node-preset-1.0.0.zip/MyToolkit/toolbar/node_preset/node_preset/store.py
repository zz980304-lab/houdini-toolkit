# -*- coding: utf-8 -*-
"""预设库的磁盘层：扫描、增删改、导入导出、备份。

分工：
    model.py     数据长什么样
    store.py     ← 这个文件，只碰文件和 json（**不 import hou**）
    houdini_bridge.py  存/取节点（唯一 import hou 的地方）
    controller.py      把 ui / store / bridge 串起来

库目录结构::

    <库>/
        catalog.json                 ← 自定义文件夹（彩色）
        p_1a2b3c/                    ← 一个预设
            meta.json  nodes.cpio  nodes.py  preview.gif
        _cache/                      ← 缩略图缓存（可清）
        _backup/                     ← 备份（工具自己写）
        .update/                     ← 自动更新的状态，别放进 git

并发/损坏原则：**读的时候尽量容错，写的时候要么全对要么别动**。
 - 读 meta.json 失败 → 跳过这个预设，不抛异常（一个坏文件不该毁掉整个库）
 - 写 meta.json 走 "写临时文件 + os.replace"，断电也不会写半个 json
"""

import json
import os
import shutil
import time
import zipfile

from . import model, paths

META_NAME = "meta.json"
CATALOG_NAME = "catalog.json"
SKIP_DIRS = {"_cache", "_backup", ".update", "_trash", "__pycache__"}
SKIP_SUFFIX = (".pyc", ".tmp", ".bak")

NP_EXT = ".npreset"


def _safe_name(text):
    """把用户输入变成合法文件夹名（只在需要时用）。"""
    bad = '<>:"/\\|?*\n\r\t'
    out = "".join("_" if ch in bad else ch for ch in str(text or "")).strip()
    return out[:40] or "preset"


class StoreError(Exception):
    pass


class Store(object):
    def __init__(self, root=None):
        self._root = os.path.abspath(root) if root else paths.library_dir()
        self._folders = None                 # catalog 缓存
        self._folders_mtime = None

    # ================================================================ 基础
    def root(self):
        return self._root

    def ensure(self):
        """库目录建出来；失败返回 False（N 盘没挂上时会这样）。

        ⚠️ 必须用 self.cache_dir() / self.backup_dir()，不能用 paths.cache_dir()：
        后者算的是**默认库**的位置，本库被改到别处（设置里改过 / 自检传了临时目录）
        时会把目录建错地方。
        """
        try:
            for path in (self._root, self.cache_dir(), self.backup_dir()):
                if not os.path.isdir(path):
                    os.makedirs(path)
            return True
        except Exception:                                 # noqa: BLE001
            return False

    def set_root(self, root):
        self._root = os.path.abspath(root)
        self._folders = None
        self._folders_mtime = None
        return self.ensure()

    def exists(self):
        return os.path.isdir(self._root)

    def cache_dir(self):
        return os.path.join(self._root, "_cache")

    def backup_dir(self):
        return os.path.join(self._root, "_backup")

    @staticmethod
    def _write_json(path, data):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2)
        os.replace(tmp, path)

    @staticmethod
    def _read_json(path, default=None):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                return json.load(handle)
        except Exception:                                 # noqa: BLE001
            return default

    # ================================================================ 扫描
    def preset_dir(self, preset_id):
        return os.path.join(self._root, str(preset_id))

    def scan(self):
        """扫一遍库，返回 (presets, folders)。坏数据跳过，不抛。"""
        presets = []
        if os.path.isdir(self._root):
            for name in sorted(os.listdir(self._root)):
                if not name.startswith("p_"):
                    continue
                if name in SKIP_DIRS or name.endswith(SKIP_SUFFIX):
                    continue
                folder = os.path.join(self._root, name)
                if not os.path.isdir(folder):
                    continue
                raw = self._read_json(os.path.join(folder, META_NAME))
                if not isinstance(raw, dict):
                    continue
                meta = model.normalize_meta(raw, name)
                # 预览图丢了就别硬指着一个不存在的文件
                preview = meta.get("preview") or ""
                if preview and not os.path.isfile(os.path.join(folder, preview)):
                    meta["preview"] = ""
                presets.append(meta)
        return presets, self.folders()

    def new_preset_dir(self, preset_id=""):
        preset_id = preset_id or model.new_preset_id()
        folder = os.path.join(self._root, preset_id)
        if os.path.isdir(folder):
            raise StoreError("预设目录已存在：%s" % preset_id)
        os.makedirs(folder)
        return folder

    def write_meta(self, preset_dir, meta):
        meta["modified"] = model.now_text()
        self._write_json(os.path.join(preset_dir, META_NAME), meta)
        return meta

    def read_meta(self, preset_id):
        folder = self.preset_dir(preset_id)
        raw = self._read_json(os.path.join(folder, META_NAME))
        if not isinstance(raw, dict):
            return None
        return model.normalize_meta(raw, preset_id)

    def patch(self, preset_id, changes, touch=True):
        """改 meta 的若干字段（改名/简介/标签/收藏/文件夹…）。"""
        meta = self.read_meta(preset_id)
        if meta is None:
            return None
        meta.update(changes or {})
        if touch:
            meta["modified"] = model.now_text()
        self._write_json(os.path.join(self.preset_dir(preset_id), META_NAME), meta)
        return meta

    def bump_use(self, preset_id):
        meta = self.read_meta(preset_id)
        if meta is None:
            return None
        meta["use_count"] = int(meta.get("use_count") or 0) + 1
        self._write_json(os.path.join(self.preset_dir(preset_id), META_NAME), meta)
        return meta

    # ================================================================ 删除 / 复制
    def delete_preset(self, preset_id, to_trash=True):
        folder = self.preset_dir(preset_id)
        if not os.path.isdir(folder):
            return False
        if to_trash:
            trash = os.path.join(self._root, "_trash")
            if not os.path.isdir(trash):
                os.makedirs(trash)
            target = os.path.join(trash, "%s_%s" % (
                os.path.basename(folder), time.strftime("%Y%m%d-%H%M%S")))
            try:
                shutil.move(folder, target)
                return True
            except Exception:                             # noqa: BLE001
                pass
        try:
            shutil.rmtree(folder)
            return True
        except Exception:                                 # noqa: BLE001
            return False

    def duplicate_preset(self, preset_id, new_name=""):
        meta = self.read_meta(preset_id)
        if meta is None:
            return ""
        new_id = model.new_preset_id()
        src = self.preset_dir(preset_id)
        dst = os.path.join(self._root, new_id)
        try:
            shutil.copytree(src, dst)
        except Exception:                                 # noqa: BLE001
            return ""
        meta["id"] = new_id
        meta["name"] = new_name or ("%s 副本" % (meta.get("name") or "预设"))
        meta["created"] = model.now_text()
        meta["modified"] = meta["created"]
        meta["use_count"] = 0
        meta["favorite"] = False
        self._write_json(os.path.join(dst, META_NAME), meta)
        return new_id

    # ================================================================ 预览图
    def set_preview(self, preset_id, source_path):
        """把外部图片复制进预设目录并改名 preview.<ext>。"""
        if not source_path or not os.path.isfile(source_path):
            return ""
        folder = self.preset_dir(preset_id)
        ext = os.path.splitext(source_path)[1].lower() or ".png"
        name = "preview" + ext
        dst = os.path.join(folder, name)
        try:
            if os.path.abspath(source_path) != os.path.abspath(dst):
                shutil.copyfile(source_path, dst)
        except Exception:                                 # noqa: BLE001
            return ""
        # 换了扩展名就把旧的删掉，避免目录里堆一堆
        for other in os.listdir(folder):
            if other.startswith("preview.") and other != name:
                try:
                    os.remove(os.path.join(folder, other))
                except Exception:                         # noqa: BLE001
                    pass
        self.patch(preset_id, {"preview": name})
        return dst

    def clear_preview(self, preset_id):
        folder = self.preset_dir(preset_id)
        for name in os.listdir(folder) if os.path.isdir(folder) else []:
            if name.startswith("preview."):
                try:
                    os.remove(os.path.join(folder, name))
                except Exception:                         # noqa: BLE001
                    pass
        self.patch(preset_id, {"preview": ""})

    def presets_missing_preview(self):
        return [meta for meta in self.scan()[0] if not meta.get("preview")]

    # ================================================================ 文件夹
    def folders(self):
        """读 catalog.json（带 mtime 缓存）。

        ⚠️ 缓存键是 (mtime, size) 而不是只有 mtime：网络盘 / exFAT 的 mtime 精度
        只有 2 秒，同一秒内改两次（新建文件夹后马上改名）会读到旧列表，
        表现为"新建的文件夹不显示"。
        """
        path = os.path.join(self._root, CATALOG_NAME)
        try:
            stamp = (os.path.getmtime(path), os.path.getsize(path))
        except OSError:
            stamp = None
        if self._folders is not None and stamp == self._folders_mtime:
            return list(self._folders)
        raw = self._read_json(path, {}) or {}
        folders = []
        for item in raw.get("folders") or []:
            folder = model.normalize_folder(item)
            if folder:
                folders.append(folder)
        self._folders = folders
        self._folders_mtime = stamp
        return list(folders)

    def save_folders(self, folders):
        path = os.path.join(self._root, CATALOG_NAME)
        data = {"schema": 1, "folders": list(folders or [])}
        self._write_json(path, data)
        self._folders = list(folders or [])
        try:
            self._folders_mtime = (os.path.getmtime(path), os.path.getsize(path))
        except OSError:
            self._folders_mtime = None
        return True

    def add_folder(self, name, context, parent="", color="#7C8794",
                   shape="folder"):
        folders = self.folders()
        order = len([f for f in folders
                     if f.get("context") == context
                     and (f.get("parent") or "") == (parent or "")])
        folder = model.build_folder(name, context, parent, color, shape, order)
        folders.append(folder)
        self.save_folders(folders)
        return folder

    def update_folder(self, folder_id, changes):
        folders = self.folders()
        updated = None
        for folder in folders:
            if folder.get("id") == folder_id:
                for key, value in (changes or {}).items():
                    if key in ("name", "color", "shape", "parent", "context"):
                        folder[key] = str(value)
                    elif key == "order":
                        folder["order"] = int(value)
                updated = folder
                break
        if updated is not None:
            self.save_folders(folders)
        return updated

    def delete_folder(self, folder_id):
        """删文件夹：里面的预设退回「未分类」，子文件夹一并删掉。"""
        folders = self.folders()
        doomed = self.folder_ids_below(folder_id, folders)
        keep = [f for f in folders if f.get("id") not in doomed]
        self.save_folders(keep)
        for meta in self.scan()[0]:
            if meta.get("folder_id") in doomed:
                self.patch(meta["id"], {"folder_id": None})
        return sorted(doomed)

    @staticmethod
    def folder_ids_below(folder_id, folders=None):
        folders = folders if folders is not None else []
        ids = {folder_id}
        changed = True
        while changed:
            changed = False
            for folder in folders:
                if folder.get("parent") in ids and folder.get("id") not in ids:
                    ids.add(folder.get("id"))
                    changed = True
        return ids

    def move_preset(self, preset_id, folder_id):
        return self.patch(preset_id, {"folder_id": folder_id or None})

    # ================================================================ 导入导出
    def export_presets(self, preset_ids, dst_path):
        """把若干预设打包成 .npreset（就是个 zip，根目录是 presets/ 和 catalog.json）。"""
        preset_ids = [p for p in (preset_ids or []) if p]
        if not preset_ids:
            return False
        folders = self.folders()
        used_folders = []
        folder_by_id = dict((f["id"], f) for f in folders)
        for preset_id in preset_ids:
            meta = self.read_meta(preset_id)
            fid = (meta or {}).get("folder_id")
            chain = []
            while fid and fid in folder_by_id:
                chain.append(folder_by_id[fid])
                fid = folder_by_id[fid].get("parent")
            for folder in chain:
                if folder["id"] not in [f["id"] for f in used_folders]:
                    used_folders.append(folder)

        try:
            with zipfile.ZipFile(dst_path, "w", zipfile.ZIP_DEFLATED) as archive:
                for preset_id in preset_ids:
                    folder = self.preset_dir(preset_id)
                    if not os.path.isdir(folder):
                        continue
                    for name in os.listdir(folder):
                        full = os.path.join(folder, name)
                        if not os.path.isfile(full) or name.endswith(SKIP_SUFFIX):
                            continue
                        archive.write(full, "presets/%s/%s" % (preset_id, name))
                archive.writestr("catalog.json", json.dumps(
                    {"schema": 1, "folders": used_folders},
                    ensure_ascii=False, indent=2))
                archive.writestr("npreset.json", json.dumps(
                    {"schema": 1, "app": "node_preset",
                     "created": model.now_text()},
                    ensure_ascii=False, indent=2))
            return True
        except Exception:                                 # noqa: BLE001
            return False

    def import_presets(self, src_path):
        """导入 .npreset，返回 (新预设 id 列表, 错误说明)。id 冲突时自动换新 id。"""
        new_ids = []
        if not os.path.isfile(src_path):
            return new_ids, "文件不存在"
        existing = set(f["id"] for f in self.folders())
        folder_map = {}
        id_map = {}                    # 压缩包里的旧 id → 落地用的新 id
        try:
            with zipfile.ZipFile(src_path, "r") as archive:
                names = archive.namelist()
                if "catalog.json" in names:
                    raw = json.loads(archive.read("catalog.json").decode("utf-8"))
                    keep = self.folders()
                    for item in (raw.get("folders") or []):
                        folder = model.normalize_folder(item)
                        if not folder:
                            continue
                        if folder["id"] in existing:
                            folder_map[item.get("id")] = folder["id"]
                            continue
                        folder["parent"] = folder_map.get(folder.get("parent") or "",
                                                          folder.get("parent") or "")
                        keep.append(folder)
                        existing.add(folder["id"])
                    self.save_folders(keep)

                for name in names:
                    if not name.startswith("presets/") or name.endswith("/"):
                        continue
                    parts = name.split("/")
                    if len(parts) < 3:
                        continue
                    src_id, filename = parts[1], parts[-1]
                    # 同一个预设的所有文件必须落到同一个新 id 上
                    new_id = id_map.get(src_id)
                    if new_id is None:
                        if src_id and not os.path.isdir(self.preset_dir(src_id)):
                            new_id = src_id
                        else:
                            new_id = model.new_preset_id()
                        id_map[src_id] = new_id
                        new_ids.append(new_id)
                    folder = self.preset_dir(new_id)
                    if not os.path.isdir(folder):
                        os.makedirs(folder)
                    with open(os.path.join(folder, filename), "wb") as handle:
                        handle.write(archive.read(name))

            # 修 id 和失效的 folder_id
            for new_id in new_ids:
                meta = self.read_meta(new_id)
                if meta is None:
                    continue
                meta["id"] = new_id
                folder_id = meta.get("folder_id")
                if folder_id:
                    meta["folder_id"] = folder_map.get(folder_id, folder_id)
                    if meta["folder_id"] not in existing:
                        meta["folder_id"] = None
                meta["modified"] = model.now_text()
                self._write_json(os.path.join(self.preset_dir(new_id), META_NAME), meta)
        except Exception as exc:                          # noqa: BLE001
            return new_ids, "导入失败：%r" % exc
        return new_ids, ""

    # ================================================================ 备份 / 缓存
    def backup(self, dst_path="", include_cache=False):
        """打包整个库（默认排除 _cache/_backup/.update/_trash）。"""
        if not dst_path:
            stamp = time.strftime("%Y%m%d-%H%M%S")
            dst_path = os.path.join(self.backup_dir(), "library_%s.zip" % stamp)
        parent = os.path.dirname(dst_path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        skip = set(SKIP_DIRS)
        if include_cache:
            skip.discard("_cache")
        try:
            with zipfile.ZipFile(dst_path, "w", zipfile.ZIP_DEFLATED) as archive:
                for root, dirs, files in os.walk(self._root):
                    rel = os.path.relpath(root, self._root)
                    if rel == ".":
                        rel = ""
                    dirs[:] = [d for d in dirs
                               if d not in skip and not d.startswith(".")]
                    for name in files:
                        if name.endswith(SKIP_SUFFIX):
                            continue
                        full = os.path.join(root, name)
                        archive.write(full, os.path.join(rel, name)
                                      if rel else name)
            return dst_path
        except Exception:                                 # noqa: BLE001
            return ""

    def clear_cache(self):
        removed = 0
        cache = self.cache_dir()
        if os.path.isdir(cache):
            for name in os.listdir(cache):
                try:
                    os.remove(os.path.join(cache, name))
                    removed += 1
                except Exception:                         # noqa: BLE001
                    pass
        return removed

    def stats(self):
        presets, folders = self.scan()
        return {"presets": len(presets), "folders": len(folders),
                "root": self._root}


__all__ = ["Store", "StoreError", "META_NAME", "CATALOG_NAME", "NP_EXT"]
