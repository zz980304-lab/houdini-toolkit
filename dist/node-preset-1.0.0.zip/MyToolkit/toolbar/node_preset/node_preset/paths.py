# -*- coding: utf-8 -*-
"""路径解析：库目录 / 缓存目录 / 仓库目录，**一个写死的盘符都没有**。

解析顺序（库目录）：
  1. 环境变量 HOUDINI_NODE_PRESET_DIR
  2. <工具目录>/config.json 里的 library_dir（界面"设置"里可改，支持 $VAR）
  3. 兜底 <工具目录>/library/

工具目录本身也是靠 HOUDINI_PATH 找的：本包（node_preset/）的上级目录就是
``<某个 HOUDINI_PATH 项>/toolbar/node_preset``，所以直接往上退一级即可，
不需要知道它在 N 盘还是别的盘。
"""

import json
import os

ENV_LIBRARY = "HOUDINI_NODE_PRESET_DIR"
ENV_REPO = "HOUDINI_TOOLKIT_REPO"

CONFIG_NAME = "config.json"
LIBRARY_NAME = "library"


# ------------------------------------------------------------------ 基础
def package_dir():
    """node_preset 包所在目录。"""
    return os.path.dirname(os.path.abspath(__file__))


def tool_dir():
    """自包含工具目录（包的上一级）。"""
    return os.path.dirname(package_dir())


def houdini_path_entries():
    """HOUDINI_PATH 的每一项。先问 hou（在 Houdini 里最准），再退到环境变量。"""
    raw = ""
    try:
        import hou
        raw = hou.getenv("HOUDINI_PATH") or ""
    except Exception:                                         # noqa: BLE001
        raw = ""
    if not raw:
        raw = os.environ.get("HOUDINI_PATH", "")
    sep = ";" if os.name == "nt" else ":"
    out = []
    for part in str(raw).split(sep):
        part = part.strip().strip('"')
        if part and part not in out:
            out.append(part)
    return out


def expand(text):
    """展开 $VAR / %VAR% / ~。"""
    if not text:
        return ""
    text = os.path.expandvars(str(text))
    text = os.path.expanduser(text)
    return os.path.normpath(text)


# ------------------------------------------------------------------ 配置
def config_path():
    return os.path.join(tool_dir(), CONFIG_NAME)


def load_config():
    try:
        with open(config_path(), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except Exception:                                         # noqa: BLE001
        pass
    return {}


def save_config(data):
    path = config_path()
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data or {}, handle, ensure_ascii=False, indent=4)
        return True
    except Exception:                                         # noqa: BLE001
        return False


def library_dir():
    """预设库根目录（不会自动创建）。"""
    env = os.environ.get(ENV_LIBRARY)
    if env:
        return expand(env)
    cfg = load_config()
    value = cfg.get("library_dir")
    if value:
        return expand(value)
    return os.path.join(tool_dir(), LIBRARY_NAME)


def set_library_dir(path):
    cfg = load_config()
    cfg["library_dir"] = str(path)
    return save_config(cfg)


def cache_dir():
    return os.path.join(library_dir(), "_cache")


def backup_dir():
    return os.path.join(library_dir(), "_backup")


def update_dir():
    return os.path.join(library_dir(), ".update")


def installed_path():
    return os.path.join(update_dir(), "installed.json")


def catalog_path():
    return os.path.join(library_dir(), "catalog.json")


def ensure_library():
    """把库目录和它的子目录建出来；失败返回 False（N 盘离线时会这样）。"""
    try:
        for path in (library_dir(), cache_dir()):
            if not os.path.isdir(path):
                os.makedirs(path)
        return True
    except Exception:                                         # noqa: BLE001
        return False


# ------------------------------------------------------------------ 仓库（自动更新用）
def repo_dir():
    """hou 工具集 git 仓库目录；找不到返回空字符串。"""
    env = os.environ.get(ENV_REPO)
    if env and os.path.isdir(expand(env)):
        return expand(env)
    cfg = load_config()
    value = cfg.get("repo_dir")
    if value and os.path.isdir(expand(value)):
        return expand(value)
    for entry in houdini_path_entries():
        candidate = os.path.join(entry, "houdini_updata", "repo", "houdini-toolkit")
        if os.path.isdir(candidate):
            return candidate
    return ""


def set_repo_dir(path):
    cfg = load_config()
    cfg["repo_dir"] = str(path)
    return save_config(cfg)


__all__ = ["package_dir", "tool_dir", "houdini_path_entries", "expand",
           "config_path", "load_config", "save_config",
           "library_dir", "set_library_dir", "cache_dir", "backup_dir",
           "update_dir", "installed_path", "catalog_path", "ensure_library",
           "repo_dir", "set_repo_dir",
           "ENV_LIBRARY", "ENV_REPO", "CONFIG_NAME", "LIBRARY_NAME"]
