# -*- coding: utf-8 -*-
"""数据模型：预设 / 文件夹的"形状"，以及磁盘上 meta.json 的读写规则。

这个文件只管**数据长什么样**，不碰磁盘 IO（store.py 管）、不碰 hou（bridge 管）、
不碰界面（ui.py 管）。

一个预设 = 库目录下的一个文件夹::

    <库>/p_1a2b3c/
        meta.json      ← 下面这些字段
        nodes.cpio     ← parent.saveItemsToFile(items, path) —— 主内容
        nodes.py       ← asCode 兜底（cpio 跨大版本可能读不进）
        preview.png    ← 可选，预览图 / GIF

meta.json 字段（**只增不改，改名要写迁移**）::

    schema       1
    id           预设 id（= 文件夹名）
    name         名字（界面可改）
    desc         简介
    tags         ["破碎", "RBD"]
    context      Houdini category，如 "Sop" / "Dop" / "Driver"
    node_types   ["voronoifracture", "assemble"]（type().name()）
    node_count   3
    node_names   ["voronoi1", "assemble1"]
    source_path  /obj/geo1     ← 存的时候节点在哪个网络里
    folder_id    "f_xxx" 或 null（null = 该层级的「未分类」）
    favorite     false
    use_count    0
    created      2026-10-18 19:40:00
    modified     同上
    preview      preview.gif  ← 相对本目录的文件名，别存绝对路径！
    py_abbr      "ps"          ← 拼音首字母（小写，不含空格）
    py_full      "posui"       ← 全拼
    py_abbr_tags "psrbd"
"""

import os
import random
import time

SCHEMA = 1

#: 新建 meta 的默认值
DEFAULTS = {
    "schema": SCHEMA,
    "id": "",
    "name": "",
    "desc": "",
    "tags": [],
    "context": "",
    "node_types": [],
    "node_count": 0,
    "node_names": [],
    "source_path": "",
    "folder_id": None,
    "favorite": False,
    "use_count": 0,
    "created": "",
    "modified": "",
    "preview": "",
    "py_abbr": "",
    "py_full": "",
    "py_abbr_tags": "",
}

#: 界面会传给我们的字段（创建框里的那几个）
VALUES_KEYS = ("name", "desc", "tags", "context", "folder_id", "preview")

_ID_ALPHABET = "0123456789abcdefghijkmnpqrstuvwxyz"      # 去掉容易看错的 l/o


def _rand(n=4):
    return "".join(random.choice(_ID_ALPHABET) for _ in range(n))


def now_text():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def new_preset_id():
    """p_<秒级时间 base34><4 位随机>，单机够用，也不怕并行建。"""
    stamp = ""
    value = int(time.time())
    base = len(_ID_ALPHABET)                 # 34，不是 36（字母表去掉了 l/o）
    while value:
        value, rem = divmod(value, base)
        stamp = _ID_ALPHABET[rem] + stamp
    return "p_%s%s" % (stamp[-5:], _rand(4))


def new_folder_id():
    return "f_%s" % _rand(5)


# ------------------------------------------------------------------ 预设
def build_meta(values, info=None, preset_id=""):
    """创建框的 values + bridge 探测到的 info → 一份完整 meta。"""
    values = values or {}
    info = info or {}
    meta = dict(DEFAULTS)
    meta["id"] = preset_id or values.get("id") or new_preset_id()
    meta["name"] = str(values.get("name") or "").strip() or "未命名预设"
    meta["desc"] = str(values.get("desc") or "")
    meta["tags"] = [str(t).strip() for t in (values.get("tags") or [])
                    if str(t).strip()]
    meta["context"] = str(values.get("context") or info.get("context") or "")
    folder_id = values.get("folder_id")
    meta["folder_id"] = str(folder_id) if folder_id else None
    meta["preview"] = os.path.basename(str(values.get("preview") or "")) or ""
    for key in ("node_types", "node_names"):
        raw = info.get(key) or []
        meta[key] = [str(x) for x in raw]
    meta["node_count"] = int(info.get("node_count") or len(meta["node_types"]))
    meta["source_path"] = str(info.get("source_path") or "")
    meta["created"] = now_text()
    meta["modified"] = meta["created"]
    return meta


def normalize_meta(raw, preset_id=""):
    """从磁盘读回来的 meta → 补齐默认值、纠正类型。坏数据不抛异常。"""
    meta = dict(DEFAULTS)
    if isinstance(raw, dict):
        for key, default in DEFAULTS.items():
            if key not in raw:
                continue
            value = raw.get(key)
            if isinstance(default, list):
                meta[key] = [str(v) for v in value] if isinstance(value, (list, tuple)) else []
            elif isinstance(default, bool):
                meta[key] = bool(value)
            elif isinstance(default, int):
                try:
                    meta[key] = int(value)
                except (TypeError, ValueError):
                    meta[key] = 0
            elif default is None:
                meta[key] = str(value) if value else None
            else:
                meta[key] = "" if value is None else str(value)
    meta["id"] = preset_id or meta.get("id") or new_preset_id()
    meta["schema"] = int(meta.get("schema") or SCHEMA)
    if not meta["created"]:
        meta["created"] = now_text()
    if not meta["modified"]:
        meta["modified"] = meta["created"]
    return meta


def to_ui(meta, preset_dir=""):
    """meta → 界面要的 dict。

    界面只认"能直接显示"的字段：预览图给**绝对路径**（界面层不拼路径）。
    """
    item = dict(meta)
    preview = meta.get("preview") or ""
    if preview and preset_dir:
        item["preview"] = os.path.join(preset_dir, preview)
    else:
        item["preview"] = ""
    item["folder_id"] = meta.get("folder_id") or ""
    return item


def apply_values(meta, values):
    """在已有 meta 上套用创建框/详情页改动（不动 id / created）。"""
    values = values or {}
    for key in ("name", "desc", "context"):
        if key in values and values[key] is not None:
            meta[key] = str(values[key]).strip() if key == "name" else str(values[key])
    if "tags" in values and values["tags"] is not None:
        meta["tags"] = [str(t).strip() for t in values["tags"] if str(t).strip()]
    if "folder_id" in values:
        folder_id = values.get("folder_id")
        meta["folder_id"] = str(folder_id) if folder_id else None
    if "favorite" in values:
        meta["favorite"] = bool(values["favorite"])
    if "preview" in values and values["preview"] is not None:
        meta["preview"] = os.path.basename(str(values["preview"]))
    meta["modified"] = now_text()
    return meta


# ------------------------------------------------------------------ 文件夹
def build_folder(name, context, parent="", color="#7C8794", shape="folder",
                 order=0, folder_id=""):
    return {
        "id": folder_id or new_folder_id(),
        "name": str(name or "新文件夹").strip() or "新文件夹",
        "context": str(context or ""),
        "parent": str(parent or ""),
        "color": str(color or "#7C8794"),
        "shape": str(shape or "folder"),
        "order": int(order or 0),
    }


def normalize_folder(raw):
    if not isinstance(raw, dict):
        return None
    folder = build_folder(raw.get("name") or "?", raw.get("context") or "",
                          raw.get("parent") or "",
                          raw.get("color") or "#7C8794",
                          raw.get("shape") or "folder",
                          raw.get("order") or 0,
                          raw.get("id") or "")
    return folder


__all__ = ["SCHEMA", "DEFAULTS", "VALUES_KEYS", "now_text",
           "new_preset_id", "new_folder_id",
           "build_meta", "normalize_meta", "to_ui", "apply_values",
           "build_folder", "normalize_folder"]
