# -*- coding: utf-8 -*-
"""Qt 绑定兼容层（PySide2 / PySide6 通用）。照 hip_packer.qt 抄，多带一个 QtSvg。

优先级：
  1. hutil.Qt  —— Houdini 自带，跟着主程序的 Qt 版本走
                  （H20.5 = PySide2/Qt5，H21+ = PySide6/Qt6）
  2. PySide6   —— 脱离 Houdini 单独运行时（Qt6）
  3. PySide2   —— 脱离 Houdini 单独运行时（Qt5）

对外暴露
    BINDING      实际用到的绑定名，方便日志里写清楚
    QtCore / QtGui / QtWidgets / QtUiTools / QtSvg
    Qt / Signal / Slot
    QT_VERSION（Qt 版本，如 5.15.2）/ QT_MAJOR / IS_QT6
    enum_of(group, name)   Qt5 旧枚举写法与 Qt6 作用域写法的通用取值器

为什么要 enum_of：
    Qt5 里是 Qt.AlignCenter，Qt6 里必须写 Qt.AlignmentFlag.AlignCenter；
    Qt5 里是 QHeaderView.Stretch，Qt6 里是 QHeaderView.ResizeMode.Stretch。
"""

import os
import sys

from ._env import ensure_dll_dir

#: 必须在 import Qt 之前把 <HFS>/bin 加进 DLL 搜索路径
HFS = ensure_dll_dir()

BINDING = None
QtCore = QtGui = QtWidgets = None

try:                                              # 1) Houdini 内置 shim
    from hutil.Qt import QtCore, QtGui, QtWidgets  # noqa: F401
    BINDING = "hutil.Qt"
except Exception:                                 # noqa: BLE001
    try:                                          # 2) PySide6
        from PySide6 import QtCore, QtGui, QtWidgets  # noqa: F401
        BINDING = "PySide6"
    except Exception:                             # noqa: BLE001
        from PySide2 import QtCore, QtGui, QtWidgets  # noqa: F401
        BINDING = "PySide2"


def _import_module(name):
    from importlib import import_module
    try:
        return import_module(name)
    except Exception:                             # noqa: BLE001
        return None


def _import_sub(name):
    """按 BINDING 的优先级，把某个子模块（QtUiTools / QtSvg）找出来。"""
    order = ["hutil.Qt", "PySide6", "PySide2"]
    if BINDING in order:
        order.remove(BINDING)
        order.insert(0, BINDING)
    for base in order:
        module = _import_module(base + "." + name)
        if module is not None:
            return module
    return None


QtUiTools = _import_sub("QtUiTools")
QtSvg = _import_sub("QtSvg")

Qt = QtCore.Qt
Signal = QtCore.Signal
Slot = QtCore.Slot


def _detect_qt_version():
    """拿到 Qt 的版本号（形如 "5.15.2"）。

    坑：在 Houdini 里走的是 hutil.Qt 那层壳，`QtCore` 是 hutil 自己拼出来的
    模块，**没有 __version__**，直接取会 AttributeError。
    """
    try:
        version = QtCore.qVersion()
        if version:
            return str(version)
    except Exception:                                         # noqa: BLE001
        pass
    version = getattr(QtCore, "__version__", None)
    if version:
        return str(version)
    for name in ("PySide6", "PySide2"):
        try:
            version = getattr(__import__(name), "__version__", None)
        except Exception:                                     # noqa: BLE001
            version = None
        if version:
            return str(version)
    return "unknown"


def _qt_major():
    for candidate in (None, QT_VERSION):
        try:
            text = str(QtCore.qVersion()) if candidate is None else candidate
            return int(text.split(".")[0])
        except Exception:                                     # noqa: BLE001
            continue
    return 0


QT_VERSION = _detect_qt_version()
QT_MAJOR = _qt_major()
IS_QT6 = QT_MAJOR >= 6


def _is_enum_value(value):
    """是不是一个可用的枚举值（Qt5 的 int 写法、Qt6 / PySide2-5.15 的枚举成员都算）。"""
    if value is None or isinstance(value, (bool, str, bytes)):
        return False
    if isinstance(value, int):
        return True
    return not isinstance(value, type) and not callable(value)


def enum_of(group, name):
    """取枚举值，兼容 Qt5 / Qt6 两种写法。"""
    value = getattr(group, name, None)
    if _is_enum_value(value):
        return value
    for attr in dir(group):                   # Qt6：枚举被收进作用域类
        sub = getattr(group, attr, None)
        if isinstance(sub, type) and hasattr(sub, name):
            candidate = getattr(sub, name)
            if _is_enum_value(candidate):
                return candidate
    raise AttributeError("%r 里找不到枚举 %s" % (group, name))


def combine(*values):
    """把多个枚举 / flag 拼起来（Qt6 的 Flag 与 Qt5 的 int 都吃得下）。"""
    if not values:
        return 0
    out = values[0]
    for value in values[1:]:
        try:
            out = out | value
        except TypeError:
            out = int(out) | int(value)
    return out


def event_pos(event):
    """鼠标事件的坐标：Qt6 是 position()（浮点），Qt5 是 pos()。"""
    getter = getattr(event, "position", None)
    if getter is not None:
        try:
            return getter().toPoint()
        except Exception:                                     # noqa: BLE001
            pass
    try:
        return event.pos()
    except Exception:                                         # noqa: BLE001
        try:
            return event.globalPos()
        except Exception:                                     # noqa: BLE001
            from .qt import QtCore as _C
            return _C.QPoint(0, 0)


def exec_box(box):
    """弹一个 QDialog / QMessageBox，返回它的结果。

    Qt5 叫 `exec_()`，Qt6 把下划线去掉了叫 `exec()`。别再写死 `exec_()` ——
    在 PySide6 上会 AttributeError（这个坑在 updater / publisher 里踩过）。
    """
    for name in ("exec", "exec_"):
        method = getattr(box, name, None)
        if method is None:
            continue
        try:
            return method()
        except (TypeError, AttributeError):                # noqa: BLE001
            continue
    return None


def start_drag(drag, supported_actions=None):
    """发起拖拽：Qt5 叫 exec_()，Qt6 叫 exec()。"""
    if supported_actions is not None:
        for name in ("exec", "exec_"):
            method = getattr(drag, name, None)
            if method is not None:
                try:
                    return method(supported_actions)
                except TypeError:
                    continue
    for name in ("exec", "exec_"):
        method = getattr(drag, name, None)
        if method is not None:
            try:
                return method()
            except TypeError:
                continue
    return None


__all__ = [
    "BINDING", "QtCore", "QtGui", "QtWidgets", "QtUiTools", "QtSvg",
    "Qt", "Signal", "Slot", "QT_VERSION", "QT_MAJOR", "IS_QT6", "HFS",
    "enum_of", "combine", "event_pos", "start_drag", "exec_box",
]
