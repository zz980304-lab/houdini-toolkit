# -*- coding: utf-8 -*-
"""Houdini 桥：**整个工具里唯一 import hou 的地方**。

别的模块一律不准 import hou —— 这样界面能脱离 Houdini 跑（_preview.py 自检），
也方便以后把这套东西挪到独立进程 / Blender 之类的地方。

实测结论（H20.5.410，2026-10-18，记下来免得下次又踩）：
  ① `parent.saveItemsToFile(items, file_path)` —— **节点在前、路径在后**！
     顺序写反会抛 `TypeError: argument 2 of type vector<HOM_NetworkMovableItem*>`。
  ② `parent.loadItemsFromFile(file_path)` **返回 None**（不是节点列表），
     要拿新节点只能比对 load 前后 children() 的差集。
  ③ `node.asCode(recurse=True)` 才有子节点；默认不含。
  ④ `hou.ui.paneTabUnderCursor()` 存在，但从脚本里调常常返回 None，
     所以一律带退路：`paneTabOfType(NetworkEditor).pwd()`。
  ⑤ 没有 `GeometryViewport.screenshot()` / `takeViewportScreenshot()`（20.5 没有）。
     截视口只能走 Qt：`paneTab.qtScreenGeometry()` 拿屏幕矩形 →
     `QScreen.grabWindow(0, 局部坐标...)` → 按屏裁切。多屏时必须换算成
     "该屏的局部坐标"，否则会抓到别的屏幕的内容。
"""

import os
import time

from .qt import QtCore, QtGui, QtWidgets

_HOU = None
_HOU_TRIED = False


# ------------------------------------------------------------------ 基础
def hou():
    """惰性拿 hou 模块；不在 Houdini 里返回 None（不抛）。"""
    global _HOU, _HOU_TRIED
    if _HOU_TRIED:
        return _HOU
    _HOU_TRIED = True
    try:
        import hou as _module                            # noqa: F401
        _HOU = _module
    except Exception:                                    # noqa: BLE001
        _HOU = None
    return _HOU


def available():
    return hou() is not None


def _enum(group, name):
    try:
        return getattr(group, name)
    except Exception:                                    # noqa: BLE001
        return None


# ------------------------------------------------------------------ 网络 / 选择
def current_network():
    """当前网络编辑器的 pwd；没有网络编辑器就退回 hou.pwd()。"""
    module = hou()
    if module is None:
        return None
    try:
        editor = module.ui.paneTabOfType(module.paneTabType.NetworkEditor)
        if editor is not None:
            return editor.pwd()
    except Exception:                                    # noqa: BLE001
        pass
    try:
        return module.pwd()
    except Exception:                                    # noqa: BLE001
        return None


def pane_tab_under_cursor():
    module = hou()
    if module is None:
        return None
    try:
        return module.ui.paneTabUnderCursor()
    except Exception:                                    # noqa: BLE001
        return None


def drop_target_network():
    """拖拽落点所在的网络层级（拿不到就用当前网络）。

    ⚠️ 这个函数**永远会返回一个网络**，所以只能给"双击放到当前网络"这类
    明确要兜底的场景用。**拖拽落点判断不许用它** —— 否则用户拖到空白处
    松手也会建出节点。拖拽一律走 `drop_spot()`，它拿不到就返回 None。
    """
    module = hou()
    tab = pane_tab_under_cursor()
    if tab is not None and module is not None:
        try:
            if tab.type() == module.paneTabType.NetworkEditor:
                return tab.pwd()
        except Exception:                                # noqa: BLE001
            pass
    return current_network()


def network_editors():
    """当前**显示中**的网络编辑器。

    ⚠️ 实测（20.5）—— 三条坑，都踩过：
    1. `hou.paneTabs()` **不存在**（AttributeError）。只有 `hou.ui.panes()`。
    2. 同一个 pane 里所有 tab 共用 pane 的屏幕矩形（`qtScreenGeometry()`
       返回的是 pane 的 QRect），所以只认 `pane.currentTab()`，不然会把
       藏在后面的 tab 也当成"鼠标在上面"。
    3. 网络编辑器画布是 native child window，`QApplication.widgetAt()` 和
       `findChildren()` 都找不到它（probe 里 0 个匹配），Qt 遍历路线不通。
    """
    module = hou()
    if module is None:
        return []
    editors = []
    try:
        panes = module.ui.panes()
    except Exception:                                    # noqa: BLE001
        return []
    for pane in panes or []:
        try:
            tab = pane.currentTab()
        except Exception:                                # noqa: BLE001
            continue
        if tab is None:
            continue
        try:
            if tab.type() == module.paneTabType.NetworkEditor:
                editors.append(tab)
        except Exception:                                # noqa: BLE001
            continue
    return editors


def _tab_rect(tab):
    """pane tab 的屏幕矩形，返回 (x, y, w, h)；拿不到返回 None。"""
    try:
        rect = tab.qtScreenGeometry()
    except Exception:                                    # noqa: BLE001
        return None
    try:
        x = int(rect.x())
        y = int(rect.y())
        w = int(rect.width())
        h = int(rect.height())
    except Exception:                                    # noqa: BLE001
        try:
            x, y, w, h = (int(rect[0]), int(rect[1]),
                          int(rect[2]), int(rect[3]))
        except Exception:                                # noqa: BLE001
            return None
    if w <= 4 or h <= 4:                                 # 面板没显示
        return None
    return (x, y, w, h)


def _view_center(tab):
    """网络编辑器可视区中心的网络坐标（cursorPosition 拿不到时的兜底）。"""
    try:
        bounds = tab.visibleBounds()
    except Exception:                                    # noqa: BLE001
        return None
    try:
        center = bounds.center()
        return (float(center[0]), float(center[1]))
    except Exception:                                    # noqa: BLE001
        pass
    try:
        # BoundingRect 只有 min() / max()（返回 Vector2），没有 minx()
        low = bounds.min()
        high = bounds.max()
        return ((float(low[0]) + float(high[0])) * 0.5,
                (float(low[1]) + float(high[1])) * 0.5)
    except Exception:                                    # noqa: BLE001
        return None


def _cursor_network_pos(tab):
    """鼠标在这个网络里的坐标 —— Houdini 自己算的，比我们自己换算准。"""
    try:
        point = tab.cursorPosition()
        return (float(point[0]), float(point[1]))
    except Exception:                                    # noqa: BLE001
        return None


def drop_spot(cursor=None):
    """鼠标底下能不能放节点。返回 (network, (net_x, net_y)) 或 None。

    (net_x, net_y) 是鼠标**在这个网络里**的坐标 —— 松手就把节点放这儿，
    不再是"保存时的位置"。

    拿不到落点就返回 None，**调用方必须据此取消本次拖拽**。
    这是用户明确要的行为：拖到面板上 / 桌面 / 别的面板松手 = 什么都不做。
    """
    module = hou()
    if module is None:
        return None
    if cursor is None:
        try:
            from .qt import QtGui
            cursor = QtGui.QCursor.pos()
        except Exception:                                # noqa: BLE001
            return None
    try:
        cx = float(cursor.x())
        cy = float(cursor.y())
    except Exception:                                    # noqa: BLE001
        return None

    fallback = None
    for tab in network_editors():
        rect = _tab_rect(tab)
        if rect is None:
            continue
        x, y, w, h = rect
        inside = x <= cx <= x + w and y <= cy <= y + h
        # 拖拽期间鼠标被我们的面板抓着（mouse grab），Qt 的 underMouse 不准，
        # 所以主判据是几何矩形；isUnderCursor 只当补充
        if not inside:
            if fallback is None:
                try:
                    if tab.isUnderCursor():
                        fallback = tab
                except Exception:                        # noqa: BLE001
                    pass
            continue
        try:
            network = tab.pwd()
        except Exception:                                # noqa: BLE001
            network = None
        if network is None:
            continue
        return network, (_cursor_network_pos(tab) or _view_center(tab))

    if fallback is not None:
        try:
            network = fallback.pwd()
        except Exception:                                # noqa: BLE001
            network = None
        if network is not None:
            return network, (_cursor_network_pos(fallback)
                             or _view_center(fallback))
    return None


def current_view_spot():
    """当前网络编辑器：返回 (network, 可视区中心)。给"双击放到当前网络"用。"""
    module = hou()
    if module is None:
        return None
    try:
        editor = module.ui.paneTabOfType(module.paneTabType.NetworkEditor)
    except Exception:                                    # noqa: BLE001
        editor = None
    if editor is None:
        return None
    try:
        network = editor.pwd()
    except Exception:                                    # noqa: BLE001
        return None
    if network is None:
        return None
    try:
        bounds = editor.visibleBounds()
        center = bounds.center()
        return network, (float(center[0]), float(center[1]))
    except Exception:                                    # noqa: BLE001
        return network, None


def selected_nodes():
    module = hou()
    if module is None:
        return []
    try:
        return list(module.selectedNodes())
    except Exception:                                    # noqa: BLE001
        return []


def select_nodes(nodes):
    module = hou()
    if module is None:
        return False
    try:
        module.clearAllSelected()
        for node in nodes or []:
            node.setSelected(True)
        return True
    except Exception:                                    # noqa: BLE001
        return False


def _category_of(node):
    """节点所属网络的 category 名（GEO 里是 Sop，/out 里是 Driver…）。"""
    try:
        category = node.parent().childTypeCategory()
        if category is not None:
            return category.name()
    except Exception:                                    # noqa: BLE001
        pass
    try:
        return node.type().category().name()
    except Exception:                                    # noqa: BLE001
        return ""


def describe(nodes):
    """节点列表 → 存进 meta 的那点信息。"""
    nodes = list(nodes or [])
    info = {"context": "", "node_types": [], "node_names": [],
            "node_count": len(nodes), "source_path": ""}
    if not nodes:
        return info
    first = nodes[0]
    info["context"] = _category_of(first)
    try:
        info["source_path"] = first.parent().path()
    except Exception:                                    # noqa: BLE001
        info["source_path"] = ""
    types = []
    names = []
    for node in nodes:
        try:
            type_name = node.type().name().split("::")[0]   # 去掉 ::2.0 版本后缀
        except Exception:                                # noqa: BLE001
            type_name = ""
        if type_name and type_name not in types:
            types.append(type_name)
        try:
            names.append(node.name())
        except Exception:                                # noqa: BLE001
            pass
    info["node_types"] = types
    info["node_names"] = names
    return info


def same_parent(nodes):
    nodes = list(nodes or [])
    if not nodes:
        return True
    try:
        parent = nodes[0].parent().path()
        return all(n.parent().path() == parent for n in nodes)
    except Exception:                                    # noqa: BLE001
        return False


# ------------------------------------------------------------------ 存节点
def save_nodes(nodes, directory, header=""):
    """把节点存进 directory：nodes.cpio（主）+ nodes.py（兜底）。

    返回 describe() 的 dict，另外多一个 "error"（成功是空串）。
    """
    nodes = [n for n in (nodes or [])]
    info = describe(nodes)
    info["error"] = ""
    if not nodes:
        info["error"] = "没有选中的节点"
        return info
    if not same_parent(nodes):
        info["error"] = "选中的节点不在同一个网络里（跨层级没法存成一个预设）"
        return info
    if not os.path.isdir(directory):
        try:
            os.makedirs(directory)
        except Exception as exc:                         # noqa: BLE001
            info["error"] = "建目录失败：%r" % exc
            return info

    parent = nodes[0].parent()
    cpio = os.path.join(directory, "nodes.cpio")
    try:
        parent.saveItemsToFile(nodes, cpio)              # ← 节点在前！见文件头 ①
    except Exception as exc:                             # noqa: BLE001
        info["error"] = "saveItemsToFile 失败：%r" % exc

    # 兜底代码：cpio 跨大版本可能读不进，留一份能 exec 的 python
    try:
        chunks = ["# -*- coding: utf-8 -*-",
                  "# 由节点预设库自动生成：%s" % time.strftime("%Y-%m-%d %H:%M:%S")]
        if header:
            chunks.insert(1, "# %s" % header)
        chunks.append("import hou")
        chunks.append("")
        # ⚠️ asCode() 生成的代码用的是 `hou_parent`（不是 parent！），而且只在
        # `locals().get("hou_parent") is None` 时才自己去 hou.node(原路径)。
        # 所以放预设时只要往 exec 的环境里塞一个 hou_parent，节点就会落在目标网络；
        # 单独跑这个文件时拿不到注入，才退回原来的路径。
        chunks.append("# 放预设时外部会塞 hou_parent（目标网络）；没有就用原来的位置")
        chunks.append('if locals().get("hou_parent") is None:')
        chunks.append("    hou_parent = hou.node(%r) or hou.pwd()"
                      % (info["source_path"] or "/obj"))
        chunks.append("parent = hou_parent")
        chunks.append("")
        for node in nodes:
            try:
                code = node.asCode(recurse=True)
            except Exception:                            # noqa: BLE001
                code = ""
            if code:
                chunks.append(code.strip())
                chunks.append("")
        with open(os.path.join(directory, "nodes.py"), "w",
                  encoding="utf-8") as handle:
            handle.write("\n".join(chunks))
    except Exception:                                    # noqa: BLE001
        pass
    return info


# ------------------------------------------------------------------ 取节点
def _child_paths(node):
    try:
        return set(child.path() for child in node.children())
    except Exception:                                    # noqa: BLE001
        return set()


def _context_mismatch(target, context):
    """目标网络和预设层级对不上时，返回中文说明；对得上返回空串。"""
    if not context:
        return ""
    try:
        category = target.childTypeCategory()
        target_name = category.name() if category is not None else ""
    except Exception:                                     # noqa: BLE001
        return ""
    if not target_name:
        return ""
    try:
        from . import contexts
        if contexts.key_of(target_name) == contexts.key_of(context):
            return ""
        return ("这个预设是「%s」层级的，当前在「%s」里放不下。\n"
                "先双击进到对应的网络（比如 %s 层），再放。"
                % (contexts.label_of(context), contexts.label_of(target_name),
                   contexts.label_of(context)))
    except Exception:                                     # noqa: BLE001
        return ""


def _place_nodes(nodes, position):
    """把刚放进来的一批节点整体挪到 position（保持它们之间的相对布局）。

    不挪的话节点会落在**保存时**的坐标上：换个网络就在视野外，用户以为没放上。
    position 是 (net_x, net_y)，通常来自 drop_spot() 的鼠标落点。
    """
    if not position:
        return
    try:
        center_x = float(position[0])
        center_y = float(position[1])
    except Exception:                                     # noqa: BLE001
        return
    module = hou()
    if module is None:
        return
    live = []
    for node in nodes or []:
        try:
            if node is not None and node.position() is not None:
                live.append(node)
        except Exception:                                 # noqa: BLE001
            continue
    if not live:
        return
    xs = []
    ys = []
    for node in live:
        try:
            point = node.position()
            xs.append(float(point[0]))
            ys.append(float(point[1]))
        except Exception:                                 # noqa: BLE001
            continue
    if not xs or not ys:
        return
    offset_x = center_x - (min(xs) + max(xs)) * 0.5
    offset_y = center_y - (min(ys) + max(ys)) * 0.5
    if abs(offset_x) < 0.002 and abs(offset_y) < 0.002:
        return
    for node in live:
        try:
            point = node.position()
            node.setPosition(module.Vector2(point[0] + offset_x,
                                            point[1] + offset_y))
        except Exception:                                 # noqa: BLE001
            continue


def load_preset(directory, parent=None, context="", position=None):
    """把预设放回 Houdini。返回 (新节点列表, 错误说明)。

    先试 cpio（保留连线/参数最完整）；读不进来再退到 nodes.py。

    context 是预设自己的层级（meta["context"]，如 "Sop"）。给了就先比对目标
    网络的层级：GEO 的预设塞进 OBJ 会失败，而且报错信息很难懂（实测只会说
    "没新增节点"），所以这里提前拦掉并说人话。

    position=(x, y) 给的话，新节点会被整体挪到这个网络坐标（鼠标落点）；
    不给就保持 cpio 里记的原位置。
    """
    module = hou()
    if module is None:
        return [], "当前不在 Houdini 里"
    directory = str(directory or "")
    cpio = os.path.join(directory, "nodes.cpio")
    code = os.path.join(directory, "nodes.py")
    target = parent or drop_target_network()
    if target is None:
        return [], "拿不到目标网络"
    try:
        # ⚠️ 往 "/" 里 loadItemsFromFile 会把 hython 挂死（实测），必须挡住
        if target.path() == "/":
            return [], "当前在根目录（/）。先双击进入某个网络（比如 /obj/geo1），再放。"
    except Exception:                                     # noqa: BLE001
        pass

    mismatch = _context_mismatch(target, context)
    if mismatch:
        return [], mismatch

    errors = []
    if os.path.isfile(cpio):
        before = _child_paths(target)
        try:
            target.loadItemsFromFile(cpio)               # 返回 None，见文件头 ②
            after = _child_paths(target)
            new_paths = sorted(after - before)
            if new_paths:
                nodes = [module.node(path) for path in new_paths]
                select_nodes(nodes)
                _place_nodes(nodes, position)
                return [n for n in nodes if n is not None], ""
            errors.append("cpio 读进来但没新增节点")
        except Exception as exc:                         # noqa: BLE001
            errors.append("cpio 失败：%r" % exc)

    if os.path.isfile(code):
        before = _child_paths(target)
        try:
            with open(code, "r", encoding="utf-8") as handle:
                text = handle.read()
            # hou_parent 是 asCode() 认的那个变量 —— 不塞它，节点会被建回原路径
            environment = {"hou": module, "parent": target,
                           "hou_parent": target}
            exec(compile(text, code, "exec"), environment)   # noqa: S102
            after = _child_paths(target)
            new_paths = sorted(after - before)
            if new_paths:
                nodes = [module.node(path) for path in new_paths]
                select_nodes(nodes)
                _place_nodes(nodes, position)
                return [n for n in nodes if n is not None], "（用代码重建的）"
            errors.append("代码重建没新增节点")
        except Exception as exc:                         # noqa: BLE001
            errors.append("nodes.py 失败：%r" % exc)

    return [], "；".join(errors) or "预设里没有可用的节点数据"


# ------------------------------------------------------------------ 截视口
def screenshot_viewport(dst_path, width=0):
    """截当前 SceneViewer 的视口存成 png。

    走 Qt 的屏幕抓取（20.5 没有 Houdini 侧的截图 API）。
    ⚠️ 抓的是**屏幕上那块像素**，所以如果视口被别的窗口挡住，会连挡住的窗口一起抓进去。
    """
    module = hou()
    if module is None:
        return ""
    try:
        viewer = module.ui.paneTabOfType(module.paneTabType.SceneViewer)
        if viewer is None:
            return ""
        rect = viewer.qtScreenGeometry()
    except Exception:                                    # noqa: BLE001
        return ""

    app = QtWidgets.QApplication.instance()
    if app is None:
        return ""
    try:
        screen = app.screenAt(rect.center()) or app.primaryScreen()
        geo = screen.geometry()
        local_x = rect.x() - geo.x()
        local_y = rect.y() - geo.y()
        pixmap = screen.grabWindow(0, local_x, local_y,
                                   rect.width(), rect.height())
    except Exception:                                    # noqa: BLE001
        return ""

    if pixmap is None or pixmap.isNull():
        return ""
    if width and pixmap.width() > width:
        pixmap = pixmap.scaledToWidth(
            int(width), enum_scale_smooth())

    parent = os.path.dirname(os.path.abspath(dst_path))
    if parent and not os.path.isdir(parent):
        try:
            os.makedirs(parent)
        except Exception:                                # noqa: BLE001
            return ""
    try:
        if pixmap.save(dst_path, "PNG"):
            return dst_path
    except Exception:                                    # noqa: BLE001
        pass
    return ""


def enum_scale_smooth():
    """Qt5：Qt.SmoothTransformation；Qt6：Qt.TransformationMode.SmoothTransformation。"""
    from .qt import Qt, enum_of
    try:
        return enum_of(Qt, "SmoothTransformation")
    except Exception:                                    # noqa: BLE001
        return 1


# ------------------------------------------------------------------ 杂项
def reveal_in_explorer(path):
    """在资源管理器里打开（Windows）。"""
    try:
        import subprocess
        path = os.path.normpath(path)
        if os.path.isdir(path):
            subprocess.Popen(["explorer", path])
        else:
            subprocess.Popen(["explorer", "/select,", path])
        return True
    except Exception:                                    # noqa: BLE001
        return False


def status_text(text):
    try:
        module = hou()
        if module is not None:
            module.ui.setStatusMessage(str(text))
        return True
    except Exception:                                    # noqa: BLE001
        return False


__all__ = ["available", "hou", "current_network", "pane_tab_under_cursor",
           "drop_target_network", "network_editors", "drop_spot",
           "current_view_spot", "selected_nodes", "select_nodes",
           "describe", "same_parent", "save_nodes", "load_preset",
           "screenshot_viewport", "reveal_in_explorer", "status_text"]
