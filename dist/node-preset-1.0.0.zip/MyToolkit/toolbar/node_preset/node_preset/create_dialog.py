# -*- coding: utf-8 -*-
"""创建预设对话框 —— 拖节点进来 / 点"新建"之后弹它。

铁律同 ui.py：**不 import hou**。它只负责收信息：
    名字 / 简介 / 标签 / 层级（GEO、DOP、ROP…）/ 放在哪个文件夹 / 预览图
按了「保存」之后由 controller 去调 hou 取节点、落盘。

用户在需求里的原话："拖到界面哪里都出一个创建框，这个框可以写名字、简介、
放在哪里的分类" —— 所以这个框是整条新建流程的唯一入口，不管是拖进来的
还是点按钮，走的都是它。
"""

import os
import tempfile

from . import contexts, icons
from .ime import enable_ime, ime_widgets, install_ime_guard
from .qt import (QtCore, QtGui, QtWidgets, Qt, enum_of)
from .widgets import PreviewLabel, TagBar

_ALIGN_LEFT = enum_of(Qt, "AlignLeft")
_GIF_EXTS = (".gif", ".webp")


def _image_filter():
    return "图片 (*.png *.jpg *.jpeg *.gif *.webp *.bmp)"


class CreatePresetDialog(QtWidgets.QDialog):
    """新建 / 编辑预设的元信息。

    用法：
        dlg = CreatePresetDialog(parent, folders=..., context="Sop",
                                 folder_id="f_break", hint="来自刚拖进来的 3 个节点")
        if dlg.exec_dialog():
            data = dlg.values()      # dict: name/desc/tags/context/folder_id/preview
    """

    def __init__(self, parent=None, folders=None, context="",
                 folder_id="", hint="", preview="", title="保存为预设",
                 screenshot_provider=None):
        super(CreatePresetDialog, self).__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(560)
        self.setModal(True)
        self._folders = [f for f in (folders or []) if isinstance(f, dict)]
        self._preview = str(preview or "")
        self._hint = str(hint or "")
        self._screenshot = screenshot_provider
        self._temp_dir = ""
        self._ime_widgets_cache = None

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 10)
        layout.setSpacing(8)

        body = QtWidgets.QHBoxLayout()
        body.setSpacing(10)
        body.addLayout(self._build_preview_column(), 0)
        body.addLayout(self._build_form(), 1)
        layout.addLayout(body)

        layout.addWidget(QtWidgets.QLabel("简介"))
        self.desc_edit = QtWidgets.QPlainTextEdit()
        self.desc_edit.setPlaceholderText(
            "这堆节点是干嘛的、怎么用、注意什么…（可以留空，之后在右边详情里补）")
        self.desc_edit.setFixedHeight(84)
        layout.addWidget(self.desc_edit)

        layout.addWidget(QtWidgets.QLabel("标签"))
        self.tag_bar = TagBar()
        layout.addWidget(self.tag_bar)

        layout.addSpacing(2)
        footer = QtWidgets.QHBoxLayout()
        footer.setSpacing(6)
        self.hint_label = QtWidgets.QLabel(self._hint or "预览图可以不填，之后能改")
        self.hint_label.setObjectName("Hint")
        self.hint_label.setWordWrap(True)
        footer.addWidget(self.hint_label, 1)
        self.cancel_btn = QtWidgets.QPushButton("取消")
        self.cancel_btn.clicked.connect(self.reject)
        self.ok_btn = QtWidgets.QPushButton("保存为预设")
        self.ok_btn.setObjectName("Accent")
        self.ok_btn.setDefault(True)
        self.ok_btn.clicked.connect(self._on_accept)
        footer.addWidget(self.cancel_btn, 0)
        footer.addWidget(self.ok_btn, 0)
        layout.addLayout(footer)

        self._set_context(context)
        self._select_folder(folder_id)
        self._refresh_preview()
        self._update_ok_state()
        self.name_edit.textChanged.connect(self._update_ok_state)

        # 输入法：不装这个，Houdini 里名字 / 简介 / 标签都打不了中文
        install_ime_guard(self)

    # ============================================================ 布局
    def _build_preview_column(self):
        column = QtWidgets.QVBoxLayout()
        column.setSpacing(4)
        self.preview_label = PreviewLabel()
        self.preview_label.setFixedSize(196, 126)
        column.addWidget(self.preview_label)

        row = QtWidgets.QHBoxLayout()
        row.setSpacing(4)
        self.pick_btn = QtWidgets.QToolButton()
        self.pick_btn.setText("选图…")
        self.pick_btn.setToolTip("挑一张 png / jpg / gif 当预览")
        self.pick_btn.clicked.connect(self._on_pick_preview)
        self.paste_btn = QtWidgets.QToolButton()
        self.paste_btn.setText("粘贴")
        self.paste_btn.setToolTip("把剪贴板里的图贴进来")
        self.paste_btn.clicked.connect(self._on_paste_preview)
        self.clear_btn = QtWidgets.QToolButton()
        self.clear_btn.setText("清空")
        self.clear_btn.clicked.connect(self._on_clear_preview)
        row.addWidget(self.pick_btn)
        row.addWidget(self.paste_btn)
        if self._screenshot is not None:
            self.shot_btn = QtWidgets.QToolButton()
            self.shot_btn.setText("截视口")
            self.shot_btn.setToolTip(
                "把当前 SceneViewer 的画面截下来当预览\n（Houdini 被别的窗口挡住时，截到的会是挡住它的窗口）")
            self.shot_btn.clicked.connect(self._on_shot)
            row.addWidget(self.shot_btn)
        row.addWidget(self.clear_btn)
        row.addStretch(1)
        column.addLayout(row)

        self.preview_name = QtWidgets.QLabel("")
        self.preview_name.setObjectName("Hint")
        self.preview_name.setFixedWidth(196)
        self.preview_name.setWordWrap(True)
        column.addWidget(self.preview_name)
        column.addStretch(1)
        return column

    def _build_form(self):
        form = QtWidgets.QVBoxLayout()
        form.setSpacing(6)

        form.addWidget(QtWidgets.QLabel("名字"))
        self.name_edit = QtWidgets.QLineEdit()
        self.name_edit.setPlaceholderText("比如：破碎预处理 — voronoi + 分组")
        form.addWidget(self.name_edit)

        form.addWidget(QtWidgets.QLabel("分类"))
        row = QtWidgets.QHBoxLayout()
        row.setSpacing(6)

        self.context_combo = QtWidgets.QComboBox()
        self.context_combo.setMinimumWidth(96)
        for key in contexts.ORDER:
            self.context_combo.addItem(
                icons.icon("cube", contexts.COLORS.get(key, contexts.DEFAULT_COLOR), 14),
                contexts.label_of(key), key)
        row.addWidget(self.context_combo, 0)

        self.folder_combo = QtWidgets.QComboBox()
        self.folder_combo.setMinimumWidth(150)
        row.addWidget(self.folder_combo, 1)
        form.addLayout(row)

        self.context_combo.currentIndexChanged.connect(self._on_context_changed)
        return form

    # ============================================================ 分类
    def _set_context(self, context):
        key = contexts.key_of(context)
        index = self.context_combo.findData(key)
        if index < 0:
            index = 0
        self.context_combo.blockSignals(True)
        self.context_combo.setCurrentIndex(index)
        self.context_combo.blockSignals(False)
        self._rebuild_folder_combo()

    def current_context(self):
        return self.context_combo.currentData() or ""

    def _on_context_changed(self, _index):
        self._rebuild_folder_combo()

    def _folders_of(self, context, parent_id="", depth=0, out=None):
        """按父子关系摊平成一个带缩进的有序列表。"""
        out = [] if out is None else out
        children = [f for f in self._folders
                    if contexts.key_of(f.get("context")) == context
                    and (f.get("parent") or "") == (parent_id or "")]
        children.sort(key=lambda f: (int(f.get("order") or 0),
                                     str(f.get("name") or "")))
        for folder in children:
            out.append((folder, depth))
            self._folders_of(context, folder.get("id"), depth + 1, out)
        return out

    def _rebuild_folder_combo(self):
        keep = self.folder_combo.currentData() or ""
        context = self.current_context()
        self.folder_combo.blockSignals(True)
        self.folder_combo.clear()
        self.folder_combo.addItem(
            icons.icon("folder", "#5C6672", 14), "（不分类）", "")
        for folder, depth in self._folders_of(context):
            self.folder_combo.addItem(
                icons.icon(folder.get("shape") or "folder",
                           folder.get("color") or "#7C8794", 14),
                "%s%s" % ("　" * depth, folder.get("name") or "?"),
                folder.get("id"))
        self.folder_combo.blockSignals(False)
        self._select_folder(keep)

    def _select_folder(self, folder_id):
        index = self.folder_combo.findData(folder_id or "")
        self.folder_combo.setCurrentIndex(index if index >= 0 else 0)

    def current_folder(self):
        return self.folder_combo.currentData() or ""

    # ============================================================ 预览图
    def _refresh_preview(self):
        path = self._preview
        if path and os.path.isfile(path):
            self.preview_label.set_preview(path, 196, 126)
            name = os.path.basename(path)
            self.preview_name.setText(
                name if len(name) <= 26 else name[:23] + "…")
            self.preview_name.setToolTip(path)
        else:
            self.preview_label.clear_preview()
            self.preview_name.setText("（没图也能存）")
            self.preview_name.setToolTip("")

    def current_preview(self):
        path = self._preview
        return path if path and os.path.isfile(path) else ""

    def _on_pick_preview(self):
        path, _filter = QtWidgets.QFileDialog.getOpenFileName(
            self, "挑一张预览图", os.path.dirname(self._preview) or "",
            _image_filter())
        if path:
            self._preview = path
            self._refresh_preview()

    def _on_paste_preview(self):
        clipboard = QtWidgets.QApplication.clipboard()
        if clipboard is None:
            return
        image = clipboard.image()
        if image is not None and not image.isNull():
            base = os.path.join(tempfile.gettempdir(), "node_preset_clip")
            if not os.path.isdir(base):
                os.makedirs(base)
            path = os.path.join(base, "clip_%d.png" % int(QtCore.QDateTime
                                                          .currentMSecsSinceEpoch()))
            if image.save(path, "PNG"):
                self._preview = path
                self._refresh_preview()
                return
        urls = clipboard.mimeData().urls() if clipboard.mimeData() else []
        for url in urls:
            local = url.toLocalFile() if hasattr(url, "toLocalFile") else ""
            if local and os.path.splitext(local.lower())[1] in (
                    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"):
                self._preview = local
                self._refresh_preview()
                return
        self.hint_label.setText("剪贴板里没有图片")

    def _on_clear_preview(self):
        self._preview = ""
        self._refresh_preview()

    def _on_shot(self):
        """截当前视口（实现由 controller 注入，界面层不认识 hou）。"""
        if self._screenshot is None:
            return
        if not self._temp_dir:
            base = os.path.join(tempfile.gettempdir(), "node_preset_shot")
            if not os.path.isdir(base):
                try:
                    os.makedirs(base)
                except Exception:                         # noqa: BLE001
                    return
            self._temp_dir = base
        path = os.path.join(self._temp_dir, "shot_%d.png"
                            % int(QtCore.QDateTime.currentMSecsSinceEpoch()))
        try:
            result = self._screenshot(path)
        except Exception as exc:                          # noqa: BLE001
            self.hint_label.setText("截视口失败：%r" % exc)
            return
        if result:
            self._preview = result if isinstance(result, str) else path
            self._refresh_preview()
        else:
            self.hint_label.setText("截不到视口（可能 SceneViewer 没开着）")

    # ============================================================ 结果
    def _update_ok_state(self):
        self.ok_btn.setEnabled(bool(self.name_edit.text().strip()))

    def _on_accept(self):
        if not self.name_edit.text().strip():
            self.name_edit.setFocus()
            return
        self.accept()

    def values(self):
        """返回 controller 需要的那份 dict。"""
        return {
            "name": self.name_edit.text().strip(),
            "desc": self.desc_edit.toPlainText().strip(),
            "tags": list(self.tag_bar.tags()),
            "context": self.current_context(),
            "folder_id": self.current_folder(),
            "preview": self.current_preview(),
        }

    def set_values(self, data):
        """编辑已有预设时，把老信息灌回来。"""
        data = data or {}
        self.name_edit.setText(str(data.get("name") or ""))
        self.desc_edit.setPlainText(str(data.get("desc") or ""))
        self.tag_bar.set_tags(data.get("tags") or [])
        self._set_context(data.get("context") or "")
        self._select_folder(data.get("folder_id") or "")
        self._preview = str(data.get("preview") or "")
        self._refresh_preview()
        self._update_ok_state()

    def set_hint(self, text):
        self._hint = str(text or "")
        self.hint_label.setText(self._hint)

    def exec_dialog(self):
        """Qt5 是 exec_()，Qt6 是 exec()。"""
        for name in ("exec_", "exec"):
            method = getattr(self, name, None)
            if method is None:
                continue
            try:
                return bool(method())
            except TypeError:
                continue
        return False

    # ============================================================ 输入法
    def showEvent(self, event):                               # noqa: N802
        try:
            super(CreatePresetDialog, self).showEvent(event)
        except Exception:                                     # noqa: BLE001
            pass
        self._enable_ime()
        self.name_edit.setFocus()
        self.name_edit.selectAll()

    def _enable_ime(self):
        """打不了中文的坑见 ime.py；这里只是顺手在 show 的瞬间再补一次。"""
        enable_ime(ime_widgets(self))

    def _ime_targets(self):
        return ime_widgets(self)


__all__ = ["CreatePresetDialog"]
