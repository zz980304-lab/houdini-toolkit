# -*- coding: utf-8 -*-
"""拼音索引：把名字/标签/简介变成可以搜的拼音串。

为什么要自己包一层：
  * pypinyin 不是 Houdini 自带的，我们 vendor 在 `node_preset/_vendor/pypinyin`
    （3.3MB，去掉 .pyi/工具后）。
  * 万一 vendor 目录被人删了 / 21 上导入出问题，要能**降级不报错**：
    退化成"只按原文搜"，功能还在，只是打 ps 搜不到破碎。

对外
    has_pinyin()                 有没有可用的拼音库
    abbr(text) / full(text)      "测试2" → "cs2" / "ceshi2"（数字英文都留着）
    seq_match(text, word)        逐字匹配："测试2" 打 "ces2" 也中
    build(meta)                  把 py_abbr / py_full / py_abbr_tags 写进 meta
    score(meta, query)           给一条预设打分（0 = 不匹配）

⚠️ 非汉字（数字 / 英文 / 符号）**必须原样留在拼音串里**。
以前整串丢给 pypinyin 转，数字和英文会被吃掉：「测试2」索引成 "cs"，
于是打 "cs2" 永远搜不到。现在逐字处理：汉字转拼音，其它字符原样保留。

打分权重跟界面里那份兜底实现保持一致，**改这里也要改 ui._matches**：
    name 10 > tags 6 > node_types 4 > desc 2，拼音命中 × 0.8
"""

import os
import sys

_VENDOR_ADDED = False
_lazy_pinyin = None
_style = None
_ready = None


def _ensure_vendor():
    """把 `_vendor` 塞进 sys.path（只需一次）。"""
    global _VENDOR_ADDED
    if _VENDOR_ADDED:
        return
    vendor = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_vendor")
    if os.path.isdir(vendor) and vendor not in sys.path:
        sys.path.insert(0, vendor)
    _VENDOR_ADDED = True


def _load():
    """惰性导入；失败返回 False（不抛）。"""
    global _lazy_pinyin, _style, _ready
    if _ready is not None:
        return _ready
    _ensure_vendor()
    try:
        from pypinyin import lazy_pinyin, Style      # noqa: F401
        _lazy_pinyin = lazy_pinyin
        _style = Style
        _ready = True
    except Exception:                                 # noqa: BLE001
        _lazy_pinyin = None
        _style = None
        _ready = False
    return _ready


def has_pinyin():
    return _load()


def _is_cjk(ch):
    """这个字要不要交给拼音库（汉字才转，英文数字走原样）。"""
    code = ord(ch)
    return (0x3400 <= code <= 0x4DBF or 0x4E00 <= code <= 0x9FFF
            or 0xF900 <= code <= 0xFAFF or 0x20000 <= code <= 0x2A6DF)


_SEG_CACHE = {}
_SEG_LIMIT = 4000


def segments(text):
    """切成 [(首字母, 全拼), ...]：**一个字一段**。

    * 汉字 → ("c", "ce") 这种
    * 英文 / 数字 / 符号 → 原样（小写），两个都一样
    * 空白 → ("", "")，匹配时可以整段跳过

    结果按原文缓存（名字就那么几个字，别每次搜索都重算）。
    拿不到拼音库时返回 []，调用方自然退化成"只按原文搜"。
    """
    if not text:
        return []
    key = str(text)
    cached = _SEG_CACHE.get(key)
    if cached is not None:
        return cached
    segs = []
    if not _load():
        _SEG_CACHE[key] = segs
        return segs
    for ch in key:
        if ch.isspace():
            segs.append(("", ""))
            continue
        if not _is_cjk(ch):
            low = ch.lower()
            segs.append((low, low))
            continue
        try:
            first = "".join(_lazy_pinyin(ch, style=_style.FIRST_LETTER,
                                         errors="ignore"))
            whole = "".join(_lazy_pinyin(ch, style=_style.NORMAL,
                                         errors="ignore"))
        except Exception:                             # noqa: BLE001
            first = whole = ""
        if not first and not whole:
            low = ch.lower()
            segs.append((low, low))
        else:
            segs.append((first.lower(), whole.lower()))
    if len(_SEG_CACHE) > _SEG_LIMIT:
        _SEG_CACHE.clear()
    _SEG_CACHE[key] = segs
    return segs


def abbr(text):
    """首字母串：测试2 → cs2，RBD破碎 v2 → rbdpsv2。"""
    segs = segments(text)
    if not segs:
        return ""
    return "".join(first for first, _whole in segs)


def full(text):
    """全拼串：测试2 → ceshi2。"""
    segs = segments(text)
    if not segs:
        return ""
    return "".join(whole for _first, whole in segs)


def seq_match(text, word):
    """逐字匹配：查询按顺序走完各段就算命中，每段可以吃首字母或全拼。

    这是给"混着打"兜底的：「测试2」的段是 [c/ce, s/shi, 2/2]，于是
        cs2    → c + s + 2              ✓（其实 abbr 子串就能中）
        ceshi2 → ce + shi + 2           ✓
        ces2   → ce + s + 2             ✓ 只有这条必须靠逐字匹配
        shi2   → 从第二个字开始也行     ✓
    空白段自动跳过，所以 "破碎 v2" 打 "psv2" 也中。

    允许从中间起头，但**起头之后必须顺着走**：打 "ac" 不会命中 "abcdef"，
    那种"任意跳段"太松，噪音受不了。
    """
    segs = segments(text)
    if not segs:
        return False
    word = str(word or "").lower()
    if not word:
        return False
    rows = len(segs)
    total = len(word)
    if rows * (total + 1) > 200000:                   # 太长了，别算
        return False
    # 迭代 DP（不用递归：名字再长也不会爆栈）
    # dp[i][j]：从第 i 段、词里第 j 个字符开始，能不能顺着走完
    table = []
    nxt = [j >= total for j in range(total + 1)]
    for index in range(rows - 1, -1, -1):
        current = [False] * (total + 1)
        first, whole = segs[index]
        skippable = not first and not whole           # 空白段
        for at in range(total, -1, -1):
            if at >= total:
                current[at] = True
                continue
            ok = False
            if skippable:
                ok = nxt[at]
            if not ok:
                # 先试全拼（更长，一次吃掉更多），再试首字母
                for candidate in (whole, first):
                    if candidate and word.startswith(candidate, at):
                        ahead = at + len(candidate)
                        if ahead > total:
                            continue
                        if nxt[ahead]:
                            ok = True
                            break
            current[at] = ok
        table.append(current)
        nxt = current
    # 从哪一段起头都行（打后半截也要能搜到），但起头后必须顺着走
    return any(row[0] for row in table)


def build(meta):
    """就地补 meta 里的拼音字段（**只读文本，不改业务字段**）。"""
    if not isinstance(meta, dict):
        return meta
    name = str(meta.get("name") or "")
    meta["py_abbr"] = abbr(name)
    meta["py_full"] = full(name)
    tags = meta.get("tags") or []
    if isinstance(tags, (list, tuple)):
        meta["py_abbr_tags"] = abbr("".join(str(t) for t in tags))
    else:
        meta["py_abbr_tags"] = ""
    return meta


# ------------------------------------------------------------------ 搜索
def _field_text(value):
    if isinstance(value, (list, tuple)):
        return " ".join(str(v) for v in value)
    return str(value or "")


def _word_hit(meta, word):
    """一个词能拿到的最高分（0 = 没命中）。"""
    hit = 0
    for field, weight in (("name", 10), ("tags", 6),
                          ("node_types", 4), ("desc", 2)):
        if word in _field_text(meta.get(field)).lower():
            hit = max(hit, weight)
    if hit >= 10:
        return hit
    # 拼音串：命中打 0.8 折
    for field, weight in (("py_abbr", 10), ("py_full", 10),
                          ("py_abbr_tags", 6)):
        text = str(meta.get(field) or "").lower()
        if text and word in text:
            hit = max(hit, int(round(weight * 0.8)))
    # 逐字匹配兜底。这条不只是锦上添花 —— 老预设的 py_abbr 是"数字被吃掉"
    # 的版本（「测试2」存成 "cs"），只有现算一遍才能搜到 "cs2"
    for field, weight in (("name", 10), ("tags", 6)):
        if seq_match(_field_text(meta.get(field)), word):
            hit = max(hit, int(round(weight * 0.8)))
    return hit


def score(meta, query):
    """空格分词 AND；返回总分，0 表示不匹配。"""
    if not query:
        return 0
    words = [w for w in str(query).strip().lower().split() if w]
    if not words:
        return 0
    total = 0
    for word in words:
        hit = _word_hit(meta, word)
        if not hit:
            return 0
        total += hit
    return total


def matches(meta, query):
    return bool(score(meta, query))


__all__ = ["has_pinyin", "segments", "abbr", "full", "seq_match",
           "build", "score", "matches"]
