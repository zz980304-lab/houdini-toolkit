# -*- coding: utf-8 -*-
"""发布到 Git：把当前工具打包上传（调仓库里现成的 tools/release.py）。

为什么不自己写打包逻辑：
    `release.py` 已经封装了 make_shelf + build + commit + push + 代理通道探测，
    而且 build.py 是按模块 content_hash 判断的 —— 我们只改了 tool 的代码时，
    91MB 的 ffx 包不会被重打。自己重写一份只会漏掉这些细节。

注意：
    * `git add -A` 是在仓库目录里跑，所以务必确认 release.py 的 cwd 是 repo
    * 只会把 build_config.json 里登记的 sources 打进去；
      **node_preset/library/ 必须在 exclude 里**，别把 GIF 传上公开仓库
    * 这里不碰 token（仓库已经配好凭据）
"""

import os
import shutil
import sys

from . import paths
from .ime import install_ime_guard
from .qt import QtCore, QtGui, QtWidgets, Qt, enum_of, exec_box

_OK = enum_of(QtWidgets.QMessageBox, "Ok")
_WARNING = enum_of(QtWidgets.QMessageBox, "Warning")
_NO_ICON = enum_of(QtWidgets.QMessageBox, "NoIcon")


def python_exe():
    """找一个正经的 python 来跑工具脚本。

    ⚠️ 不能直接用 `shutil.which("python")`：在 Houdini 里 PATH 上排前面的往往是
    `<HFS>/python311/python.exe`，那个带脚本参数跑会以 127 退出（实测），
    而且会拖一堆 Houdini 的环境变量进去。所以先把 HFS 里的排除掉。
    """
    candidates = []
    for name in ("python", "python3", "py"):
        found = shutil.which(name)
        if found and found not in candidates:
            candidates.append(found)

    hfs = ""
    try:
        from .qt import HFS as _HFS
        hfs = (_HFS or "").replace("\\", "/").lower()
    except Exception:                                     # noqa: BLE001
        hfs = ""

    for candidate in candidates:
        path = candidate.replace("\\", "/").lower()
        if hfs and path.startswith(hfs):
            continue
        return candidate
    # 实在没有就用当前的解释器（Houdini 里就是 hython，跑 stdlib 脚本没问题，只是慢）
    return sys.executable or "python"


def release_script(repo=""):
    repo = repo or paths.repo_dir()
    if not repo:
        return ""
    candidate = os.path.join(repo, "tools", "release.py")
    return candidate if os.path.isfile(candidate) else ""


def ask_message(parent, default="节点预设库：更新"):
    """问一句 commit 说明。

    ⚠️ 不用 `QInputDialog.getText()` 那个静态快捷方式：拿不到对话框实例，
    就没法给它装输入法守卫（ime.py），在 Houdini 里照样打不了中文。
    """
    dialog = QtWidgets.QInputDialog(parent)
    dialog.setWindowTitle("发布到 Git")
    dialog.setLabelText("这次改了什么？（会写进 commit 和日志）")
    dialog.setTextValue(default or "")
    try:
        dialog.setOkButtonText("确定")
        dialog.setCancelButtonText("取消")
    except Exception:                                     # noqa: BLE001
        pass
    install_ime_guard(dialog)
    ok = bool(exec_box(dialog))
    if not ok:
        return ""
    text = str(dialog.textValue() or "").strip()
    return text or default


class PublishDialog(QtWidgets.QDialog):
    """跑 release.py 并把输出实时显示出来。"""

    def __init__(self, parent=None, repo="", message=""):
        super(PublishDialog, self).__init__(parent)
        self.setWindowTitle("发布到 Git")
        self.resize(720, 420)
        self._repo = repo
        self._message = message
        self._process = None
        self._failed = False

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(6)

        self.info = QtWidgets.QLabel(
            "仓库：%s\n说明：%s" % (repo, message))
        self.info.setObjectName("Hint")
        self.info.setWordWrap(True)
        layout.addWidget(self.info)

        self.log_view = QtWidgets.QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setLineWrapMode(
            enum_of(QtWidgets.QPlainTextEdit, "NoWrap"))
        layout.addWidget(self.log_view, 1)

        row = QtWidgets.QHBoxLayout()
        self.status = QtWidgets.QLabel("准备中…")
        self.status.setObjectName("Hint")
        row.addWidget(self.status, 1)
        self.open_btn = QtWidgets.QToolButton()
        self.open_btn.setText("打开仓库目录")
        self.open_btn.clicked.connect(
            lambda: self._open_repo())
        row.addWidget(self.open_btn)
        self.close_btn = QtWidgets.QPushButton("关闭")
        self.close_btn.clicked.connect(self.reject)
        self.close_btn.setEnabled(False)
        row.addWidget(self.close_btn)
        layout.addLayout(row)

        self._timer = QtCore.QTimer(self)
        self._timer.setInterval(500)
        self._timer.timeout.connect(self._tick)
        self._elapsed = 0

    # ---------------------------------------------------------- 执行
    def start(self):
        if not self._repo:
            self._append("找不到仓库目录（可用环境变量 HOUDINI_TOOLKIT_REPO 指定）")
            self._finish(False)
            return
        script = release_script(self._repo)
        if not script:
            self._append("仓库里没有 tools/release.py，先确认路径：%s" % self._repo)
            self._finish(False)
            return

        self._append("开始：%s %s" % (python_exe(), script))
        self._append("说明：%s" % self._message)
        self._append("")

        process = QtCore.QProcess(self)
        process.setWorkingDirectory(self._repo)
        try:
            process.setProcessChannelMode(
                enum_of(QtCore.QProcess, "MergedChannels"))
        except Exception:                                 # noqa: BLE001
            pass
        process.readyReadStandardOutput.connect(self._read)
        process.finished.connect(self._on_finished)
        # Qt5 叫 error()，Qt6 改叫 errorOccurred()
        error_signal = getattr(process, "errorOccurred", None)
        if error_signal is None:
            error_signal = getattr(process, "error", None)
        if error_signal is not None:
            try:
                error_signal.connect(self._on_error)
            except Exception:                             # noqa: BLE001
                pass
        process.start(python_exe(), [script, self._message])
        self._process = process
        self.status.setText("正在发布…")
        self._timer.start()

    def _read(self):
        process = self._process
        if process is None:
            return
        try:
            data = bytes(process.readAllStandardOutput())
        except Exception:                                 # noqa: BLE001
            return
        text = data.decode("utf-8", "replace")
        if text:
            self._append(text.rstrip("\n"))

    def _on_finished(self, code, _status=0):
        self._timer.stop()
        ok = int(code) == 0
        self._append("")
        self._append("完成，退出码 %s" % code if ok else "失败，退出码 %s" % code)
        self._finish(ok)

    def _on_error(self, _error):
        self._append("启动失败（找不到 python？）")
        self._finish(False)

    def _finish(self, ok):
        self._failed = not ok
        self.close_btn.setEnabled(True)
        self.status.setText("发布成功（Cloudflare 1~2 分钟后生效）" if ok
                            else "发布失败，看上面的日志")

    def _append(self, text):
        self.log_view.appendPlainText(str(text))
        bar = self.log_view.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _tick(self):
        self._elapsed += 0.5
        self.status.setText("正在发布… %.0f 秒" % self._elapsed)

    def _open_repo(self):
        if self._repo:
            try:
                import subprocess
                subprocess.Popen(["explorer", self._repo])
            except Exception:                             # noqa: BLE001
                pass

    def exec_dialog(self):
        for name in ("exec_", "exec"):
            method = getattr(self, name, None)
            if method is None:
                continue
            try:
                return bool(method())
            except TypeError:
                continue
        return False


def publish_from_ui(controller):
    win = getattr(controller, "win", None)
    repo = paths.repo_dir()
    if not repo:
        _warn(win, "找不到工具集仓库目录。\n"
                   "设环境变量 HOUDINI_TOOLKIT_REPO，或在 config.json 里写 repo_dir。")
        return False
    if not release_script(repo):
        _warn(win, "仓库里没有 tools/release.py：\n%s" % repo)
        return False

    message = ask_message(win)
    if not message:
        return False

    dialog = PublishDialog(win, repo, message)
    dialog.start()
    dialog.exec_dialog()
    return not dialog._failed


def _warn(parent, text):
    box = QtWidgets.QMessageBox(parent)
    box.setWindowTitle("发布到 Git")
    box.setIcon(_WARNING)
    box.setText(text)
    box.setStandardButtons(_OK)
    return exec_box(box)


__all__ = ["publish_from_ui", "PublishDialog", "release_script", "python_exe"]
