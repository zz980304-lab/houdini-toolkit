# -*- coding: utf-8 -*-
"""界面用的自绘控件。

这一层**不认识 hou，也不认识 store**：给它一个 dict 它就画。
    cards   网格 / 列表两种视图的委托（QStyledItemDelegate）
    PresetView  列表控件，负责 hover 时播 GIF、发起"拖出去"
    PreviewStore  缩略图 / GIF 的加载与缓存（按路径 + 尺寸缓存）
    DropOverlay  拖拽悬停时盖住整窗的提示层（不吃鼠标事件）
    TagBar    标签 chips（可增删）
"""

import os

from . import icons
from .ime import install_ime_guard
from .qt import (QtCore, QtGui, QtWidgets, Qt, Signal, enum_of, combine,
                 event_pos, start_drag)

_LEFT_BUTTON = enum_of(Qt, "LeftButton")
_SHIFT = enum_of(Qt, "ShiftModifier")
_CONTROL = enum_of(Qt, "ControlModifier")
_KEY_SHIFT = enum_of(Qt, "Key_Shift")
_SELECT_SINGLE = enum_of(QtWidgets.QAbstractItemView, "SingleSelection")
_SELECT_EXTENDED = enum_of(QtWidgets.QAbstractItemView, "ExtendedSelection")
_ROLE_DATA = enum_of(Qt, "UserRole")
_ELIDE_RIGHT = enum_of(Qt, "ElideRight")
_ALIGN_LEFT = enum_of(Qt, "AlignLeft")
_ALIGN_TOP = enum_of(Qt, "AlignTop")
_ALIGN_VCENTER = enum_of(Qt, "AlignVCenter")
_ALIGN_HCENTER = enum_of(Qt, "AlignHCenter")
_ALIGN_CENTER = enum_of(Qt, "AlignCenter")
_TEXT_WRAP = enum_of(Qt, "TextWordWrap")
_NO_PEN = enum_of(Qt, "NoPen")
_TRANSPARENT = enum_of(Qt, "transparent")
_STATE_SELECTED = enum_of(QtWidgets.QStyle, "State_Selected")
_STATE_MOUSE_OVER = enum_of(QtWidgets.QStyle, "State_MouseOver")

_GIF_EXTS = (".gif",)


# ================================================================ 缩略图缓存
class PreviewStore(object):
    """按 (路径, 宽, 高) 缓存 QPixmap；GIF 只取第一帧做静态图。

    动图本身不缓存（QMovie 有状态，同一张图到处播会互相抢帧），
    谁要播谁自己 new 一个。
    """

    #: 缓存上限：库里几百个预设 × 三种缩略图尺寸，不设上限会把内存吃干
    MAX = 240

    def __init__(self):
        self._static = {}
        self._missing = set()

    def pixmap(self, path, width, height):
        """拿一张缩略图；没有图 / 读不出来返回 None（交给调用方画占位）。"""
        if not path or path in self._missing:
            return None
        if not os.path.isfile(path):
            self._missing.add(path)
            return None
        key = (path, int(width), int(height))
        hit = self._static.get(key)
        if hit is not None:
            return hit

        reader = QtGui.QImageReader(path)
        reader.setAutoTransform(True)
        try:
            reader.setScaledSize(QtCore.QSize(int(width), int(height)))
        except Exception:                                     # noqa: BLE001
            pass
        image = reader.read()
        if image.isNull():
            self._missing.add(path)
            return None
        pm = QtGui.QPixmap.fromImage(image)
        # 超上限就丢最早的一半（dict 是插入有序的，够用，不搞真 LRU）
        if len(self._static) >= self.MAX:
            for old in list(self._static)[:self.MAX // 2]:
                self._static.pop(old, None)
        self._static[key] = pm
        return pm

    def is_animated(self, path):
        return bool(path) and os.path.splitext(str(path).lower())[1] in _GIF_EXTS

    def movie(self, path, width=0, height=0):
        """new 一个 QMovie（调用方自己管生命周期）。"""
        if not path or not os.path.isfile(path):
            return None
        mv = QtGui.QMovie(path)
        if not mv.isValid():
            return None
        if width and height:
            mv.setScaledSize(QtCore.QSize(int(width), int(height)))
        return mv

    def clear(self, path=None):
        if path is None:
            self._static.clear()
            self._missing.clear()
        else:
            for key in [k for k in self._static if k[0] == path]:
                self._static.pop(key, None)
            self._missing.discard(path)


def placeholder_color(text=""):
    """没有预览图时，按名字算一个稳定的占位色（同一个预设每次都一样）。"""
    seed = 0
    for ch in str(text or ""):
        seed = (seed * 31 + ord(ch)) & 0xFFFFFF
    hue = seed % 360
    color = QtGui.QColor()
    color.setHsl(hue, 90, 132)
    return color


# ================================================================ 卡片委托
class PresetDelegate(QtWidgets.QStyledItemDelegate):
    """网格卡片 / 列表行。两种模式都在这里画。"""

    THUMB_W = 150
    THUMB_H = 96
    CARD_H = 152
    ROW_H = 48

    def __init__(self, view, previews=None):
        super(PresetDelegate, self).__init__(view)
        self.view = view
        self.previews = previews or PreviewStore()
        self.grid = True

    # ---------------------------------------------------------- 尺寸
    def sizeHint(self, option, index):                        # noqa: N802
        if self.grid:
            return QtCore.QSize(self.THUMB_W + 12, self.CARD_H)
        # 列表模式一行铺满：写死 240 的话窗口宽一点就会挤出第二列，
        # 右边还露半截（看着像 bug）
        width = 240
        try:
            view = self.parent()
            viewport = view.viewport()
            if viewport is not None and viewport.width() > 80:
                width = max(180, viewport.width() - 6)
        except Exception:                                     # noqa: BLE001
            pass
        return QtCore.QSize(width, self.ROW_H)

    # ---------------------------------------------------------- 画
    def paint(self, painter, option, index):
        data = index.data(_ROLE_DATA)
        if not isinstance(data, dict):
            super(PresetDelegate, self).paint(painter, option, index)
            return
        painter.save()
        try:
            painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
            if self.grid:
                self._paint_card(painter, option, data)
            else:
                self._paint_row(painter, option, data)
        finally:
            painter.restore()

    def _card_rect(self, option):
        rect = QtCore.QRect(option.rect)
        rect.adjust(4, 4, -4, -4)
        return rect

    def _paint_card(self, painter, option, data):
        rect = self._card_rect(option)
        selected = bool(option.state & _STATE_SELECTED)
        hovered = bool(option.state & _STATE_MOUSE_OVER)

        # 卡片底
        path = QtGui.QPainterPath()
        path.addRoundedRect(rect.x(), rect.y(), rect.width(), rect.height(),
                            7, 7)
        base = option.palette.color(
            enum_of(QtGui.QPalette, "Window")).lighter(118 if hovered else 108)
        painter.setPen(_NO_PEN)
        painter.setBrush(base)
        painter.drawPath(path)

        if selected:
            pen = QtGui.QPen(option.palette.color(
                enum_of(QtGui.QPalette, "Highlight")))
            pen.setWidth(2)
            painter.setPen(pen)
            painter.setBrush(enum_of(Qt, "NoBrush"))
            painter.drawPath(path)
            painter.setPen(_NO_PEN)

        # 缩略图
        thumb = QtCore.QRect(rect.x() + 6, rect.y() + 6,
                             rect.width() - 12, self.THUMB_H)
        pm = self._thumb_pixmap(data, thumb.width(), thumb.height())
        painter.save()
        clip = QtGui.QPainterPath()
        clip.addRoundedRect(thumb.x(), thumb.y(), thumb.width(),
                            thumb.height(), 5, 5)
        painter.setClipPath(clip)
        if pm is not None and not pm.isNull():
            self._draw_pixmap_cover(painter, pm, thumb)
        else:
            color = placeholder_color(data.get("name", ""))
            painter.setBrush(color)
            painter.drawRect(thumb)
            painter.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255, 190)))
            painter.setBrush(enum_of(Qt, "NoBrush"))
            painter.drawText(thumb, _ALIGN_CENTER,
                             data.get("context_label") or "无预览")
            painter.setPen(_NO_PEN)
        painter.restore()

        # GIF 角标
        if self.previews.is_animated(data.get("preview")):
            badge = QtCore.QRect(thumb.right() - 32, thumb.bottom() - 18, 28, 14)
            painter.setBrush(QtGui.QColor(0, 0, 0, 150))
            painter.drawRoundedRect(badge, 3, 3)
            painter.setPen(QtGui.QPen(QtGui.QColor(255, 255, 255)))
            font = QtGui.QFont(painter.font())
            font.setPixelSize(9)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(badge, _ALIGN_CENTER, "GIF")
            painter.setPen(_NO_PEN)

        # 标题
        title_rect = QtCore.QRect(thumb.x(), thumb.bottom() + 6,
                                  thumb.width(), 20)
        fm = QtGui.QFontMetrics(painter.font())
        name = data.get("name") or "(未命名)"
        if data.get("favorite"):
            name = "★ " + name
        painter.setPen(option.palette.color(
            enum_of(QtGui.QPalette, "Text")))
        painter.drawText(title_rect, _ALIGN_LEFT | _ALIGN_VCENTER,
                         fm.elidedText(name, _ELIDE_RIGHT, title_rect.width()))

        # 元信息
        meta_rect = QtCore.QRect(title_rect.x(), title_rect.bottom() + 1,
                                 title_rect.width(), 16)
        painter.setPen(option.palette.color(
            enum_of(QtGui.QPalette, "Disabled"),
            enum_of(QtGui.QPalette, "Text")))
        font = QtGui.QFont(painter.font())
        font.setPixelSize(10)
        painter.setFont(font)
        painter.drawText(meta_rect, _ALIGN_LEFT | _ALIGN_VCENTER,
                         self._meta_text(data))

    def _paint_row(self, painter, option, data):
        rect = QtCore.QRect(option.rect)
        selected = bool(option.state & _STATE_SELECTED)
        hovered = bool(option.state & _STATE_MOUSE_OVER)

        if selected or hovered:
            painter.setPen(_NO_PEN)
            painter.setBrush(option.palette.color(
                enum_of(QtGui.QPalette, "Highlight") if selected
                else enum_of(QtGui.QPalette, "Window")).lighter(
                    112 if hovered else 100))
            if selected:
                painter.setOpacity(0.35 if not hovered else 0.5)
            painter.drawRect(rect)
            painter.setOpacity(1.0)

        thumb = QtCore.QRect(rect.x() + 6, rect.y() + 5, 62, rect.height() - 10)
        pm = self._thumb_pixmap(data, thumb.width(), thumb.height())
        painter.save()
        clip = QtGui.QPainterPath()
        clip.addRoundedRect(thumb.x(), thumb.y(), thumb.width(),
                            thumb.height(), 4, 4)
        painter.setClipPath(clip)
        if pm is not None and not pm.isNull():
            self._draw_pixmap_cover(painter, pm, thumb)
        else:
            painter.setBrush(placeholder_color(data.get("name", "")))
            painter.drawRect(thumb)
        painter.restore()

        text_x = thumb.right() + 8
        name_rect = QtCore.QRect(text_x, rect.y() + 4,
                                 rect.width() - (text_x - rect.x()) - 96, 18)
        fm = QtGui.QFontMetrics(painter.font())
        name = data.get("name") or "(未命名)"
        if data.get("favorite"):
            name = "★ " + name
        painter.setPen(option.palette.color(enum_of(QtGui.QPalette, "Text")))
        painter.drawText(name_rect, _ALIGN_LEFT | _ALIGN_VCENTER,
                         fm.elidedText(name, _ELIDE_RIGHT, name_rect.width()))

        desc_rect = QtCore.QRect(text_x, name_rect.bottom(),
                                 name_rect.width(), rect.height() - 22)
        font = QtGui.QFont(painter.font())
        font.setPixelSize(10)
        painter.setFont(font)
        painter.setPen(option.palette.color(
            enum_of(QtGui.QPalette, "Disabled"),
            enum_of(QtGui.QPalette, "Text")))
        painter.drawText(desc_rect, _ALIGN_LEFT | _ALIGN_VCENTER,
                         fm.elidedText((data.get("desc") or "").replace("\n", " "),
                                       _ELIDE_RIGHT, desc_rect.width()))

        right = QtCore.QRect(rect.right() - 88, rect.y(), 82, rect.height())
        font.setPixelSize(10)
        painter.setFont(font)
        painter.setPen(option.palette.color(
            enum_of(QtGui.QPalette, "Disabled"),
            enum_of(QtGui.QPalette, "Text")))
        painter.drawText(right, _ALIGN_LEFT | _ALIGN_VCENTER,
                         self._meta_text(data))

    def _meta_text(self, data):
        label = data.get("context_label") or ""
        count = data.get("node_count") or 0
        return "%s · %d 节点" % (label, count)

    def _thumb_pixmap(self, data, width, height):
        """先问 view 有没有正在播的 GIF 帧，没有再用静态图。"""
        live = None
        try:
            live = self.view.hover_frame(data.get("id"), width, height)
        except Exception:                                     # noqa: BLE001
            live = None
        if live is not None and not live.isNull():
            return live
        return self.previews.pixmap(data.get("preview"), width, height)

    @staticmethod
    def _draw_pixmap_cover(painter, pm, rect):
        """按 cover 方式把图铺进 rect（不留白、不变形）。"""
        if pm.isNull():
            return
        size = pm.size()
        if size.width() <= 0 or size.height() <= 0:
            return
        scale = max(float(rect.width()) / size.width(),
                    float(rect.height()) / size.height())
        w = int(size.width() * scale)
        h = int(size.height() * scale)
        painter.drawPixmap(rect.x() + (rect.width() - w) // 2,
                           rect.y() + (rect.height() - h) // 2,
                           w, h, pm)


# ================================================================ 列表视图
class PresetView(QtWidgets.QListWidget):
    """预设列表。负责：hover 播 GIF、右键菜单位置、发起"拖出去"。

    拖出去的实现说明（P3 会接上）：这里只发 `dragOut(preset_id)` 信号，
    **不**用 Qt 的 MIME drop —— Houdini 的网络编辑器不收外部 MIME，
    真正的落点判断靠 controller 那边问 hou.ui。
    """

    dragOut = Signal(str)                                     # noqa: N815
    contextMenu = Signal(str, QtCore.QPoint)                  # noqa: N815

    def __init__(self, parent=None):
        super(PresetView, self).__init__(parent)
        self.previews = PreviewStore()
        self.delegate = PresetDelegate(self, self.previews)
        self.setItemDelegate(self.delegate)
        self.setViewMode(enum_of(QtWidgets.QListWidget, "IconMode"))
        self.setMovement(enum_of(QtWidgets.QListWidget, "Static"))
        self.setResizeMode(enum_of(QtWidgets.QListWidget, "Adjust"))
        self.setFlow(enum_of(QtWidgets.QListWidget, "LeftToRight"))
        self.setWrapping(True)
        self.setSpacing(2)
        self.setUniformItemSizes(False)
        self.setMouseTracking(True)
        # 默认单选：这样拖卡片时不会冒出 Qt 的橡皮筋框选。
        # 按住 Shift 才切成多选（见 _set_multi），框选框也只在那时候出现。
        self.setSelectionMode(_SELECT_SINGLE)
        self._multi_on = None
        self._set_multi(False)
        self.setDragEnabled(False)
        self.setAcceptDrops(False)
        self.setToolTip("单击选中一个。\n"
                        "按住 Shift 拖动可以框选多个（批量删除 / 导出）。")

        self._hover_id = ""
        self._hover_movie = None
        self._press_pos = None
        self._press_id = ""
        self._drag_done = False       # 刚拖完，接下来的 release 别当点击
        self.empty_text = ("还没有预设。\n把网络编辑器里选中的节点拖进这个窗口，"
                           "或者点左上角「＋ 新建」。")

        self.itemEntered.connect(self._on_item_entered)
        self.customContextMenuRequested.connect(self._on_menu)
        self.setContextMenuPolicy(enum_of(QtCore.Qt, "CustomContextMenu"))

    # ---------------------------------------------------------- 视图模式
    def set_grid(self, grid):
        self.delegate.grid = bool(grid)
        if grid:
            self.setViewMode(enum_of(QtWidgets.QListWidget, "IconMode"))
            self.setFlow(enum_of(QtWidgets.QListWidget, "LeftToRight"))
            self.setGridSize(QtCore.QSize(PresetDelegate.THUMB_W + 12,
                                          PresetDelegate.CARD_H))
            self.setSpacing(2)
        else:
            self.setViewMode(enum_of(QtWidgets.QListWidget, "ListMode"))
            self.setFlow(enum_of(QtWidgets.QListWidget, "TopToBottom"))
            self.setGridSize(QtCore.QSize())
            self.setSpacing(1)
        self.scheduleDelayedItemsLayout()
        self.viewport().update()

    # ---------------------------------------------------------- hover 播 GIF
    def hover_frame(self, preset_id, width, height):
        """delegate 每帧来问：这张卡片现在有没有动图帧。"""
        if not preset_id or preset_id != self._hover_id:
            return None
        movie = self._hover_movie
        if movie is None or movie.state() != QtGui.QMovie.Running:
            return None
        pm = movie.currentPixmap()
        if pm.isNull():
            return None
        if pm.width() != width or pm.height() != height:
            pm = pm.scaled(int(width), int(height),
                           enum_of(Qt, "KeepAspectRatioByExpanding"),
                           enum_of(Qt, "SmoothTransformation"))
        return pm

    def _on_item_entered(self, item):
        data = item.data(_ROLE_DATA) if item else None
        path = (data or {}).get("preview") or ""
        pid = (data or {}).get("id") or ""
        if pid == self._hover_id:
            return
        self._stop_movie()
        self._hover_id = pid
        if path and self.previews.is_animated(path):
            movie = self.previews.movie(path, PresetDelegate.THUMB_W,
                                        PresetDelegate.THUMB_H)
            if movie is not None:
                self._hover_movie = movie
                movie.frameChanged.connect(self._on_movie_frame)
                movie.start()

    def _on_movie_frame(self, _frame):
        item = self.current_hover_item()
        if item is not None:
            self.viewport().update(self.visualRect(self.indexFromItem(item)))

    def current_hover_item(self):
        if not self._hover_id:
            return None
        for idx in range(self.count()):
            item = self.item(idx)
            data = item.data(_ROLE_DATA)
            if isinstance(data, dict) and data.get("id") == self._hover_id:
                return item
        return None

    def _stop_movie(self):
        movie = self._hover_movie
        if movie is not None:
            try:
                movie.frameChanged.disconnect(self._on_movie_frame)
            except Exception:                                 # noqa: BLE001
                pass
            movie.stop()
            movie.deleteLater()
        self._hover_movie = None
        self._hover_id = ""

    def resizeEvent(self, event):                             # noqa: N802
        super(PresetView, self).resizeEvent(event)
        # 列表模式的行宽跟着窗口变（sizeHint 要重新问一次）
        try:
            if not self.delegate.grid:
                self.scheduleDelayedItemsLayout()
        except Exception:                                     # noqa: BLE001
            pass

    def leaveEvent(self, event):                              # noqa: N802
        self._stop_movie()
        super(PresetView, self).leaveEvent(event)

    def paintEvent(self, event):                              # noqa: N802
        super(PresetView, self).paintEvent(event)
        if self.count():
            return
        painter = QtGui.QPainter(self.viewport())
        try:
            painter.setPen(QtGui.QColor("#6E7480"))
            font = painter.font()
            font.setPixelSize(14)
            painter.setFont(font)
            painter.drawText(self.viewport().rect().adjusted(24, -12, -24, -12),
                             combine(_ALIGN_CENTER, _ALIGN_VCENTER),
                             self.empty_text)
        finally:
            painter.end()

    # ---------------------------------------------------------- 多选开关
    def _set_multi(self, on):
        """按住 Shift = 多选（可以框选）；不按 = 单选（拖出去用，别冒框）。"""
        on = bool(on)
        if self._multi_on == on:
            return
        self._multi_on = on
        try:
            self.setSelectionMode(_SELECT_EXTENDED if on else _SELECT_SINGLE)
        except Exception:                                     # noqa: BLE001
            pass
        # 选择矩形（橡皮筋）只在多选时可见
        try:
            if hasattr(self, "setSelectionRectVisible"):
                self.setSelectionRectVisible(on)
        except Exception:                                     # noqa: BLE001
            pass

    @classmethod
    def _modifiers_held(cls, event=None, mask=0):
        mask = mask or int(_SHIFT)
        try:
            if event is not None:
                if int(event.modifiers()) & mask:
                    return True
        except Exception:                                     # noqa: BLE001
            pass
        try:
            app = QtWidgets.QApplication.instance()
            if app is not None:
                if int(app.keyboardModifiers()) & mask:
                    return True
        except Exception:                                     # noqa: BLE001
            pass
        return False

    @classmethod
    def _shift_held(cls, event=None):
        """Shift 按住吗？（有没有框选意图就靠它）"""
        return cls._modifiers_held(event, int(_SHIFT))

    @classmethod
    def _multi_held(cls, event=None):
        """Shift 或 Ctrl 按住吗？（按下时决定允许多选用）"""
        return cls._modifiers_held(event, int(_SHIFT) | int(_CONTROL))

    def keyPressEvent(self, event):                           # noqa: N802
        try:
            if int(event.key()) == int(_KEY_SHIFT):
                self._set_multi(True)
        except Exception:                                     # noqa: BLE001
            pass
        super(PresetView, self).keyPressEvent(event)

    def keyReleaseEvent(self, event):                         # noqa: N802
        try:
            if int(event.key()) == int(_KEY_SHIFT):
                self._set_multi(False)
        except Exception:                                     # noqa: BLE001
            pass
        super(PresetView, self).keyReleaseEvent(event)

    # ---------------------------------------------------------- 拖出去
    def mousePressEvent(self, event):                         # noqa: N802
        if event.button() == _LEFT_BUTTON:
            # 按下这一刻就决定：Shift / Ctrl 按住 → 多选；否则单选
            self._set_multi(self._multi_held(event))
            self._press_pos = event_pos(event)
            item = self.itemAt(event_pos(event))
            data = item.data(_ROLE_DATA) if item else None
            self._press_id = (data or {}).get("id", "") if isinstance(data, dict) else ""
        super(PresetView, self).mousePressEvent(event)

    def mouseMoveEvent(self, event):                          # noqa: N802
        holding = False
        try:
            holding = bool(int(event.buttons()) & int(_LEFT_BUTTON))
        except Exception:                                     # noqa: BLE001
            holding = False
        # ⚠️ 按住左键拖动又没按 Shift 时，**不要**交给父类：
        # QListView 会画橡皮筋框选（用户不想要这个框）。
        # 没按按键的纯 hover 移动必须照常交给父类，否则 itemEntered
        # 不发，卡片上的 GIF 就不动了。
        if holding and not self._shift_held(event):
            if self._press_pos is None or not self._press_id:
                return
            delta = event_pos(event) - self._press_pos
            if delta.manhattanLength() < 10:
                return
            pid = self._press_id
            self._press_id = ""
            self._press_pos = None
            self.dragOut.emit(pid)
            return
        # Shift 拖动 = 框选，交给父类处理；这时候不发起"拖出去"
        if holding and self._press_id:
            self._press_id = ""
            self._press_pos = None
        super(PresetView, self).mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):                       # noqa: N802
        self._press_id = ""
        self._press_pos = None
        if self._drag_done:
            # 拖出去过：这次松手是拖拽的收尾，别触发 clicked / activated，
            # 不然会变成"松手就双击放了" —— 放到哪儿由 controller 决定
            self._drag_done = False
            return
        super(PresetView, self).mouseReleaseEvent(event)

    def _on_menu(self, pos):
        item = self.itemAt(pos)
        data = item.data(_ROLE_DATA) if item else None
        pid = (data or {}).get("id", "") if isinstance(data, dict) else ""
        self.contextMenu.emit(pid, self.viewport().mapToGlobal(pos))


# ================================================================ 拖拽残影
class InlineRename(QtWidgets.QLineEdit):
    """分类树里就地改名的小输入框（双击文件夹时贴在那一行上）。

    为什么不用 `QTreeWidget.editItem()`：树上的文字是「名字 (数量)」，
    editItem 会把 `(数量)` 一起塞进输入框，用户得自己删；而且按 Esc 取消
    时树上会留下没有计数的脏文字。自己摆一个 QLineEdit 最省心 —— 回车提交、
    Esc / 点到别处取消，全程不碰树的模型，树由 controller 重建时统一刷新。
    """

    committed = Signal(str)
    cancelled = Signal()

    def __init__(self, parent=None):
        super(InlineRename, self).__init__(parent)
        self.setFrame(False)
        self._done = False
        # 就地改名也是要打中文的（Houdini 默认把输入法关着）
        install_ime_guard(self)

    def keyPressEvent(self, event):                           # noqa: N802
        key = event.key()
        if key in (int(enum_of(Qt, "Key_Return")),
                   int(enum_of(Qt, "Key_Enter"))):
            self._finish(True)
            return
        if key == int(enum_of(Qt, "Key_Escape")):
            self._finish(False)
            return
        super(InlineRename, self).keyPressEvent(event)

    def focusOutEvent(self, event):                           # noqa: N802
        super(InlineRename, self).focusOutEvent(event)
        self._finish(False)

    def cancel(self):
        """外部要求收摊（比如树要重建了）。"""
        self._finish(False)

    def _finish(self, commit):
        if self._done:
            return
        self._done = True
        text = self.text().strip()
        self.hide()
        if commit and text:
            self.committed.emit(text)
        else:
            self.cancelled.emit()
        self.deleteLater()


class DragGhost(QtWidgets.QFrame):
    """把预设拖到网络编辑器时，跟着鼠标走的那个小卡片。

    纯装饰：不吃鼠标（WA_TransparentForMouseEvents + Tool 窗口），
    真正的"放到哪儿"由 controller 在松手时问 hou.ui.paneTabUnderCursor()。
    """

    def __init__(self, parent=None):
        super(DragGhost, self).__init__(parent)
        flags = (enum_of(Qt, "Tool")
                 | enum_of(Qt, "FramelessWindowHint")
                 | enum_of(Qt, "WindowStaysOnTopHint")
                 | enum_of(Qt, "WindowTransparentForInput"))
        self.setWindowFlags(flags)
        self.setAttribute(enum_of(Qt, "WA_TransparentForMouseEvents"), True)
        self.setAttribute(enum_of(Qt, "WA_ShowWithoutActivating"), True)
        self.setObjectName("DragGhost")
        self.setStyleSheet(
            "QFrame#DragGhost{background:rgba(24,28,32,225);"
            "border:1px solid #4FA37A;border-radius:6px;}")

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)
        self.image = QtWidgets.QLabel("")
        self.image.setFixedSize(180, 112)
        self.image.setScaledContents(True)
        self.image.setAlignment(_ALIGN_CENTER)
        layout.addWidget(self.image)
        self.caption = QtWidgets.QLabel("")
        self.caption.setAlignment(_ALIGN_CENTER)
        self.caption.setStyleSheet("color:#DCE8E0;")
        layout.addWidget(self.caption)
        self.hint = QtWidgets.QLabel("")
        self.hint.setAlignment(_ALIGN_CENTER)
        self.hint.setWordWrap(True)
        self.hint.setFixedWidth(184)
        layout.addWidget(self.hint)
        self.setFixedWidth(196)
        self.set_hint("")

    def set_content(self, pixmap, text=""):
        if pixmap is not None and not pixmap.isNull():
            self.image.setPixmap(pixmap)
        else:
            self.image.setText("（无预览）")
        self.caption.setText(str(text or ""))
        self.adjustSize()

    def set_hint(self, text, ok=False):
        """落点提示：能放是绿的写网络路径，不能放是灰的写"松开取消"。"""
        color = "#7FD6A6" if ok else "#8A919C"
        self.hint.setStyleSheet("color:%s;font-size:11px;" % color)
        self.hint.setText(str(text or ""))
        try:
            self.adjustSize()
        except Exception:                                 # noqa: BLE001
            pass

    def follow(self, pos, offset=18):
        try:
            self.move(pos.x() + offset, pos.y() + offset)
        except Exception:                                     # noqa: BLE001
            pass


# ================================================================ 拖拽提示层
class DropOverlay(QtWidgets.QWidget):
    """拖拽悬停时盖在整个窗口上的提示层。

    用户要求"拖到界面哪里都算"，所以不再有底部横幅：拖进来时整窗压一层
    半透明遮罩 + 虚框 + 中间一句话，松手就弹创建框。
    它设了 WA_TransparentForMouseEvents，不吃鼠标也不吃拖拽事件。
    """

    def __init__(self, parent=None, text="松开鼠标，保存为预设"):
        super(DropOverlay, self).__init__(parent)
        self._text = text
        self._sub = "接着会弹出一个框，填名字 / 简介 / 放到哪个分类"
        self.setAttribute(enum_of(Qt, "WA_TransparentForMouseEvents"), True)
        self.setAttribute(enum_of(Qt, "WA_NoSystemBackground"), True)
        self.setFocusPolicy(enum_of(Qt, "NoFocus"))
        self.hide()

    def set_text(self, text, sub=""):
        """换提示语（拖进来的是文件而不是节点时用得上）。"""
        self._text = str(text or "")
        if sub:
            self._sub = str(sub)
        self.update()

    def set_hot(self, hot):
        hot = bool(hot)
        if hot:
            self.show()
            self.raise_()
            self.update()
        else:
            self.hide()

    def is_hot(self):
        return self.isVisible()

    def paintEvent(self, _event):                             # noqa: N802
        painter = QtGui.QPainter(self)
        try:
            painter.fillRect(self.rect(), QtGui.QColor(12, 16, 20, 150))
            pen = QtGui.QPen(QtGui.QColor("#4FA37A"))
            pen.setWidth(3)
            pen.setStyle(enum_of(Qt, "DashLine"))
            painter.setPen(pen)
            painter.drawRect(self.rect().adjusted(5, 5, -6, -6))

            big = painter.font()
            big.setPixelSize(22)
            big.setBold(True)
            small = painter.font()
            small.setPixelSize(13)
            small.setBold(False)

            gap = 14
            h1 = QtGui.QFontMetrics(big).height()
            h2 = QtGui.QFontMetrics(small).height()
            top = max(0, int((self.rect().height() - h1 - gap - h2) / 2))

            painter.setFont(big)
            painter.setPen(QtGui.QColor(240, 246, 240))
            painter.drawText(QtCore.QRect(0, top, self.width(), h1),
                             _ALIGN_CENTER, self._text)

            painter.setFont(small)
            painter.setPen(QtGui.QColor(218, 230, 222))
            painter.drawText(QtCore.QRect(0, top + h1 + gap, self.width(), h2),
                             _ALIGN_CENTER, self._sub)
        finally:
            painter.end()


# ================================================================ 标签
class TagBar(QtWidgets.QWidget):
    """一排标签 chips，末尾跟着一个输入框可以随时加。"""

    tagsChanged = Signal(list)                                # noqa: N815

    def __init__(self, parent=None):
        super(TagBar, self).__init__(parent)
        self._tags = []
        self._layout = QtWidgets.QHBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(4)

        self.edit = QtWidgets.QLineEdit()
        self.edit.setPlaceholderText("＋标签")
        self.edit.setFixedWidth(72)
        self.edit.returnPressed.connect(self._add_from_edit)
        self._layout.addWidget(self.edit)
        self._layout.addStretch(1)
        install_ime_guard(self.edit)          # 标签也要能打中文

    def tags(self):
        return list(self._tags)

    def set_tags(self, tags):
        self._tags = [str(t) for t in (tags or []) if str(t).strip()]
        self._rebuild()

    def _rebuild(self):
        """整排重建：chips → 输入框 → 弹簧。edit 只摘出来不删。"""
        while self._layout.count():
            item = self._layout.takeAt(0)
            widget = item.widget()
            if widget is None or widget is self.edit:
                continue
            widget.setParent(None)
            widget.deleteLater()
        for tag in self._tags:
            chip = QtWidgets.QToolButton()
            chip.setText("%s  ✕" % tag)
            chip.setToolTip("点一下删掉「%s」" % tag)
            try:                                      # 别让布局把 chip 压成一个字
                metrics = chip.fontMetrics()
                chip.setMinimumWidth(metrics.boundingRect(chip.text()).width() + 18)
            except Exception:                         # noqa: BLE001
                pass
            chip.clicked.connect(lambda _c=False, t=tag: self._remove(t))
            self._layout.addWidget(chip)
        self._layout.addWidget(self.edit)
        self._layout.addStretch(1)

    def _add_from_edit(self):
        text = self.edit.text().strip()
        if not text or text in self._tags:
            self.edit.clear()
            return
        self._tags.append(text)
        self.edit.clear()
        self._rebuild()
        self.tagsChanged.emit(self.tags())

    def _remove(self, tag):
        if tag in self._tags:
            self._tags.remove(tag)
            self._rebuild()
            self.tagsChanged.emit(self.tags())


# ================================================================ 预览标签
class PreviewLabel(QtWidgets.QLabel):
    """右侧大预览：静图直接显示，GIF 用 QMovie 循环播。"""

    def __init__(self, parent=None):
        super(PreviewLabel, self).__init__(parent)
        self.setAlignment(_ALIGN_CENTER)
        self.setMinimumHeight(150)
        self._movie = None
        self._path = ""
        self._resizing = False
        self._last_size = (0, 0)

    def set_preview(self, path, width=0, height=0):
        """width/height 传 0 就用控件当前大小（避免图片撑出边界压到下面的控件）。"""
        self._stop()
        self._path = path or ""
        self.setText("")
        if not width:
            width = max(120, self.width() - 4)
        if not height:
            height = max(90, self.height() - 4)
        self._last_size = (int(width), int(height))
        if not path or not os.path.isfile(path):
            self.setText("（还没有预览图）")
            return
        if os.path.splitext(str(path).lower())[1] in _GIF_EXTS:
            movie = QtGui.QMovie(path)
            if movie.isValid():
                movie.setScaledSize(QtCore.QSize(int(width), int(height)))
                self._movie = movie
                self.setMovie(movie)
                movie.start()
                return
        pm = QtGui.QPixmap(path)
        if pm.isNull():
            self.setText("（图读不出来）")
            return
        self.setPixmap(pm.scaled(int(width), int(height),
                                 enum_of(Qt, "KeepAspectRatio"),
                                 enum_of(Qt, "SmoothTransformation")))

    def _stop(self):
        movie = self._movie
        if movie is not None:
            movie.stop()
            movie.deleteLater()
        self._movie = None
        self.setMovie(None)

    def clear_preview(self):
        self._stop()
        self._path = ""
        self.setText("（还没有预览图）")

    def resizeEvent(self, event):                             # noqa: N802
        super(PreviewLabel, self).resizeEvent(event)
        # 按新尺寸重画（否则图片会撑出边界压到下面的控件）。
        # 必须防重入：setPixmap 可能又触发一次 layout → resize。
        if self._resizing or not self._path:
            return
        if not os.path.isfile(self._path):
            return
        size = (self.width() - 4, self.height() - 4)
        if size == self._last_size or size[0] <= 0 or size[1] <= 0:
            return
        self._resizing = True
        try:
            self.set_preview(self._path)
        finally:
            self._resizing = False


__all__ = ["PreviewStore", "PresetDelegate", "PresetView", "DragGhost",
           "DropOverlay", "TagBar", "PreviewLabel", "InlineRename",
           "placeholder_color", "combine", "icons"]
