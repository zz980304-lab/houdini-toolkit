# -*- coding: utf-8 -*-
"""单行改名框：预设改名 / 文件夹改名兜底都用它。

为什么单独一个文件：
  * 创建框（create_dialog）太重（预览图、标签、层级…），改名只要一个输入框。
  * 树上改文件夹走的是**就地输入框**（widgets.InlineRename），
    只有在树里找不到那一行时才退到这里，别把两个混在一起。

⚠️ 输入法：Houdini 会把 `WA_InputMethodEnabled` 关掉，窗口和输入框都要
   补这个属性，而且得用定时器复查（跟 create_dialog 同一套）。
"""

from .ime import enable_ime, ime_widgets, install_ime_guard
from .qt import QtCore, QtWidgets, Qt, enum_of

__all__ = ["NameDialog"]


class NameDialog(QtWidgets.QDialog):
    """问一个新名字。返回 True 表示确定，`value()` 拿结果。"""

    def __init__(self, parent=None, title="重命名", label="名字",
                 value="", hint="", select=True):
        super(NameDialog, self).__init__(parent)
        self.setWindowTitle(str(title or "重命名"))
        self.setModal(True)
        self._value = str(value or "")

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(8)

        if hint:
            hint_label = QtWidgets.QLabel(str(hint))
            hint_label.setWordWrap(True)
            try:
                hint_label.setStyleSheet("color:#8A949F;")
            except Exception:                             # noqa: BLE001
                pass
            layout.addWidget(hint_label)

        row = QtWidgets.QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(QtWidgets.QLabel(str(label or "名字")))
        self.edit = QtWidgets.QLineEdit()
        self.edit.setText(self._value)
        self.edit.setMinimumWidth(260)
        self.edit.setToolTip("回车确定，Esc 取消")
        self.edit.returnPressed.connect(self._accept)
        row.addWidget(self.edit, 1)
        layout.addLayout(row)

        buttons = QtWidgets.QDialogButtonBox()
        ok_button = buttons.addButton(
            "确定", enum_of(QtWidgets.QDialogButtonBox, "AcceptRole"))
        cancel_button = buttons.addButton(
            "取消", enum_of(QtWidgets.QDialogButtonBox, "RejectRole"))
        for name in ("accepted", "rejected"):
            signal = getattr(buttons, name, None)
            if signal is not None:
                try:
                    signal.connect(self.accept if name == "accepted"
                                   else self.reject)
                except Exception:                         # noqa: BLE001
                    pass
        layout.addWidget(buttons)
        self._ok_button = ok_button
        self._cancel_button = cancel_button
        self._select = bool(select)
        self.edit.textChanged.connect(self._sync_ok)

        # 输入法：不装这个在 Houdini 里打不了中文（原理见 ime.py）
        install_ime_guard(self)

    # ---------------------------------------------------------------- 取值
    def value(self):
        return str(self.edit.text() or "").strip()

    def _accept(self):
        if self.value():
            self.accept()

    def _sync_ok(self, _text):
        try:
            self._ok_button.setEnabled(bool(self.value()))
        except Exception:                                 # noqa: BLE001
            pass

    def exec_dialog(self):
        """Qt5 是 exec_()，Qt6 是 exec()。"""
        for name in ("exec_", "exec"):
            method = getattr(self, name, None)
            if method is None:
                continue
            try:
                return bool(method())
            except TypeError:
                continue
        return False

    @staticmethod
    def ask(parent=None, title="重命名", label="名字", value="", hint=""):
        """一步到位：弹出 → 返回新名字（取消了返回 None）。"""
        dialog = NameDialog(parent, title=title, label=label,
                            value=value, hint=hint)
        if not dialog.exec_dialog():
            return None
        text = dialog.value()
        return text or None

    # ============================================================ 输入法
    def _ime_targets(self):
        return ime_widgets(self)

    def _enable_ime(self):
        enable_ime(ime_widgets(self))

    def showEvent(self, event):                           # noqa: N802
        try:
            super(NameDialog, self).showEvent(event)
        except Exception:                                 # noqa: BLE001
            pass
        self._enable_ime()
        self.edit.setFocus()
        if self._select:
            self.edit.selectAll()

    def _on_ime_tick(self):
        guard = getattr(self, "_ime_guard_obj", None)
        if guard is not None:
            guard.tick()
