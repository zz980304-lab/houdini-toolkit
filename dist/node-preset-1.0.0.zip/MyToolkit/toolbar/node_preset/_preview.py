# -*- coding: utf-8 -*-
"""开发用：把界面离线渲染成 PNG 自检（不进分发包，也不 import hou）。

用法（Git Bash，用 hython 跑，它自带 Qt 且 DLL 路径已配好）：
    cd /tmp && env -u HOME "E:/Houdini20.5.401/bin/hython.exe" \
        "N:/Houdini_path/toolbar/node_preset/_preview.py" <输出.png> [grid|list|create]

为什么要 WA_DontShowOnScreen 而不是 QT_QPA_PLATFORM=offscreen：
    Windows 的 offscreen 插件没有字体库，界面上所有文字会渲染成空白，
    截图只有一堆空控件。用原生平台 + 这个属性：窗口不真的弹出来，字体正常。
"""

import os
import sys
import tempfile

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from node_preset.qt import QtCore, QtGui, QtWidgets, enum_of   # noqa: E402
from node_preset.ui import NodePresetWindow                    # noqa: E402

FAKE_DIR = os.path.join(tempfile.gettempdir(), "np_preview_fake")


def _make_thumb(path, color, title, sub):
    """造一张假缩略图（渐变 + 文字），供界面自检用。"""
    image = QtGui.QImage(300, 200, QtGui.QImage.Format_RGB32)
    base = QtGui.QColor(color)
    painter = QtGui.QPainter(image)
    try:
        grad = QtGui.QLinearGradient(0, 0, 300, 200)
        grad.setColorAt(0.0, base.lighter(130))
        grad.setColorAt(1.0, base.darker(160))
        painter.fillRect(image.rect(), grad)
        painter.setPen(QtGui.QColor(255, 255, 255, 210))
        font = QtGui.QFont()
        font.setPixelSize(28)
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(image.rect().adjusted(14, 10, -14, -30),
                         enum_of(QtCore.Qt, "AlignLeft"), title)
        font.setPixelSize(15)
        font.setBold(False)
        painter.setFont(font)
        painter.setPen(QtGui.QColor(255, 255, 255, 165))
        painter.drawText(image.rect().adjusted(14, 0, -14, -14),
                         enum_of(QtCore.Qt, "AlignBottom"), sub)
    finally:
        painter.end()
    image.save(path, "PNG")


def _version():
    """版本号只认包里的 __version__，别在这儿写死（写死就会跟发布对不上）。"""
    try:
        from node_preset import __version__
        return __version__
    except Exception:                                     # noqa: BLE001
        return "?"


def fake_library():
    """造一批假数据：假缩略图 + 假预设 + 假文件夹。"""
    if not os.path.isdir(FAKE_DIR):
        os.makedirs(FAKE_DIR)

    thumbs = [
        ("破碎预处理", "voronoi + 分组", "#7A4A3E"),
        ("路径生长", "curve → popnet", "#3E5A7A"),
        ("粒子拖尾", "trail + 属性衰减", "#4A6B3E"),
        ("VDB 平滑", "vdb smooth sdf", "#3E6B63"),
        ("材质球快速搭建", "principled + 贴图", "#7A6B3E"),
        ("RBD 解算标准配置", "bullet + 约束", "#6B3E5A"),
        ("输出 EXR 序列", "arnold rop", "#4E4E58"),
        ("TOP 缓存批处理", "wedge + filecache", "#5A4A7A"),
        ("镜头抖动曲线", "chop noise", "#3E6B6B"),
        ("LOP 灯光预设", "usd luz", "#4A5A7A"),
        ("USD 分层导出", "usd rop", "#5A5A6B"),
        ("碎块二次细分", "iterative fracture", "#7A5A3E"),
    ]
    paths = []
    for index, (title, sub, color) in enumerate(thumbs):
        name = "thumb_%02d.gif" % index if index % 4 == 0 else "thumb_%02d.png" % index
        path = os.path.join(FAKE_DIR, name)
        if not os.path.isfile(path):
            _make_thumb(path, color, title, sub)
        paths.append(path)

    def preset(pid, name, desc, context, tags, types, folder="",
               fav=False, used=0, preview=None, py_abbr="", py_full=""):
        return {
            "id": pid, "name": name, "desc": desc, "tags": list(tags),
            "context": context, "node_types": list(types),
            "node_count": len(types), "folder_id": folder,
            "favorite": fav, "use_count": used, "preview": preview,
            "source_path": "/obj/geo1/%s" % pid,
            "created": "2026-10-1%d 10:00" % (pid.count("0") % 9 + 1),
            "modified": "2026-10-1%d 18:%02d" % ((len(name) % 9) + 1, len(name) * 3 % 60),
            "py_abbr": py_abbr, "py_full": py_full,
        }

    presets = [
        preset("p_01", "破碎预处理 — voronoi + 分组",
               "给输入几何做 voronoi 破碎，按 @name 分好组，接 RBD 之前用。\n"
               "注意：要先保证输入是封闭的实体，不然二级碎会出问题。",
               "Sop", ["破碎", "RBD"], ["voronoifracture", "assemble", "groupcreate"],
               folder="f_break", fav=True, used=12, preview=paths[0],
               py_abbr="psycl", py_full="posuichuli"),
        preset("p_02", "碎块二次细分",
               "对已经破好的块再切一刀，只切体积大于阈值的。",
               "Sop", ["破碎"], ["voronoifracture", "blast", "measure"],
               folder="f_break", preview=paths[11],
               py_abbr="skecxfq", py_full="suikuaiercixifen"),
        preset("p_03", "路径生长",
               "沿着曲线撒点 + popnet 生长，最后 polywire 成管。",
               "Sop", ["生长", "常用"], ["resample", "popnet", "polywire"],
               folder="f_grow", fav=True, used=27, preview=paths[1],
               py_abbr="ljsz", py_full="lujingshengzhang"),
        preset("p_04", "粒子拖尾",
               "trail 取速度做拖尾，用 age 衰减宽度。",
               "Sop", ["粒子"], ["popnet", "trail", "attribwrangle"],
               folder="f_grow", used=5, preview=paths[2],
               py_abbr="lzty", py_full="lizituowei"),
        preset("p_05", "VDB 平滑",
               "体素转 VDB → smooth sdf → 转回多边形，做融合感。",
               "Sop", ["VDB", "常用"], ["vdbfrompolygons", "vdbsmoothsdf", "convertvdb"],
               folder="f_common", fav=True, used=31, preview=paths[3],
               py_abbr="vdbph", py_full="vdbpinghua"),
        preset("p_06", "材质球快速搭建",
               "principled shader + 三张贴图连好，改颜色就能用。",
               "Vop", ["材质"], ["principledshader", "texture", "collect"],
               used=9, preview=paths[4],
               py_abbr="czqksd", py_full="caizhiqiukuaidasu"),
        preset("p_07", "RBD 解算标准配置",
               "bullet solve + 硬约束 + 地面，参数是我常用的那套。",
               "Dop", ["RBD", "解算"], ["rbdpackedobject", "bulletsolver", "gravity"],
               folder="f_sim", fav=True, used=18, preview=paths[5],
               py_abbr="rbdjs", py_full="rbdjiesuan"),
        preset("p_08", "输出 EXR 序列",
               "arnold rop，带 cryptomatte 和 AOV，路径走 $HIP/render。",
               "Driver", ["输出", "渲染"], ["arnold"],
               folder="f_out", used=7, preview=paths[6],
               py_abbr="scexr", py_full="shuchuexr"),
        preset("p_09", "TOP 缓存批处理",
               "wedge 多版本 → filecache → 汇总，农场提交用。",
               "Top", ["PDG", "缓存"], ["wedge", "filecache", "ropgeometry"],
               used=4, preview=paths[7],
               py_abbr="top", py_full="top"),
        preset("p_10", "镜头抖动曲线",
               "chop 里用 noise 做手持感，接到相机的 t/r。",
               "Chop", ["镜头"], ["noise", "export"],
               used=2, preview=paths[8],
               py_abbr="jtdd", py_full="jingtoudoudong"),
        preset("p_11", "LOP 灯光预设",
               "三点光 + dome light 的 HDRI，直接引用就有。",
               "Lop", ["灯光", "USD"], ["light", "domelight"],
               used=6, preview=paths[9],
               py_abbr="lopdg", py_full="lopdengguang"),
        preset("p_12", "USD 分层导出",
               "按 layer 分层写 usd，方便在别处再合成。",
               "Lop", ["USD", "输出"], ["usd_rop", "layerbreak"],
               used=3, preview=paths[10],
               py_abbr="usdfc", py_full="usdfenceng"),
        preset("p_13", "常用属性清理",
               "删掉一堆没用的属性，出缓存前跑一遍。",
               "Sop", ["常用", "清理"], ["attribdelete", "attribpromote"],
               folder="f_common", used=14, preview=None,
               py_abbr="cysxql", py_full="changyongshuxingqingli"),
    ]

    folders = [
        {"id": "f_break", "name": "破碎", "context": "Sop", "parent": "",
         "color": "#E0574A", "shape": "flask", "order": 0},
        {"id": "f_grow", "name": "生长", "context": "Sop", "parent": "",
         "color": "#4C9A5A", "shape": "flame", "order": 1},
        {"id": "f_common", "name": "常用", "context": "Sop", "parent": "",
         "color": "#F2C94C", "shape": "star", "order": 2},
        {"id": "f_sim", "name": "解算", "context": "Dop", "parent": "",
         "color": "#9B6BD6", "shape": "bolt", "order": 0},
        {"id": "f_out", "name": "输出", "context": "Driver", "parent": "",
         "color": "#8A8F98", "shape": "tag", "order": 0},
    ]
    return presets, folders


def main(argv):
    out = argv[1] if len(argv) > 1 else os.path.join(_HERE, "preview.png")
    mode = argv[2] if len(argv) > 2 else "grid"

    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(argv[:1])

    presets, folders = fake_library()

    if mode == "empty":
        win = NodePresetWindow()
        win.setWindowTitle("节点预设库（空库）")
        win.set_catalog([])
        win.set_presets([])
        win.set_version("v%s" % _version())
        win.setAttribute(enum_of(QtCore.Qt, "WA_DontShowOnScreen"), True)
        win.resize(1080, 700)
        win.show()
        app.processEvents()
        pixmap = win.grab()
        ok = pixmap.save(out, "PNG")
        print("saved=%s ok=%s size=%dx%d" % (out, ok, pixmap.width(), pixmap.height()))
        return 0 if ok else 1

    if mode == "create":
        return preview_create(out, presets, folders)

    win = NodePresetWindow()
    win.setWindowTitle("节点预设库（界面自检 · 假数据）")
    win.set_catalog(folders)
    win.set_presets(presets)
    win.set_version("v%s · 已是最新" % _version())
    win.set_status("界面自检：下面是假数据（只看布局，不碰真库）")
    win.view.set_grid(mode != "list")
    win.setAttribute(enum_of(QtCore.Qt, "WA_DontShowOnScreen"), True)
    win.resize(1080, 700)
    win.show()
    app.processEvents()

    if win.view.count():
        win.view.setCurrentRow(0)

    if mode == "drop":
        win._set_drop_hot(True)
        app.processEvents()

    app.processEvents()
    pixmap = win.grab()
    ok = pixmap.save(out, "PNG")
    print("saved=%s ok=%s size=%dx%d fake_dir=%s"
          % (out, ok, pixmap.width(), pixmap.height(), FAKE_DIR))
    return 0 if ok else 1


def preview_create(out, presets, folders):
    """单独把创建框渲染出来看看。"""
    from node_preset.create_dialog import CreatePresetDialog
    sample = presets[0]
    dialog = CreatePresetDialog(None, folders=folders, context=sample["context"],
                                folder_id=sample.get("folder_id") or "",
                                hint="刚拖进来的 3 个节点会被存进这个预设")
    dialog.set_values(sample)
    dialog.setAttribute(enum_of(QtCore.Qt, "WA_DontShowOnScreen"), True)
    dialog.show()
    QtWidgets.QApplication.instance().processEvents()
    pixmap = dialog.grab()
    ok = pixmap.save(out, "PNG")
    print("saved=%s ok=%s size=%dx%d"
          % (out, ok, pixmap.width(), pixmap.height()))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
