# -*- coding: utf-8 -*-
"""自动更新：从 Git（Cloudflare Pages / GitHub Pages）拉新版本代码 + 云端预设包。

代码更新：**只更新代码，绝不碰你的 library/**（预设数据）。
预设更新（preset-pack 模块）：把云端预设包**合并**进 library ——
云端同名预设覆盖本机版本，本机自存的预设一个不删，也不删任何
library 里已有的其它文件。

流程
    1. 拉 manifest.json（CF Pages 优先，失败退 GitHub Pages）
    2. 代码：找 modules[id=node-preset]，和 <库>/.update/installed.json 里的版本比
       预设：找 modules[id=preset-pack]，版本先看 .update/installed.json，
       没有再看 bootstrap 安装器写的 MyToolkit/installed.json（两边都认，
       免得从「安装/更新工具集」装过之后这里又下一遍同版）
    3. 有新版本 → 下载 parts → 逐个校验 sha256
    4. 代码：把当前工具目录备份到 <库>/_backup/tool_<时间戳>/
       预设：把 catalog.json 备份到 <库>/_backup/presets_<时间戳>/
    5. 解压覆盖（zip 里的路径形如 MyToolkit/toolbar/node_preset/…：
       代码只认 toolbar/node_preset/ 的条目（library/ 子目录除外），
       预设只认 toolbar/node_preset/library/ 的条目）
    6. 写 installed.json；提示重开窗口（reload_package 能热重载，不保证干净）

⚠️ Cloudflare 对 Python-urllib 的 UA 直接返 403，所以必须自己带 User-Agent。
⚠️ 本机装得是不是最新，靠 installed.json 而不是代码里写版本号 ——
   写死在代码里会跟着代码一起被覆盖，永远等于最新，比不出来。
"""

import hashlib
import json
import os
import shutil
import time
import urllib.error
import urllib.request
import zipfile

from . import paths
from .qt import QtCore, QtWidgets, Qt, enum_of, exec_box

MODULE_ID = "node-preset"
PRESET_MODULE_ID = "preset-pack"
USER_AGENT = "node-preset-updater/1.0 (+houdini)"
MANIFEST_URLS = [
    "https://houdini-toolkit.pages.dev/manifest.json",
    "https://zz980304-lab.github.io/houdini-toolkit/manifest.json",
]
MARKER = "toolbar/node_preset"
PRESET_MARKER = MARKER + "/library"
TOOLKIT_ROOT = "MyToolkit"

_OK = enum_of(QtWidgets.QMessageBox, "Ok")
_WARNING = enum_of(QtWidgets.QMessageBox, "Warning")
_INFORMATION = enum_of(QtWidgets.QMessageBox, "Information")


# ------------------------------------------------------------------ 网络
def _request(url, timeout=10):
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    return urllib.request.urlopen(request, timeout=timeout)


def _fetch_json(url, timeout=10):
    with _request(url, timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_manifest():
    """返回 (manifest, base_url, 错误)。base_url 用来拼 parts 的相对路径。"""
    errors = []
    for url in MANIFEST_URLS:
        base = url.rsplit("/", 1)[0] + "/"
        try:
            data = _fetch_json(url, timeout=8)
            if isinstance(data, dict) and data.get("modules"):
                return data, base, ""
            errors.append("%s：内容不像 manifest" % url)
        except Exception as exc:                          # noqa: BLE001
            errors.append("%s：%r" % (url, exc))
    return None, "", "；".join(errors)


# ------------------------------------------------------------------ 版本
def _version_tuple(text):
    parts = []
    for chunk in str(text or "0").split("."):
        digits = "".join(ch for ch in chunk if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def installed_info():
    path = paths.installed_path()
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except Exception:                                     # noqa: BLE001
        pass
    return {}


def preset_installed_version():
    """预设包的本机有效版本（.update 记录与 bootstrap 记录取新）。"""
    return installed_version(PRESET_MODULE_ID)


def installed_version(module_id=MODULE_ID):
    """本机该模块的有效版本。

    两个更新器各记各的（本文件记 .update/installed.json，
    bootstrap 安装器记 MyToolkit/installed.json），只看自己的就会打架：
    用「安装/更新工具集」更新过之后，这里又提示一遍同样的更新。
    磁盘上代码到底是什么版本，取两边记录里更新的那个。
    """
    rec = installed_info().get(module_id) or {}
    mine = str(rec.get("version") or "")
    boot = _bootstrap_installed_version(module_id)
    if boot and (not mine or _version_tuple(boot) > _version_tuple(mine)):
        return boot
    return mine


def save_installed(version, extra=None, module_id=MODULE_ID):
    info = installed_info()
    record = {"version": str(version),
              "installed": time.strftime("%Y-%m-%d %H:%M:%S")}
    record.update(extra or {})
    info[module_id] = record
    path = paths.installed_path()
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(info, handle, ensure_ascii=False, indent=2)
    return record


def module_info(manifest, module_id=MODULE_ID):
    for module in (manifest or {}).get("modules") or []:
        if module.get("id") == module_id:
            return module
    return None


def _bootstrap_installed_version(module_id):
    """读 bootstrap 安装器记在 MyToolkit/installed.json 里的模块版本。

    「安装/更新工具集」装的模块记在那边，本更新器的 installed.json
    里没有记录 —— 不认它的话，第一次点「检查更新」会把刚装过的
    同一个包再下一遍（两个更新器互相打架的根源之一）。
    """
    try:
        toolkit_root = os.path.dirname(os.path.dirname(paths.tool_dir()))
        path = os.path.join(toolkit_root, "installed.json")
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return str((data.get("modules") or {}).get(module_id) or "")
    except Exception:                                     # noqa: BLE001
        return ""


def _sync_bootstrap_record(module_id, version):
    """把自己刚更新完的版本回写进 bootstrap 安装器的记录。

    不回写的话：这里更新完，用户再点「安装/更新工具集」，
    它一看自己记录还是旧的，又把同一个更新下一遍 ——
    「每次点更新都提示要更新」就是这么来的。
    文件不存在（N 盘源码机、未装 MyToolkit）就不动，避免乱建文件。
    """
    try:
        toolkit_root = os.path.dirname(os.path.dirname(paths.tool_dir()))
        path = os.path.join(toolkit_root, "installed.json")
        if not os.path.isfile(path):
            return False
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return False
        modules = data.get("modules") or {}
        if _version_tuple(version) <= _version_tuple(str(modules.get(module_id) or "")):
            return False
        modules[module_id] = str(version)
        data["modules"] = modules
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=4)
        return True
    except Exception:                                     # noqa: BLE001
        return False


# ------------------------------------------------------------------ 下载
def _download(url, dst_path, timeout=60):
    with _request(url, timeout) as response, open(dst_path, "wb") as handle:
        shutil.copyfileobj(response, handle)
    return dst_path


def _sha256(path, bufsize=1 << 20):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(bufsize)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


# ------------------------------------------------------------------ 备份 / 解压
def _backup_tool_dir(keep=5):
    """把工具目录备份一份（跳过 library / _cache / __pycache__）。

    keep=N 只保留最近 N 份 tool_ 备份，更老的清掉 ——
    以前没有上限，每次更新都往 _backup 里堆一份，慢慢把网络盘吃满。
    """
    from .paths import tool_dir
    source = tool_dir()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = os.path.join(paths.backup_dir(), "tool_%s" % stamp)
    skip = {"library", "_cache", "_backup", ".update", "__pycache__", ".git"}
    try:
        if not os.path.isdir(paths.backup_dir()):
            os.makedirs(paths.backup_dir())
        if os.path.isdir(target):
            shutil.rmtree(target, ignore_errors=True)
        # dirs_exist_ok 是 3.8+ 才有的；先清空再用老写法，兼顾 3.7
        shutil.copytree(source, target,
                        ignore=shutil.ignore_patterns(*skip))
    except Exception:                                     # noqa: BLE001
        return ""
    _prune_backups(keep)
    return target


def _prune_backups(keep=5, prefix="tool_"):
    """只留最近 keep 份 <prefix>* 备份，其余删掉。失败静默（备份清理不该挡更新）。"""
    try:
        bdir = paths.backup_dir()
        names = [n for n in os.listdir(bdir) if n.startswith(prefix)]
        items = sorted((os.path.join(bdir, n) for n in names),
                       key=os.path.getmtime, reverse=True)
        for old in items[max(0, int(keep)):]:
            shutil.rmtree(old, ignore_errors=True)
    except Exception:                                     # noqa: BLE001
        pass


def _backup_catalog(keep=5):
    """预设更新前备份 catalog.json（合并式更新里唯一会被整体覆盖的文件）。"""
    src = paths.catalog_path()
    if not os.path.isfile(src):
        return ""
    try:
        target = os.path.join(paths.backup_dir(),
                              "presets_%s" % time.strftime("%Y%m%d-%H%M%S"))
        if not os.path.isdir(target):
            os.makedirs(target)
        shutil.copy2(src, os.path.join(target, "catalog.json"))
        _prune_backups(keep, "presets_")
        return target
    except Exception:                                     # noqa: BLE001
        return ""


def _extract_into(part_paths, target_root, marker, forbid_marker=None):
    """把 zip 里 <marker>/ 下的条目解压覆盖到 target_root，其余跳过。

    forbid_marker：再往前挡一道 —— 匹配它前缀的条目也跳过
    （代码解压用挡 library/，library 只能由 _extract_preset_parts 动）。
    防 zip slip（.. / 绝对路径一律跳过），跳过 __pycache__ / .pyc。
    返回 (写入文件数, 跳过条目数, 错误)。
    """
    written = 0
    skipped = 0
    try:
        for part in part_paths:
            with zipfile.ZipFile(part, "r") as archive:
                for name in archive.namelist():
                    if name.endswith("/"):
                        continue
                    normalized = name.replace("\\", "/")
                    if "__pycache__" in normalized or normalized.endswith(".pyc"):
                        skipped += 1
                        continue
                    index = normalized.find(marker + "/")
                    if index < 0:
                        skipped += 1
                        continue
                    relative = normalized[index + len(marker) + 1:]
                    if not relative:
                        skipped += 1
                        continue
                    if forbid_marker and (normalized.find(forbid_marker + "/") >= 0):
                        skipped += 1
                        continue
                    # 防 zip slip：条目里带 .. 或绝对路径的一律跳过
                    chunks = [c for c in relative.split("/") if c]
                    if not chunks or any(c == ".." for c in chunks):
                        skipped += 1
                        continue
                    dst = os.path.join(target_root, *chunks)
                    if not os.path.abspath(dst).startswith(
                            os.path.abspath(target_root)):
                        skipped += 1
                        continue
                    parent = os.path.dirname(dst)
                    if parent and not os.path.isdir(parent):
                        os.makedirs(parent)
                    with archive.open(name, "r") as src, open(dst, "wb") as out:
                        shutil.copyfileobj(src, out)
                    written += 1
    except Exception as exc:                              # noqa: BLE001
        return written, skipped, "%r" % exc
    return written, skipped, ""


def _extract_parts(part_paths, replace=False):
    """解压并覆盖到工具目录，只处理 toolbar/node_preset/ 下的条目。

    library/ 子路径一律挡住（打包时已排除，这里是第二道防线）——
    library 只能由 _extract_preset_parts 动。
    """
    from .paths import tool_dir
    written, skipped, error = _extract_into(part_paths, tool_dir(), MARKER,
                                            forbid_marker=PRESET_MARKER)
    _ = replace
    return written, skipped, error


def _extract_preset_parts(part_paths):
    """把预设包解压**合并**进 library。

    只认 toolbar/node_preset/library/ 下的条目；同路径覆盖、
    新路径新建、本机独有文件一律不动。
    """
    written, skipped, error = _extract_into(part_paths, paths.library_dir(),
                                            PRESET_MARKER)
    return written, skipped, error


# ------------------------------------------------------------------ 入口
def _download_parts(win, base, module, controller=None):
    """下载并校验一个模块的全部 parts。成功返回本地路径列表；
    失败弹窗并返回 None。"""
    parts = module.get("parts") or []
    cache = os.path.join(paths.update_dir(), "download")
    if not os.path.isdir(cache):
        os.makedirs(cache)
    downloaded = []
    try:
        for index, part in enumerate(parts):
            url = part.get("url") or ""
            if not url.startswith("http"):
                url = base + url
            dst = os.path.join(cache, os.path.basename(url) or ("part%d.zip" % index))
            if controller is not None and hasattr(controller, "message"):
                controller.message("下载中 %d/%d：%s"
                                   % (index + 1, len(parts), os.path.basename(dst)))
            QtWidgets.QApplication.processEvents()
            _download(url, dst)
            expect = str(part.get("sha256") or "")
            if expect and _sha256(dst) != expect:
                raise RuntimeError("sha256 不符：%s" % os.path.basename(dst))
            downloaded.append(dst)
    except Exception as exc:                              # noqa: BLE001
        _box(win, "下载失败", "%r" % exc, _WARNING)
        return None
    return downloaded


def _update_code(controller, win, manifest, base, quiet):
    """node-preset 代码更新。返回 "updated" / "current" / "missing"。"""
    module = module_info(manifest, MODULE_ID)
    if module is None:
        return "missing"
    local_version = installed_version()
    remote_version = str(module.get("version") or "")
    if local_version and _version_tuple(remote_version) <= _version_tuple(local_version):
        return "current"

    parts = module.get("parts") or []
    total = sum(int(p.get("size") or 0) for p in parts)
    if not _confirm(win, "发现新版本 v%s" % remote_version,
                    "本机：%s\n线上：%s\n\n共 %d 个文件，%.1f MB。\n"
                    "只更新代码，预设库（library/）一个字节都不动。\n现在更新？"
                    % (local_version or "（没记录）", remote_version,
                       len(parts), total / 1048576.0)):
        return "current"

    downloaded = _download_parts(win, base, module, controller)
    if downloaded is None:
        return "current"

    backup = _backup_tool_dir()
    written, skipped, error = _extract_parts(downloaded)
    if error:
        _box(win, "解压失败",
             "%s\n\n备份在：%s\n可以用它手动还原。" % (error, backup or "（没备份成功）"),
             _WARNING)
        return "current"

    save_installed(remote_version, {"parts": len(downloaded),
                                    "backup": backup or "",
                                    "skipped": skipped})
    # 回写 bootstrap 记录，免得「安装/更新工具集」又把同一次更新下一遍
    _sync_bootstrap_record(MODULE_ID, remote_version)
    if hasattr(controller, "message"):
        controller.message("已更新到 v%s（写入 %d 个文件）" % (remote_version, written))

    reloaded = False
    try:
        from . import reload_package
        reload_package()
        reloaded = True
    except Exception:                                     # noqa: BLE001
        reloaded = False
    _box(win, "更新完成",
         "已更新到 v%s，写入 %d 个文件。\n备份：%s\n\n%s"
         % (remote_version, written, backup or "（无）",
            "已尝试热重载，重新点一次工具架按钮即可。"
            if reloaded else "关掉窗口再点工具架按钮生效。"),
         _INFORMATION)
    return "updated"


def _update_presets(win, manifest, base, quiet):
    """云端预设包（preset-pack）合并更新。返回 "updated" / "current" / "missing"。

    合并语义：云端同名预设覆盖本机版本，本机自存的预设一律不动。
    """
    module = module_info(manifest, PRESET_MODULE_ID)
    if module is None:
        return "missing"
    remote_version = str(module.get("version") or "")
    if not remote_version:
        return "missing"
    local_version = preset_installed_version()
    if local_version and _version_tuple(remote_version) <= _version_tuple(local_version):
        return "current"

    parts = module.get("parts") or []
    total = sum(int(p.get("size") or 0) for p in parts)
    if not _confirm(win, "云端预设包 v%s" % remote_version,
                    "本机：%s\n云端：%s\n\n共 %d 个文件，%.1f MB。\n\n"
                    "合并进你的预设库：\n"
                    "· 云端预设覆盖本机同名预设\n"
                    "· 本机自存的预设不会被删除\n"
                    "· catalog.json（文件夹分组）以云端为准，已备份\n\n"
                    "现在下载？"
                    % (local_version or "（没装过）", remote_version,
                       len(parts), total / 1048576.0)):
        return "current"

    downloaded = _download_parts(win, base, module)
    if downloaded is None:
        return "current"

    catalog_backup = _backup_catalog()
    written, skipped, error = _extract_preset_parts(downloaded)
    if error:
        _box(win, "解压失败", "%s\n\ncatalog 备份在：%s" % (error, catalog_backup or "（无）"),
             _WARNING)
        return "current"

    save_installed(remote_version, {"parts": len(downloaded),
                                    "skipped": skipped},
                   PRESET_MODULE_ID)
    # 回写 bootstrap 记录（同上，防两个更新器打架）
    _sync_bootstrap_record(PRESET_MODULE_ID, remote_version)
    if not quiet:
        _box(win, "预设已同步",
             "云端预设包 v%s 已合并进预设库（写入 %d 个文件）。\n\n"
             "重开预设库窗口即可看到。" % (remote_version, written),
             _INFORMATION)
    return "updated"


def check_from_ui(controller, quiet=False):
    """设置 ▸「检查更新」：先查代码，再查云端预设包。

    返回 True = 本次发生过更新（代码或预设任一）。
    """
    win = getattr(controller, "win", None)
    manifest, base, error = fetch_manifest()
    if manifest is None:
        if not quiet:
            _box(win, "检查更新失败", "拉不到版本清单：\n%s\n\n"
                       "（本机直连 GitHub 常常不通，挂上代理再试）" % error,
                 _WARNING)
        return False

    code_state = _update_code(controller, win, manifest, base, quiet)
    preset_state = _update_presets(win, manifest, base, quiet)

    # 两边都没动作 → 统一汇报"已是最新"，别让用户点完按钮没任何反馈
    if not quiet and code_state != "updated" and preset_state != "updated":
        from . import __version__ as code_version
        code_local = installed_version()
        code_remote = str((module_info(manifest, MODULE_ID) or {}).get("version")
                          or "?")
        lines = ["代码：本机 v%s / 线上 v%s" % (code_local or "（没记录）", code_remote)]
        preset_mod = module_info(manifest, PRESET_MODULE_ID)
        if preset_mod is None:
            lines.append("预设包：线上还没发布过")
        else:
            lines.append("预设包：本机 v%s / 线上 v%s"
                         % (preset_installed_version() or "（没装过）",
                            preset_mod.get("version")))
        _box(win, "检查更新",
             "已经是最新：\n" + "\n".join(lines) + "\n\n"
             "（界面标题上的 v%s 是代码内部版本号，跟发布版号是两套，"
             "更新与否只看这里的发布版号。）" % code_version,
             _INFORMATION)
    return code_state == "updated" or preset_state == "updated"


def _box(parent, title, text, icon):
    box = QtWidgets.QMessageBox(parent)
    box.setWindowTitle(title)
    box.setIcon(icon)
    box.setText(text)
    box.setStandardButtons(_OK)
    return exec_box(box)


def _confirm(parent, title, text):
    box = QtWidgets.QMessageBox(parent)
    box.setWindowTitle(title)
    box.setIcon(_INFORMATION)
    box.setText(text)
    box.setStandardButtons(enum_of(QtWidgets.QMessageBox, "Yes")
                           | enum_of(QtWidgets.QMessageBox, "No"))
    return exec_box(box) == enum_of(QtWidgets.QMessageBox, "Yes")


__all__ = ["check_from_ui", "fetch_manifest", "installed_version",
           "save_installed", "preset_installed_version",
           "MODULE_ID", "PRESET_MODULE_ID", "MANIFEST_URLS"]
