# -*- coding: utf-8 -*-
"""工程保存工具（把当前 Houdini 工程和它引用的素材一起打包带走）。

位置：<任意 HOUDINI_PATH 目录>/toolbar/hip_packer/hip_packer/
    自包含，整个拷到别的机器 / 别的盘都能用，内部不写任何绝对路径，
    靠 HOUDINI_PATH 相对定位（详见同目录 README.txt）。

在 Houdini 里用：
    from hip_packer import show
    show()

当 Houdini Python Panel 用：
    from hip_packer import HipPackerWindow
    def onCreateInterface():
        return HipPackerWindow()          # 要接功能就再 attach(win)

模块分工（各管一摊，互不塞）
    classify.py   分类 + 序列识别（纯逻辑，不依赖 Qt / hou）
    scan.py       扫描工程里的文件引用（只读，需要 hou）
    plan.py       算包内结构、处理重名（纯计算）
    transfer.py   复制 / 压缩 / 删目录（纯 IO）
    rewrite.py    改写包内工程副本的路径（跑在 hython 子进程里）
    manifest.py   生成 manifest.json / README.txt
    qt.py         Qt 绑定兼容层（PySide2 / PySide6）
    ui.py         界面（不 import hou）
    controller.py 把上面这些接到界面上

引用改写这条链（scan -> plan -> rewrite -> 复查）的约定见 rewrite.py 开头，
改动前先看一眼，别把「文件搬了、引用没跟上」的坑再踩回来。
"""

from .qt import BINDING as QT_BINDING          # noqa: F401
from .ui import HipPackerWindow                # noqa: F401

__version__ = "0.8.0"
__all__ = ["show", "HipPackerWindow", "HipPackerController", "QT_BINDING",
           "__version__"]

#: 已经打开过的窗口，避免被 Python 垃圾回收掉
_WINDOWS = []
_CONTROLLERS = []


def HipPackerController(win):                  # noqa: N802  （懒加载别名）
    from .controller import HipPackerController as _Cls
    return _Cls(win)


def reload_modules(close_windows=True):
    """把 hip_packer 及它的子模块从 `sys.modules` 里踢掉。

    Houdini 的 Python 会话是常驻的，**改了磁盘上的代码它不会自己重新读** ——
    点工具架按钮时 `from hip_packer import show` 拿到的还是内存里那份旧的，
    于是「明明改好了，点了却没反应」。这个函数就是解药：下次 import 会重新
    编译磁盘上的最新版本。

    close_windows=True 会先把已经开着的窗口关掉（它们属于旧代码的类，留着会打架）。
    返回 True / False（模块压根没导入过时返回 False）。
    """
    import sys

    keys = [k for k in sys.modules
            if k == "hip_packer" or k.startswith("hip_packer.")]
    if close_windows:
        try:
            close_all()
        except Exception:                                  # noqa: BLE001
            pass
    for key in keys:
        sys.modules.pop(key, None)
    return bool(keys)


def show(parent=None, with_logic=True):
    """以独立窗口打开界面；已经开着就把它提到前面来。

    with_logic=True（默认）会把功能接上：点按钮真的会扫描 / 打包。
    """
    from .qt import QtCore, enum_of

    for win in list(_WINDOWS):
        try:
            if win.isVisible():
                win.raise_()
                win.activateWindow()
                return win
        except RuntimeError:                  # 窗口已经被 C++ 侧销毁
            _WINDOWS.remove(win)

    if parent is None:
        try:
            import hou
            parent = hou.qt.mainWindow()      # 跟着 Houdini 主窗口，避免出现在任务栏
        except Exception:                     # noqa: BLE001
            parent = None

    win = HipPackerWindow(parent)
    if with_logic:
        try:
            _CONTROLLERS.append(HipPackerController(win))
        except Exception as exc:              # noqa: BLE001
            win.set_status("功能层没接上：%s" % exc)
    win.setWindowFlags(enum_of(QtCore.Qt, "Window"))
    win.show()
    win.raise_()
    win.activateWindow()
    try:
        win._enable_ime()          # show + 激活之后 Houdini 会把输入法开关关掉
    except Exception:                                  # noqa: BLE001
        pass
    _WINDOWS.append(win)
    return win


def close_all():
    """关掉本工具开过的所有窗口（调试用）。"""
    for win in list(_WINDOWS):
        try:
            win.close()
        except Exception:                     # noqa: BLE001
            pass
    _WINDOWS[:] = []
    _CONTROLLERS[:] = []
