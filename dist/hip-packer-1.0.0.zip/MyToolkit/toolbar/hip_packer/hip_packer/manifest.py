# -*- coding: utf-8 -*-
"""出包说明：manifest.json（机器读）+ README.txt（人读）。

manifest 是「原路径 -> 包内路径 -> 引用它的节点」这张表的落盘版本，
以后要回溯「包里这个文件原来在哪、谁在用」，查它就行。
"""

import json
import os
import time

from . import classify


def _human(num):
    size = float(num or 0)
    if size <= 0:
        return "0 B"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024.0 or unit == "TB":
            return "%.1f %s" % (size, unit) if unit != "B" else "%d B" % size
        size /= 1024.0


def build_manifest(plan, hip_info=None, options=None, extra=None):
    """把打包结果拼成一个 dict（不写盘，方便测试）。"""
    options = options or {}
    by_group = {}
    for task in plan.tasks:
        by_group.setdefault(task["group"] or "其它", []).append(task)

    files = []
    for task in plan.tasks:
        files.append({
            "source": task["src"],
            "in_pack": os.path.relpath(task["dst"], plan.pack_dir).replace("\\", "/"),
            "size": task["size"],
            "type": task["group"],
            "ext": task["ext"],
            "missing": task["missing"],
            "referenced_by": list(task["refs"]),
        })

    manifest = {
        "tool": "工程保存工具 (hip_packer)",
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "source_hip": plan.hip_src,
        "pack_dir": plan.pack_dir,
        "hip_in_pack": (os.path.basename(plan.hip_dst) if plan.hip_dst else ""),
        "paths_rewritten": bool(options.get("rewrite_paths")),
        "layout_policy": options.get("layout_policy", 0),
        "assets_root": options.get("assets_root") or "",   # 空 = 素材和工程同层
        "otls": {
            "dir": classify.OTL_DIRNAME,
            "files": sum(1 for t in plan.tasks if t.get("in_otls")),
            "auto_load_script": bool(options.get("otl_loader")),
        },
        "totals": {
            "files": len(plan.tasks),
            "bytes": plan.total_bytes,
            "human": _human(plan.total_bytes),
            "missing": sum(1 for t in plan.tasks if t["missing"]),
            "renamed": len(plan.conflicts),
        },
        "by_type": {g: len(v) for g, v in sorted(by_group.items())},
        "renamed": [{"source": s, "in_pack": os.path.relpath(d, plan.pack_dir)
                     .replace("\\", "/")} for s, d in plan.conflicts],
        "files": files,
    }
    if hip_info:
        manifest["hip_info"] = {
            "path": hip_info.get("path", ""),
            "size": hip_info.get("size", 0),
            "mtime": hip_info.get("mtime", ""),
            "houdini": hip_info.get("version", ""),
        }
    if extra:
        manifest.update(extra)
    return manifest


def write_manifest(plan, path, hip_info=None, options=None, extra=None):
    data = build_manifest(plan, hip_info, options, extra)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)
    return path


def write_readme(plan, path, hip_info=None, options=None):
    """包里给人看的一页说明：这个包里有什么、怎么打开。"""
    options = options or {}
    lines = []
    lines.append("工程保存工具 · 打包说明")
    lines.append("=" * 46)
    lines.append("打包时间：%s" % time.strftime("%Y-%m-%d %H:%M:%S"))
    if plan.hip_src:
        lines.append("原工程：%s" % plan.hip_src.replace("\\", "/"))
    if hip_info and hip_info.get("version"):
        lines.append("Houdini：%s" % hip_info["version"])
    lines.append("")

    hip_name = os.path.basename(plan.hip_dst) if plan.hip_dst else ""
    if hip_name:
        lines.append("怎么打开")
        lines.append("-" * 46)
        lines.append("  用 Houdini 打开包里的 %s" % hip_name)
        if options.get("rewrite_paths"):
            lines.append("  里面的素材路径已经改成相对 $HIP 的写法，")
            lines.append("  整个文件夹搬到别的机器 / 别的盘也能直接开。")
        else:
            lines.append("  注意：素材路径没有改写，机器目录不一致时可能要重新指一下。")
        lines.append("")

    lines.append("目录结构")
    lines.append("-" * 46)
    if hip_name:
        lines.append("  %-22s 工程文件" % hip_name)
    if plan.otl_count:
        lines.append("  %-22s 用到的 HDA / OTL" % (classify.OTL_DIRNAME + "/"))
    assets_root = (options.get("assets_root") or "").strip()
    if assets_root:
        lines.append("  %-22s 引用的素材（按类型分好）" % (assets_root + "/"))
    else:
        lines.append("  %-22s 引用的素材（和工程文件同层）" % "geo/、cache/…")
    if plan.otl_count or options.get("layout_policy", 0) == 0:
        lines.append("       %s素材按类型分的子目录："
                     % (("%s/ 里" % assets_root) if assets_root else ""))
        lines.append("         image/  贴图、图片序列      cache/  几何缓存、abc / usd / vdb")
        lines.append("         mov/    视频                audio/  音频")
        lines.append("         misc/   其它                （工程内的素材保留原来的目录结构）")
    lines.append("  manifest.json        完整依赖清单（原路径 / 包内路径 / 引用节点）")
    lines.append("  README.txt           本文件")
    lines.append("")

    if plan.otl_count:
        lines.append("HDA / OTL 怎么加载")
        lines.append("-" * 46)
        lines.append("  它们都在包里的 %s/ 目录下（工程根目录下）。" % classify.OTL_DIRNAME)
        lines.append("  Houdini 默认就会扫 $HIP/otls，正常打开工程就会自动加载。")
        if options.get("otl_loader"):
            lines.append("  另外工程里已经写入了一段「打开时自动执行」的 python，")
            lines.append("  会把 otls/ 下的文件全都装一遍，作为保险（万一对方机器")
            lines.append("  自定义过 HOUDINI_OTLSCAN_PATH，默认扫描路径可能已经失效）。")
        lines.append("")

    by_group = {}
    for task in plan.tasks:
        by_group.setdefault(task["group"] or "其它", []).append(task)
    lines.append("包里有什么")
    lines.append("-" * 46)
    for group in sorted(by_group, key=lambda g: -len(by_group[g])):
        items = by_group[group]
        size = sum(t["size"] for t in items)
        miss = sum(1 for t in items if t["missing"])
        tail = "，缺失 %d" % miss if miss else ""
        lines.append("  %-12s %4d 个   %10s%s" % (group, len(items), _human(size), tail))
    lines.append("  %-12s %4d 个   %10s" % (
        "合计", len(plan.tasks), _human(plan.total_bytes)))
    lines.append("")

    if plan.conflicts:
        lines.append("改过名的文件（包里重名，加了后缀）")
        lines.append("-" * 46)
        for src, dst in plan.conflicts[:40]:
            lines.append("  %s" % os.path.relpath(dst, plan.pack_dir).replace("\\", "/"))
            lines.append("      <- %s" % src)
        if len(plan.conflicts) > 40:
            lines.append("  … 还有 %d 个，见 manifest.json" % (len(plan.conflicts) - 40))
        lines.append("")

    missing = [t for t in plan.tasks if t["missing"]]
    if missing:
        lines.append("⚠ 这些文件没找到，没被打进包里")
        lines.append("-" * 46)
        for task in missing[:40]:
            lines.append("  %s" % task["src"])
            if task["refs"]:
                lines.append("      引用位置：%s" % ", ".join(task["refs"][:3]))
        if len(missing) > 40:
            lines.append("  … 还有 %d 个，见 manifest.json" % (len(missing) - 40))
        lines.append("")

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


__all__ = ["build_manifest", "write_manifest", "write_readme"]
