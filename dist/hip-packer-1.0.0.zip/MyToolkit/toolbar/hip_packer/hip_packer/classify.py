# -*- coding: utf-8 -*-
"""素材分类 + 文件序列识别（纯逻辑，不依赖 Qt，也不依赖 hou）。

分成两层用：
  1. 界面层：扫描结果丢进来，自动按「大类 → 扩展名」两级列到界面上；
     没见过的扩展名一律进「未识别格式」，照样列出来让你自己决定带不带，
     所以插件自定义的输出格式不会漏。
  2. 功能层：打包时用它判断一个路径属于哪一类、是不是序列。

序列这块主要是为了解决重名：
    /obj/geo1/filecache1  ->  .../filecache1/cache.bgeo.sc
    /obj/geo2/filecache2  ->  .../filecache2/cache.bgeo.sc
  文件名一模一样，父目录不同，内容也不同。所以清单里必须带父目录，
  并且同名文件要能被明显看出来（界面层负责标色，这里只负责算出来）。
"""

import os
import re

# ---------------------------------------------------------------- 大类
GEO = "几何缓存"
TEX = "贴图与材质"
HDA = "自定义 HDA"
REF = "参考与其它"
RENDER = "渲染输出"
UNKNOWN = "未识别格式"

#: 界面上大类的排列顺序
GROUP_ORDER = [GEO, TEX, HDA, REF, RENDER, UNKNOWN]

#: 大类 -> 已知扩展名（小写，带点；双后缀单独写）
EXT_GROUPS = {
    GEO: [
        ".bgeo.sc", ".bgeo", ".geo", ".abc", ".vdb",
        ".usd", ".usda", ".usdc", ".usdz", ".ply", ".sim", ".pc2",
    ],
    TEX: [
        ".exr", ".hdr", ".png", ".jpg", ".jpeg", ".tif", ".tiff",
        ".rat", ".tx", ".tga", ".bmp", ".dds", ".psd", ".webp",
    ],
    HDA: [".hda", ".hdalc", ".otl", ".otllc", ".hdanc", ".otlnc"],
    REF: [
        ".fbx", ".obj", ".pc", ".pts", ".pdb",
        ".wav", ".aif", ".aiff", ".mp3", ".wav32",
        ".ass", ".rs", ".vrscene", ".json", ".xml", ".csv", ".txt",
    ],
    RENDER: [".mov", ".mp4", ".avi", ".mxf", ".m4v", ".webm"],
}

#: 这些扩展名如果是「序列」，就当成渲染输出，而不是贴图
_IMAGE_EXTS = (".exr", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".tga", ".bmp", ".dpx")

# ---------------------------------------------------------------- 包内子目录
#: 工程外的素材复制进包里时，按类型分放到这些子目录下（用户 2026-10-15 定的规则）。
#: 工程内的素材不走这套 —— 它们在工程里本来就有目录结构，照搬即可。
SUBDIR_IMAGE = "image"        # 贴图 / 图片序列
SUBDIR_CACHE = "cache"        # 几何缓存、参考几何（abc / usd / vdb / bgeo / fbx / obj…）
SUBDIR_MOV = "mov"            # 视频
SUBDIR_AUDIO = "audio"        # 音频
SUBDIR_MISC = "misc"          # 认不出来的、文档类
#: HDA / OTL 单独放**工程根**下的这个目录（Houdini 默认会扫 $HIP/otls）
OTL_DIRNAME = "otls"

#: 先按扩展名精确归类（比大类更细：大类「参考与其它」里既有 abc 也有 wav）
_SUBDIR_BY_EXT = {}


def _map_subdir(subdir, exts):
    for _e in exts:
        _SUBDIR_BY_EXT[_e] = subdir


_map_subdir(SUBDIR_IMAGE, [
    ".exr", ".hdr", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".rat", ".tx",
    ".tga", ".bmp", ".dds", ".psd", ".webp", ".dpx",
])
_map_subdir(SUBDIR_CACHE, [
    ".bgeo.sc", ".bgeo.gz", ".bgeo.lzma", ".bgeo", ".geo", ".geo.sc",
    ".abc", ".vdb", ".usd", ".usda", ".usdc", ".usdz",
    ".ply", ".sim", ".simcache", ".pc2", ".pc", ".pts", ".pdb",
    ".fbx", ".obj",
])
_map_subdir(SUBDIR_MOV, [
    ".mov", ".mp4", ".avi", ".mxf", ".m4v", ".webm", ".mkv", ".r3d",
])
_map_subdir(SUBDIR_AUDIO, [
    ".wav", ".wav32", ".aif", ".aiff", ".mp3", ".flac", ".ogg", ".aac",
])
_map_subdir(SUBDIR_MISC, [
    ".json", ".xml", ".csv", ".txt", ".ass", ".rs", ".vrscene",
])

#: 扩展名没登记时的兜底（按大类）
_SUBDIR_BY_GROUP = {
    GEO: SUBDIR_CACHE,
    TEX: SUBDIR_IMAGE,
    HDA: OTL_DIRNAME,
    REF: SUBDIR_CACHE,
    RENDER: SUBDIR_MOV,
    UNKNOWN: SUBDIR_MISC,
}

#: 认作序列编号的写法：cache.1001.exr / cache_0001.exr / cache-12.exr
#: sep 单独记下来，拼回来的名字才不会丢掉那个点（cache.$F4.bgeo.sc）
_NUM_RE = re.compile(
    r"^(?P<base>.*?)(?P<sep>[._-]?)(?P<num>\d{2,6})(?P<ext>(?:\.[A-Za-z0-9]+)+)$")
#: Houdini 的帧变量：$F / $F4 / $F4d，以及 DOP 模拟帧 $SF（小数，如 13.0）
_F_RE = re.compile(r"\$(?:SF|F\d*[a-z]?)")

_EXT_LOOKUP = {}
for _g, _exts in EXT_GROUPS.items():
    for _e in _exts:
        _EXT_LOOKUP[_e] = _g

_DOUBLE_EXTS = (".bgeo.sc", ".bgeo.gz", ".bgeo.lzma", ".pdb.gz", ".geo.sc")


def norm_ext(path):
    """/a/b/x.BGEO.SC -> '.bgeo.sc'；/a/b/c.png -> '.png'。"""
    name = os.path.basename(str(path or "")).lower()
    for d in _DOUBLE_EXTS:
        if name.endswith(d):
            return d
    return os.path.splitext(name)[1]


def seq_pattern(path):
    """(目录, 去掉帧号的骨架) —— 只有带数字编号的文件才有，别的返回 None。

    骨架里保留原来的分隔符，例如 'cache.1001.bgeo.sc' -> ('…', 'cache.' + '$F' + '.bgeo.sc')。
    `$F` / `$F4` / `$SF`（DOP 模拟帧）都算帧变量，统一写成 `$F`。
    """
    path = str(path or "")
    d, name = os.path.split(path)
    if _F_RE.search(name):
        return d, _F_RE.sub("$F", name)
    m = _NUM_RE.match(name)
    if m:
        return d, m.group("base") + m.group("sep") + "$F" + m.group("ext")
    return None


def is_sequence(path):
    """单个路径看着像序列吗（带 $F，或者结尾有数字编号）。

    ⚠ 光看名字会把 hero_rig_v06.abc、barrel_01.fbx 这种版本号误判成序列，
    所以清单里要用 detect_sequences() 按「同目录下成组」来判定。
    """
    name = os.path.basename(str(path or ""))
    if _F_RE.search(name):
        return True
    return bool(_NUM_RE.match(name))


def detect_sequences(paths):
    """给定一批路径，返回 {path: True} —— 只有**同目录下成组**的编号才算序列。

    这条规则是为了避开版本号：一个 hero_rig_v06.abc 是模型，
    而 .../filecache1/cache.1001.bgeo.sc ~ 1240 是序列。
    """
    groups = {}
    for path in paths:
        pat = seq_pattern(path)
        if pat:
            groups.setdefault(pat, []).append(path)

    result = {}
    for path in paths:
        if _F_RE.search(os.path.basename(str(path or ""))):
            result[path] = True
    for key, members in groups.items():
        if len(members) >= 2:                 # 同目录里连号 >= 2 个才当序列
            for path in members:
                result[path] = True
    return result


def frame_number(path):
    """取出帧号；不是数字序列或没帧号就返回 None。

    ⚠ `_NUM_RE` 要求编号 **至少 2 位**（免得把 cache1.bgeo 这种当序列），
    所以 `Cache_poly_Fast1.1.bgeo.sc`（单位数帧）在这里是取不到的。
    已经确知是序列的文件请用 `frame_number_in_pattern()`。
    """
    name = os.path.basename(str(path or ""))
    m = _NUM_RE.match(name)
    return int(m.group("num")) if m else None


def frame_number_in_pattern(skeleton, path):
    """按序列骨架取帧号 —— 骨架就是参数里那段带 `$F` 的写法。

    classify.frame_number_in_pattern("cache.$F4.bgeo.sc", ".../cache.1001.bgeo.sc") -> 1001

    为什么不用 frame_number()：文件名里的编号可能只有 1 位（1~9 帧），
    也可能文件名本身以数字结尾（Cache_poly_Fast1.10），靠猜会猜错。
    骨架是用户在参数里亲口写的，按它切最可靠。
    """
    skeleton = os.path.basename(str(skeleton or ""))
    if not skeleton or not _F_RE.search(skeleton):
        return None
    parts = _F_RE.split(skeleton)
    rx = re.compile(r"^" + r"([0-9]+(?:\.[0-9]+)?)".join(
        re.escape(p) for p in parts) + r"$")
    m = rx.match(os.path.basename(str(path or "")))
    if not m:
        return None
    try:
        return int(float(m.group(1)))
    except (TypeError, ValueError):
        return None


def seq_key(path):
    """序列的唯一 key：同一段序列的所有帧算出来是一样的。

    用来把 240 个帧合并成清单里的一行。
    """
    pat = seq_pattern(path)
    return (pat[0] + "|" + pat[1]) if pat else str(path or "")


def seq_label(path):
    """序列在界面上显示的名字：cache.$F.bgeo.sc / cache_$F.exr。"""
    pat = seq_pattern(path)
    if pat:
        return pat[1]
    return os.path.basename(str(path or ""))


def classify(path, forced_sequence=None):
    """返回 (大类, 扩展名)。

    forced_sequence: 扫描层已经知道它是序列时传 True，省得再猜。
    """
    ext = norm_ext(path)
    seq = is_sequence(path) if forced_sequence is None else forced_sequence
    # 图片序列一律当渲染输出，不然一个 240 帧的 exr 会被当贴图
    if seq and ext in _IMAGE_EXTS:
        return RENDER, ext
    return _EXT_LOOKUP.get(ext, UNKNOWN), ext


def group_of(path, forced_sequence=None):
    return classify(path, forced_sequence)[0]


def describe_ext(ext):
    """.bgeo.sc -> 'bgeo.sc'，给界面当小标题用。"""
    return (ext or "").lstrip(".") or "无扩展名"


def shorten(text, max_len=52):
    """长路径从**头部**截断，尾巴（更关键的部分）保留。"""
    text = str(text or "")
    if len(text) <= max_len:
        return text
    return "…" + text[-(max_len - 1):]


def parent_dir(path):
    """取父目录；空则返回 ''。"""
    return os.path.dirname(str(path or ""))


def is_otl(path):
    """是不是 HDA / OTL 文件（这些要单独放工程根下的 otls/，不走 assets）。"""
    return norm_ext(path) in EXT_GROUPS[HDA]


def pack_subdir(path, group=None, ext=None):
    """工程外的素材该放进哪个子目录（image / cache / mov / audio / misc）。

    工程外的素材没有「原来的目录结构」可言，一律按类型归类，
    免得包里冒出 D:\\cache\\… 这种又深又没用的路径。

    HDA / OTL 不走这里 —— 它们会放到工程根下的 otls/（见 OTL_DIRNAME）。
    """
    ext = ext or norm_ext(path)
    if ext in _SUBDIR_BY_EXT:
        return _SUBDIR_BY_EXT[ext]
    if group is None:
        group = classify(path)[0]
    return _SUBDIR_BY_GROUP.get(group, SUBDIR_MISC)


__all__ = [
    "GEO", "TEX", "HDA", "REF", "RENDER", "UNKNOWN",
    "GROUP_ORDER", "EXT_GROUPS",
    "SUBDIR_IMAGE", "SUBDIR_CACHE", "SUBDIR_MOV", "SUBDIR_AUDIO", "SUBDIR_MISC",
    "OTL_DIRNAME",
    "norm_ext", "is_sequence", "detect_sequences", "seq_pattern", "frame_number",
    "seq_key", "seq_label",
    "classify", "group_of", "describe_ext", "shorten", "parent_dir",
    "is_otl", "pack_subdir",
]
