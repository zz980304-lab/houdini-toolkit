# -*- coding: utf-8 -*-
"""双击清单里的素材 -> 跳到引用它的那个节点（Houdini 侧，界面不认识 hou）。

这里只管「怎么把某个节点摆到用户眼前」：

    1. 找一个网络编辑器面板（优先已经在看这个节点所在层级的那个）；
    2. cd 到节点所在的层级；
    3. 选中它，并把视图**居中**到它身上（不缩放，免得跳过去找不到北）；
    4. 顺便闪一条提示，让用户知道跳成功了。

返回 dict 而不抛异常，界面层照着 `message` 直接显示就行。

    navigate.describe("/obj/geo1/file1")   -> 节点信息（给多选弹窗列名字用）
    navigate.jump_to_node("/obj/geo1/file1") -> {"ok": True, "message": "..."}
"""

try:                                        # 正常当包用
    from . import classify
except (ImportError, ValueError):           # 被 hython 当脚本直接跑时没有包上下文
    import importlib.util
    import os as _os

    _spec = importlib.util.spec_from_file_location(
        "hip_packer_classify",
        _os.path.join(_os.path.dirname(_os.path.abspath(__file__)),
                      "classify.py"))
    classify = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(classify)


#: 居中时视图的宽高范围（网络单位）。太大显得糊，太小看不清周围连线。
_MIN_VIEW = 220.0
_MAX_VIEW = 4000.0


# ---------------------------------------------------------------- 面板查找
def network_editors():
    """当前桌面里所有网络编辑器面板。"""
    try:
        import hou
        tabs = hou.ui.curDesktop().paneTabs()
    except Exception:                                      # noqa: BLE001
        return []
    out = []
    for tab in tabs or []:
        try:
            if tab.type() == hou.paneTabType.NetworkEditor:
                out.append(tab)
        except Exception:                                  # noqa: BLE001
            continue
    return out


def _pick_editor(node):
    """挑一个面板：优先正在看这个节点所在层级的那个，没有就用第一个。"""
    parent = node.parent()
    want = parent.path() if parent is not None else ""
    fallback = None
    for editor in network_editors():
        if fallback is None:
            fallback = editor
        try:
            pwd = editor.pwd()
        except Exception:                                  # noqa: BLE001
            continue
        if want and pwd is not None and pwd.path() == want:
            return editor
    return fallback


def ensure_editor():
    """一个网络编辑器都没有时，浮一个出来（不然没地方跳）。"""
    editors = network_editors()
    if editors:
        return editors[0]
    try:
        import hou
        return hou.ui.curDesktop().createFloatingPaneTab(
            hou.paneTabType.NetworkEditor)
    except Exception:                                      # noqa: BLE001
        return None


# ---------------------------------------------------------------- 节点信息
def describe(node_path):
    """给多选弹窗用的一行信息；节点不在了也返回 exists=False，别崩。"""
    info = {"path": node_path or "", "exists": False, "type": "",
            "category": "", "parent": "", "locked": False}
    try:
        import hou
        node = hou.node(node_path)
    except Exception:                                      # noqa: BLE001
        return info
    if node is None:
        return info

    info["exists"] = True
    try:
        info["type"] = node.type().name()
        info["category"] = node.type().category().name()
    except Exception:                                      # noqa: BLE001
        pass
    try:
        parent = node.parent()
        info["parent"] = parent.path() if parent is not None else ""
    except Exception:                                      # noqa: BLE001
        pass
    try:
        info["locked"] = bool(node.isInsideLockedHDA())
    except Exception:                                      # noqa: BLE001
        try:
            info["locked"] = bool(node.isEditableInsideLockedHDA()) is False
        except Exception:                                  # noqa: BLE001
            pass
    return info


# ---------------------------------------------------------------- 跳转
def _center(editor, node):
    """把节点挪到视图正中间（保持当前缩放）。"""
    import hou

    try:
        pos = node.position()
        bounds = editor.visibleBounds()
        width = min(max(bounds.width(), _MIN_VIEW), _MAX_VIEW)
        height = min(max(bounds.height(), _MIN_VIEW), _MAX_VIEW)
        editor.setVisibleBounds(hou.BoundingRect(
            pos.x() - width / 2.0, pos.y() - height / 2.0,
            pos.x() + width / 2.0, pos.y() + height / 2.0))
        return True
    except Exception:                                      # noqa: BLE001
        try:                                               # 兜底：选中后 home
            editor.homeToSelection()
            return True
        except Exception:                                  # noqa: BLE001
            return False


def jump_to_node(node_path):
    """把某个节点在当前网络里选中并居中。返回 {"ok", "message"}。"""
    try:
        import hou
    except Exception:                                      # noqa: BLE001
        return {"ok": False, "message": "这个环境里没有 hou（不在 Houdini 里跑）"}

    if not node_path:
        return {"ok": False, "message": "没有节点路径"}

    node = hou.node(node_path)
    if node is None:
        return {"ok": False, "message": "节点已经不在了：%s" % node_path}

    parent = node.parent()
    if parent is None:
        return {"ok": False, "message": "这个节点没有父层级，跳不过去：%s"
                % node_path}

    editor = _pick_editor(node) or ensure_editor()
    if editor is None:
        return {"ok": False, "message": "找不到网络编辑器面板，也没法新建一个"}

    try:
        editor.setIsCurrentTab()                           # 先把面板提到前面
    except Exception:                                      # noqa: BLE001
        pass

    try:
        editor.setPwd(parent)
    except Exception:                                      # noqa: BLE001
        try:
            editor.cd(parent.path())
        except Exception as exc:                           # noqa: BLE001
            return {"ok": False,
                    "message": "进不去 %s：%s" % (parent.path(), exc)}

    try:
        node.setCurrent(True, clear_all_selected=True)
    except Exception:                                      # noqa: BLE001
        try:
            node.setSelected(True, clear_all_selected=True)
        except Exception:                                  # noqa: BLE001
            pass

    centered = _center(editor, node)

    try:
        editor.flashMessage("跳到 %s" % node.name())
    except Exception:                                      # noqa: BLE001
        pass

    name = ""
    try:
        name = editor.name()
    except Exception:                                      # noqa: BLE001
        pass

    msg = "已跳到 %s（%s）" % (node_path, parent.path())
    if not centered:
        msg += "，但没能把它挪到正中"
    try:
        if node.isInsideLockedHDA():
            msg += "　⚠ 它在锁定的 HDA 里，可能只能在外面看到"
    except Exception:                                      # noqa: BLE001
        pass
    return {"ok": True, "message": msg, "editor": name}


def can_jump(node_path):
    """这个节点现在跳得过去吗。"""
    try:
        import hou
        return hou.node(node_path) is not None
    except Exception:                                      # noqa: BLE001
        return False
