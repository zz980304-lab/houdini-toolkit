# -*- coding: utf-8 -*-
"""工程保存工具（Houdini 工程打包）—— 界面层（精简版）。

当前阶段：**只有界面**。
    所有按钮的信号都已接好，但槽函数只往底部状态栏写一行提示。
    功能实现时，直接替换对应槽函数即可，界面代码不用动。

设计约定
--------
* 本文件不 import hou。Houdini 侧的数据全部由外部灌进来（见「对外接口」），
  这样界面可以脱离 Houdini 单独跑起来做预览、截图、调样式。
* 不写死配色，用 Qt 原生控件 + 极少量与主题无关的 QSS，
  这样在 Houdini 的深色 / 浅色主题下都不突兀。
* 分类不写死成一个个固定勾选项：扫描完之后按**实际出现的扩展名**列出来，
  没认出来的进「未识别格式」，所以插件自己的输出格式不会漏。
* 序列（filecache 输出的一堆帧）在清单里合并成一行，显示 `×240` 和帧范围；
  不同目录下的同名文件会标成橙色，靠「所在目录」列区分。

对外接口（以后由功能层调用）
--------
    win.set_hip_info(path="", size=0, mtime="", modified=False, version="")
    win.set_dependencies([{path, size, refs, status}, ...])
    win.set_status("就绪")
    win.set_progress(0, 100)
    win.append_log("...")            # 等价于 set_status，只显示最新一条

对外信号（功能层接这里）
--------
    win.scanRequested()        点了「扫描依赖」
    win.packRequested(dict)    点了「开始打包」，参数是 collect_options() 的结果
"""

import os

from . import classify
from .qt import (QtCore, QtGui, QtWidgets, Qt, Signal, enum_of, combine,
                 BINDING as _BINDING, QT_VERSION as _QT_VERSION)

# ---------------------------------------------------------------- 枚举常量
_ALIGN_LEFT = combine(enum_of(Qt, "AlignLeft"), enum_of(Qt, "AlignVCenter"))
_ALIGN_RIGHT = combine(enum_of(Qt, "AlignRight"), enum_of(Qt, "AlignVCenter"))
_ALIGN_CENTER = enum_of(Qt, "AlignCenter")
_CHECKED = enum_of(Qt, "Checked")
_UNCHECKED = enum_of(Qt, "Unchecked")
_PARTIAL = enum_of(Qt, "PartiallyChecked")
_USERROLE = enum_of(Qt, "UserRole")
_ITEM_FLAGS = combine(
    enum_of(Qt, "ItemIsEnabled"),
    enum_of(Qt, "ItemIsSelectable"),
    enum_of(Qt, "ItemIsUserCheckable"),
)
_TRISTATE_FLAGS = combine(_ITEM_FLAGS, enum_of(Qt, "ItemIsTristate"))
_STRETCH = enum_of(QtWidgets.QHeaderView, "Stretch")
_RESIZE_CONTENTS = enum_of(QtWidgets.QHeaderView, "ResizeToContents")
_NO_FRAME = enum_of(QtWidgets.QFrame, "NoFrame")
_SCROLL_OFF = enum_of(Qt, "ScrollBarAlwaysOff")

_RED = QtGui.QColor("#d9534f")
_GRAY = QtGui.QColor("#8a8a8a")
_WARN = QtGui.QColor("#e0a33e")      # 同名不同目录时的提示色

_STYLE = """
QGroupBox::title { font-weight: 600; }
QLabel#Hint { color: #8a8a8a; }
QLabel#Meta { color: #8a8a8a; }
QPushButton#Primary { font-weight: 600; padding: 4px 16px; }
QLabel#Summary { font-weight: 600; }
"""

#: 默认勾选的大类（渲染输出体积大，默认不带）
_DEFAULT_GROUPS = (classify.GEO, classify.TEX, classify.HDA, classify.REF,
                   classify.UNKNOWN)

#: 清单列
_COL_FILE, _COL_DIR, _COL_SIZE, _COL_REF, _COL_STATE = range(5)


def human_size(num_bytes):
    """把字节数变成人看的字符串。"""
    try:
        size = float(num_bytes or 0)
    except (TypeError, ValueError):
        return "—"
    if size <= 0:
        return "—"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024.0 or unit == "TB":
            if unit == "B":
                return "%d B" % int(size)
            return "%.1f %s" % (size, unit)
        size /= 1024.0


class HipPackerWindow(QtWidgets.QWidget):
    """主界面。

    * 当独立窗口用：hip_packer.show()
    * 当 Houdini Python Panel 用：return HipPackerWindow()（onCreateInterface 里）
    """

    scanRequested = Signal()
    packRequested = Signal(dict)
    #: 双击清单里某一项：(素材路径, 引用它的节点路径列表)
    #: 接上后：1 处引用 -> 直接在网络里选中并居中；多处 -> NodeJumpDialog 挑一个。
    dependencyActivated = Signal(str, list)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("工程保存工具")
        self.resize(1240, 720)
        self.setMinimumSize(980, 600)

        self._rows = []              # 清单行数据（dict），见 _make_rows()
        self._row_by_key = {}
        self._deps_raw = []          # 扫描原始数据（含被折叠的「HDA 内部引用」）
        self._folded = []            # 当前折叠掉的原始条目
        self._folded_rows = []       # 当前折叠掉的清单行（按行算）

        self._build_ui()
        self.setStyleSheet(_STYLE)
        self._connect_ui()
        self.set_status("当前只有界面，功能还没接上")
        self._enable_ime()

    # ------------------------------------------------------------ 输入法
    def _ime_widgets(self):
        """需要开输入法的控件（自己 + 里面所有输入框），算一次就缓存。"""
        cached = getattr(self, "_ime_widgets_cache", None)
        if cached is not None:
            return cached
        widgets = [self]
        for name in ("QLineEdit", "QTextEdit", "QPlainTextEdit"):
            klass = getattr(QtWidgets, name, None)
            if klass is None:
                continue
            try:
                widgets.extend(self.findChildren(klass))
            except Exception:                          # noqa: BLE001
                pass
        self._ime_widgets_cache = widgets
        return widgets

    def _enable_ime(self):
        """把输入法开关补回来（见模块级 `enable_ime` 的说明）。"""
        for widget in self._ime_widgets():
            try:
                widget.setAttribute(Qt.WA_InputMethodEnabled, True)
            except Exception:                          # noqa: BLE001
                pass

    def _start_ime_guard(self):
        """Houdini 会在窗口显示 / 激活**之后**又把开关关掉（实测补一次不够，
        它是在我们补完才翻的），所以挂个轻量的定时器盯着，掉了就补回来。
        只看几个控件的属性，开销可以忽略；窗口隐藏时直接跳过。
        """
        if getattr(self, "_ime_timer", None) is not None:
            return
        try:
            timer = QtCore.QTimer(self)
            timer.setInterval(500)
            timer.timeout.connect(self._on_ime_tick)
            timer.start()
            self._ime_timer = timer
        except Exception:                              # noqa: BLE001
            self._ime_timer = None

    def _on_ime_tick(self):
        if not self.isVisible():
            return
        try:
            need = [w for w in self._ime_widgets()
                    if not w.testAttribute(Qt.WA_InputMethodEnabled)]
        except Exception:                              # noqa: BLE001
            return
        if need:
            self._enable_ime()

    def showEvent(self, event):
        """窗口显示后输入法开关会被 Houdini 关掉，这里补一刀并起守卫。"""
        try:
            super(HipPackerWindow, self).showEvent(event)
        except Exception:                              # noqa: BLE001
            pass
        self._enable_ime()
        self._start_ime_guard()

    def event(self, ev):
        """窗口被激活（用户点回来）时再补一次，双保险。"""
        if _EV_WINDOW_ACTIVATE is not None:
            try:
                if ev.type() == _EV_WINDOW_ACTIVATE:
                    self._enable_ime()
            except Exception:                          # noqa: BLE001
                pass
        return super(HipPackerWindow, self).event(ev)

    # ================================================================ 构建
    def _build_ui(self):
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 10)
        root.setSpacing(8)
        root.addWidget(self._build_project_bar())
        root.addWidget(self._build_splitter(), 1)
        root.addWidget(self._build_output_bar())
        root.addLayout(self._build_action_bar())

    # ---------------------------------------------------------- 顶部工程信息
    def _build_project_bar(self):
        box = QtWidgets.QGroupBox("当前工程")
        grid = QtWidgets.QGridLayout(box)
        grid.setContentsMargins(12, 10, 12, 12)
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)

        self.hip_path_edit = QtWidgets.QLineEdit()
        self.hip_path_edit.setReadOnly(True)
        self.hip_path_edit.setPlaceholderText("还没保存过工程，或不在 Houdini 里运行")
        self.btn_pick_hip = QtWidgets.QPushButton("浏览…")

        self.hip_meta = QtWidgets.QLabel("—")
        self.hip_meta.setObjectName("Meta")

        grid.addWidget(QtWidgets.QLabel("工程文件"), 0, 0)
        grid.addWidget(self.hip_path_edit, 0, 1)
        grid.addWidget(self.btn_pick_hip, 0, 2)
        grid.addWidget(self.hip_meta, 1, 1, 1, 2)
        grid.setColumnStretch(1, 1)
        return box

    # ------------------------------------------------------------ 中间主区域
    def _build_splitter(self):
        split = QtWidgets.QSplitter()
        split.setChildrenCollapsible(False)
        split.addWidget(self._build_options_panel())
        split.addWidget(self._build_deps_panel())
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setSizes([400, 840])
        return split

    def _build_options_panel(self):
        tabs = QtWidgets.QTabWidget()
        tabs.addTab(self._scrollable(self._build_tab_content()), "打包内容")
        tabs.addTab(self._scrollable(self._build_tab_output()), "输出设置")
        tabs.setMinimumWidth(300)
        return tabs

    def _scrollable(self, page):
        """Tab 内容套一层滚动区，窗口拉小的时候不会被裁掉。"""
        area = QtWidgets.QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(_NO_FRAME)
        area.setHorizontalScrollBarPolicy(_SCROLL_OFF)
        area.viewport().setAutoFillBackground(False)
        area.setWidget(page)
        return area

    # Tab 1：打包内容
    def _build_tab_content(self):
        page = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(page)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(10)

        gb = self._group("工程本体")
        gb.layout().addWidget(self._hint("工程文件本身（必带）"))
        self.cb_backup = self._check("连同备份文件（.hip.bak / backup 目录）", False)
        gb.layout().addWidget(self.cb_backup)
        lay.addWidget(gb)

        self.cb_hda_only = self._check(
            "显示 HDA 内部引用、但磁盘上不存在的文件", False,
            "锁定 HDA 里面的节点在网络里是灰的、参数也改不动。它们引用的文件里，\n"
            "**磁盘上真的有**的那些（File Cache / Pyro 的缓存、HDA 里 ROP 写出来的 bgeo 等）\n"
            "是正经素材，一直照常显示；只有**磁盘上根本没有**的那些才折叠起来，\n"
            "例如第三方 HDA 自带的 pointlight.bgeo。勾上就能看见它们（也选不了、打不进包）。")
        self.cb_hda_only.stateChanged.connect(
            lambda *_: self._refresh_dependencies())
        lay.addWidget(self.cb_hda_only)

        lay.addWidget(self._hint(
            "扫描后按实际出现的格式列出。认不出来的进「未识别格式」，照样能勾选带走。"))

        self.kind_tree = QtWidgets.QTreeWidget()
        self.kind_tree.setHeaderHidden(True)
        self.kind_tree.setRootIsDecorated(True)
        self.kind_tree.setUniformRowHeights(True)
        self.kind_tree.setMinimumHeight(160)
        self.kind_tree.setColumnCount(2)
        self.kind_tree.header().setSectionResizeMode(0, _STRETCH)
        self.kind_tree.header().setSectionResizeMode(1, _RESIZE_CONTENTS)
        lay.addWidget(self.kind_tree, 1)

        self._set_kind_placeholder("还没扫描")
        return page

    # Tab 2：输出设置
    def _build_tab_output(self):
        page = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(page)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(10)

        gb = self._group("路径处理")
        self.mode_group = QtWidgets.QButtonGroup(self)
        for idx, (text, on) in enumerate((
            ("复制素材，并把工程里的路径改写成相对路径（推荐）", True),
            ("复制素材，但不改动工程里的路径", False),
        )):
            radio = QtWidgets.QRadioButton(text)
            radio.setChecked(on)
            self.mode_group.addButton(radio, idx)
            gb.layout().addWidget(radio)
        lay.addWidget(gb)

        gb2 = self._group("素材在包里怎么放")
        self.conflict_group = QtWidgets.QButtonGroup(self)
        for idx, (text, tip, on) in enumerate((
            ("工程内保留目录结构，工程外按类型分文件夹（推荐）",
             "本工程里的素材按原来的子目录放（geo/…、cache/…）；工程外（别的盘 / 网络盘）\n"
             "的按类型归类到子目录：image（贴图 / 图片序列）、cache（几何缓存、\n"
             "abc / usd / vdb / fbx / obj）、mov（视频）、audio（音频）、misc（其它）。\n"
             "这样跨盘引用不会在包里冒出 D:\\cache\\… 那种又深又没用的路径。",
             True),
            ("全部平铺到素材根目录，重名自动加后缀",
             "不管来自哪里，全部平铺。重名会变成 cache.bgeo.sc / cache_1.bgeo.sc，\n"
             "对应关系写进 manifest.json。",
             False),
            ("全部保留原始完整路径",
             "包里会完整重现 D:\\cache\\…、//server/… 这种层级，跨盘时目录很深。",
             False),
        )):
            radio = QtWidgets.QRadioButton(text)
            radio.setChecked(on)
            radio.setToolTip(tip)
            self.conflict_group.addButton(radio, idx)
            gb2.layout().addWidget(radio)

        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("素材根目录"))
        self.assets_root_edit = QtWidgets.QLineEdit("")
        self.assets_root_edit.setMaximumWidth(160)
        self.assets_root_edit.setPlaceholderText("留空：直接放工程旁边")
        self.assets_root_edit.setToolTip(
            "留空 = 素材目录直接和工程文件并列（v01.hip 旁边就是 geo/、cache/…）；\n"
            "填个名字（比如 assets）= 所有素材统一收进 包/assets/ 这个子目录。")
        row.addWidget(self.assets_root_edit)
        row.addStretch(1)
        gb2.layout().addLayout(row)
        gb2.layout().addWidget(self._hint(
            "HDA / OTL 不受这里影响：一律放进包里的 otls\\ 目录（工程根下）。"))
        lay.addWidget(gb2)

        gb3 = self._group("其它")
        self.cb_otl = self._check(
            "在工程里写入「打开时自动加载 otls/」的脚本", True,
            "Houdini 默认就会扫 $HIP/otls，这条是保险：万一对方机器自定义过\n"
            "HOUDINI_OTLSCAN_PATH（渲染农场常见），默认路径会丢，工程打开就会\n"
            "提示 incomplete asset definitions，加了这段就不会。")
        gb3.layout().addWidget(self.cb_otl)
        self.cb_zip = self._check("打包成 zip（完成后删掉中间目录）", False)
        gb3.layout().addWidget(self.cb_zip)
        self.cb_open = self._check("打包完成后打开输出目录", False)
        gb3.layout().addWidget(self.cb_open)
        gb3.layout().addWidget(self._hint("manifest.json 每次都会生成，不用勾。"))
        lay.addWidget(gb3)

        lay.addStretch(1)
        return page

    # ------------------------------------------------------------ 右侧依赖清单
    def _build_deps_panel(self):
        box = QtWidgets.QWidget()
        lay = QtWidgets.QVBoxLayout(box)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        head = QtWidgets.QHBoxLayout()
        title = QtWidgets.QLabel("依赖清单")
        title.setObjectName("Summary")
        head.addWidget(title)
        head.addStretch(1)
        self.summary_label = QtWidgets.QLabel("还没扫描")
        self.summary_label.setObjectName("Meta")
        head.addWidget(self.summary_label)
        lay.addLayout(head)

        tools = QtWidgets.QHBoxLayout()
        tools.setSpacing(6)
        self.search_edit = QtWidgets.QLineEdit()
        self.search_edit.setPlaceholderText("搜文件名 / 所在目录 / 引用节点…")
        self.btn_all = QtWidgets.QPushButton("全选")
        self.btn_none = QtWidgets.QPushButton("全不选")
        self.btn_missing = QtWidgets.QPushButton("只看缺失")
        for w in (self.search_edit, self.btn_all, self.btn_none, self.btn_missing):
            tools.addWidget(w)
        tools.setStretch(0, 1)
        lay.addLayout(tools)

        self.dep_tree = QtWidgets.QTreeWidget()
        self.dep_tree.setColumnCount(5)
        self.dep_tree.setHeaderLabels(["文件", "所在目录", "大小", "引用节点", "状态"])
        self.dep_tree.setAlternatingRowColors(True)
        self.dep_tree.setUniformRowHeights(True)
        header = self.dep_tree.header()
        header.setSectionResizeMode(_COL_FILE, enum_of(QtWidgets.QHeaderView, "Interactive"))
        header.setSectionResizeMode(_COL_DIR, _STRETCH)
        header.setSectionResizeMode(_COL_SIZE, enum_of(QtWidgets.QHeaderView, "Fixed"))
        header.setSectionResizeMode(_COL_REF, enum_of(QtWidgets.QHeaderView, "Interactive"))
        header.setSectionResizeMode(_COL_STATE, enum_of(QtWidgets.QHeaderView, "Fixed"))
        self.dep_tree.setColumnWidth(_COL_FILE, 235)
        self.dep_tree.setColumnWidth(_COL_SIZE, 72)
        self.dep_tree.setColumnWidth(_COL_REF, 155)
        self.dep_tree.setColumnWidth(_COL_STATE, 58)
        lay.addWidget(self.dep_tree, 1)

        self.set_dependencies([])
        return box

    # ------------------------------------------------------------ 输出位置
    def _build_output_bar(self):
        box = QtWidgets.QGroupBox("输出")
        grid = QtWidgets.QGridLayout(box)
        grid.setContentsMargins(12, 10, 12, 12)
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(6)

        self.output_dir_edit = QtWidgets.QLineEdit()
        self.output_dir_edit.setPlaceholderText("打包结果放哪里…")
        self.btn_pick_out = QtWidgets.QPushButton("浏览…")
        self.pack_name_edit = QtWidgets.QLineEdit()
        self.pack_name_edit.setPlaceholderText("默认取工程文件名")

        grid.addWidget(QtWidgets.QLabel("输出到"), 0, 0)
        grid.addWidget(self.output_dir_edit, 0, 1)
        grid.addWidget(self.btn_pick_out, 0, 2)
        grid.addWidget(QtWidgets.QLabel("包名"), 1, 0)
        grid.addWidget(self.pack_name_edit, 1, 1, 1, 2)
        grid.setColumnStretch(1, 1)
        return box

    # ------------------------------------------------------------ 底部按钮
    def _build_action_bar(self):
        row = QtWidgets.QHBoxLayout()
        row.setSpacing(8)
        self.status_label = QtWidgets.QLabel("就绪")
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFixedWidth(180)
        row.addWidget(self.status_label, 1)
        row.addWidget(self.progress)
        self.btn_scan = QtWidgets.QPushButton("扫描依赖")
        self.btn_pack = QtWidgets.QPushButton("开始打包")
        self.btn_pack.setObjectName("Primary")
        self.btn_close = QtWidgets.QPushButton("关闭")
        row.addWidget(self.btn_scan)
        row.addWidget(self.btn_pack)
        row.addWidget(self.btn_close)
        return row

    # ------------------------------------------------------------ 小工具
    def _group(self, title):
        gb = QtWidgets.QGroupBox(title)
        lay = QtWidgets.QVBoxLayout(gb)
        lay.setContentsMargins(10, 8, 10, 10)
        lay.setSpacing(6)
        return gb

    def _check(self, text, checked=False, tip=""):
        cb = QtWidgets.QCheckBox(text)
        cb.setChecked(bool(checked))
        try:                       # Qt6 才有，Qt5 的 QCheckBox 没这个方法
            cb.setWordWrap(True)
        except AttributeError:
            pass
        if tip:
            cb.setToolTip(tip)
        return cb

    def _hint(self, text):
        lab = QtWidgets.QLabel(text)
        lab.setObjectName("Hint")
        lab.setWordWrap(True)
        f = lab.font()
        if f.pointSize() > 0:
            f.setPointSize(max(7, f.pointSize() - 1))
            lab.setFont(f)
        return lab

    # ================================================================ 信号
    def _connect_ui(self):
        self.search_edit.textChanged.connect(lambda *_: self._apply_filter())
        self.btn_all.clicked.connect(lambda: self._set_visible_checked(True))
        self.btn_none.clicked.connect(lambda: self._set_visible_checked(False))
        self.btn_missing.clicked.connect(self._filter_only_missing)
        self.dep_tree.itemDoubleClicked.connect(self._on_dep_activated)
        self.kind_tree.itemChanged.connect(
            lambda item, col: self._sync_tristate(self.kind_tree, item, col))
        self.dep_tree.itemChanged.connect(
            lambda item, col: self._sync_tristate(self.dep_tree, item, col))

        # 下面这些按钮的功能还没写，先在状态栏提示；功能层接管时会断开这些占位槽
        self.btn_scan.clicked.connect(self._on_scan)
        self.btn_pack.clicked.connect(self._on_pack)
        self.btn_close.clicked.connect(self.close)
        self.btn_pick_hip.clicked.connect(self._on_pick_hip)
        self.btn_pick_out.clicked.connect(self._on_pick_out)

    def release_placeholder_slots(self):
        """功能层（controller）接管前调用：断开纯占位的槽，别再提示「还没实现」。

        ⚠️ **只断 `_on_pick_*` 这两个**。`_on_scan` / `_on_pack` 不是占位 ——
        它们负责把按钮点击转成 `scanRequested` / `packRequested` 信号，
        功能层监听的就是这两个信号。把它们也断掉的话，点按钮会**完全没反应**
        （2026-10-16 踩过：界面看着好好的，点扫描一动不动）。
        """
        pairs = ((self.btn_pick_hip, self._on_pick_hip),
                 (self.btn_pick_out, self._on_pick_out))
        for button, slot in pairs:
            try:
                button.clicked.disconnect(slot)
            except Exception:                              # noqa: BLE001
                pass

    def _todo(self, what):
        self.set_status("「%s」还没实现" % what)

    def _on_pick_hip(self):
        self._todo("选择工程文件")

    def _on_pick_out(self):
        self._todo("选择输出目录")

    def _on_scan(self):
        """点「扫描依赖」：只负责发信号，活由功能层干。"""
        self.scanRequested.emit()

    def _on_pack(self):
        """点「开始打包」：先检查填没填全，再发信号。"""
        opts = self.collect_options()
        if not opts["hip_path"]:
            self.set_status("先选一个工程文件。")
            return
        if not opts["output_dir"]:
            self.set_status("先选输出目录。")
            return
        self.packRequested.emit(opts)

    @staticmethod
    def _sync_tristate(tree, item, column):
        """父项（大类）跟子项（具体格式 / 具体文件）的勾选联动。"""
        if column != 0 or item is None:
            return
        tree.blockSignals(True)
        if item.parent() is None:
            state = item.checkState(0)
            if state == _PARTIAL:              # 点在父项上，一律当全选
                state = _CHECKED
                item.setCheckState(0, state)
            for i in range(item.childCount()):
                item.child(i).setCheckState(0, state)
        else:
            parent = item.parent()
            if parent.parent() is None:        # 只有两层，父就是大类标题
                checked = sum(1 for i in range(parent.childCount())
                              if parent.child(i).checkState(0) == _CHECKED)
                total = parent.childCount()
                parent.setCheckState(
                    0, _CHECKED if checked == total
                    else (_UNCHECKED if checked == 0 else _PARTIAL))
        tree.blockSignals(False)

    # ================================================================ 分类面板
    def _set_kind_placeholder(self, text):
        self.kind_tree.blockSignals(True)
        self.kind_tree.clear()
        it = QtWidgets.QTreeWidgetItem(self.kind_tree, [text, ""])
        it.setFlags(enum_of(Qt, "NoItemFlags"))
        it.setForeground(0, QtGui.QBrush(_GRAY))
        self.kind_tree.setFixedHeight(40)
        self.kind_tree.blockSignals(False)

    def _rebuild_kind_tree(self, counts):
        """counts: {(大类, 扩展名): 项数}，按它生成两级勾选树。"""
        self.kind_tree.blockSignals(True)
        self.kind_tree.clear()

        groups = {}
        for (grp, ext), n in counts.items():
            groups.setdefault(grp, {})[ext] = n

        order = {name: i for i, name in enumerate(classify.GROUP_ORDER)}
        rows = 0
        for grp in sorted(groups, key=lambda g: (order.get(g, len(order)), g)):
            exts = groups[grp]
            total = sum(exts.values())
            top = QtWidgets.QTreeWidgetItem(
                self.kind_tree, ["%s（%d）" % (grp, total), ""])
            f = top.font(0)
            f.setBold(True)
            top.setFont(0, f)
            top.setFlags(_TRISTATE_FLAGS)
            top.setCheckState(0, _CHECKED if grp in _DEFAULT_GROUPS else _UNCHECKED)
            rows += 1
            for ext in sorted(exts, key=lambda e: (-exts[e], e)):
                child = QtWidgets.QTreeWidgetItem(
                    top, [".%s" % classify.describe_ext(ext), "%d" % exts[ext]])
                child.setFlags(_ITEM_FLAGS)
                child.setCheckState(0, top.checkState(0))
                child.setData(0, _USERROLE, (grp, ext))
                child.setForeground(1, QtGui.QBrush(_GRAY))
                rows += 1
            top.setExpanded(True)

        self.kind_tree.blockSignals(False)
        # 让树刚好装下内容；太长就自己滚，免得把下半截顶出可视区
        row_h = max(self.kind_tree.sizeHintForRow(0), 18)
        self.kind_tree.setFixedHeight(min(rows * row_h + 10, 290))

    def _selected_kinds(self):
        """返回 (勾选的大类集合, 勾选的扩展名集合)。"""
        groups, exts = set(), set()
        root = self.kind_tree.invisibleRootItem()
        for i in range(root.childCount()):
            top = root.child(i)
            for j in range(top.childCount()):
                child = top.child(j)
                if child.checkState(0) == _CHECKED:
                    data = child.data(0, _USERROLE)
                    if data:
                        groups.add(data[0])
                        exts.add(data[1])
        return groups, exts

    # ================================================================ 清单
    def _make_rows(self, files):
        """把扫描结果整理成清单行：序列合并成一行，重名算出来。"""
        files = list(files or [])
        # 序列统一判定：同目录下连号 >= 2 个才算，免得把 v06 / barrel_01 当帧
        given = {}
        for raw in files:
            if raw.get("sequence") is not None:
                given[str(raw.get("path") or "")] = bool(raw["sequence"])
        auto = classify.detect_sequences(
            [str(r.get("path") or "") for r in files if r.get("path")])
        is_seq = {}
        for path in set(list(auto) + list(given)):
            is_seq[path] = given.get(path, auto.get(path, False))

        buckets = {}
        for raw in files:
            path = str(raw.get("path") or "")
            if not path:
                continue
            refs = raw.get("refs") or []
            if isinstance(refs, str):
                refs = [refs] if refs else []
            seq = is_seq.get(path, False)
            grp, ext = classify.classify(path, forced_sequence=seq)

            # 序列的分组 key 优先用扫描层给的「骨架」（来自参数里的 $F 写法）：
            # 靠文件名去猜会把 `x.9.bgeo.sc` 和 `x.10.bgeo.sc` 拆成两段。
            seq_label = str(raw.get("seq_label") or "")
            if seq:
                key = raw.get("seq_key") or classify.seq_key(path)
            else:
                key = path
            row = buckets.get(key)
            if row is None:
                row = dict(
                    key=key,
                    name=(seq_label or (classify.seq_label(path) if seq
                                        else os.path.basename(path))),
                    raw_label=seq_label,
                    directory=classify.parent_dir(path),
                    size=0, refs=[], missing=0, count=0,
                    group=grp, ext=ext, is_seq=bool(seq),
                    frames=[], files=[], sample=path, ambiguous=False,
                    hda_refs=0, visible_refs=0, hda_only=False, folded=False,
                )
                buckets[key] = row
            row["size"] += raw.get("size") or 0
            row["count"] += 1
            row["files"].append(path)
            row["hda_refs"] += raw.get("hda_refs") or 0
            row["visible_refs"] += raw.get("visible_refs") or 0
            if (raw.get("status") == "缺失") or raw.get("missing"):
                row["missing"] += 1
            for r in refs:
                if r and r not in row["refs"]:
                    row["refs"].append(r)
            if seq:
                num = None
                if seq_label:                    # 有骨架就按骨架取帧号，最准
                    num = classify.frame_number_in_pattern(seq_label, path)
                if num is None:
                    num = classify.frame_number(path)
                if num is not None:
                    row["frames"].append(num)

        rows = list(buckets.values())
        for row in rows:
            # 整行都只被灰节点引用 -> 这行属于「HDA 内部引用」
            row["hda_only"] = bool(row["hda_refs"]) and not row["visible_refs"]
            # 只有「里面一个文件都没找到」的才折叠（磁盘上有东西就必须让人看见）
            row["folded"] = bool(row["hda_only"] and row["count"]
                                 and row["missing"] == row["count"])

        # 同名不同目录 -> 打标记，界面上把目录列标出来
        seen = {}
        for row in rows:
            seen.setdefault(row["name"], []).append(row)
        for group in seen.values():
            if len(group) > 1:
                for row in group:
                    row["ambiguous"] = True
        return rows

    def _add_dep_item(self, parent, row):
        name = row["name"]
        tip_lines = []
        if row["is_seq"] and row["frames"]:
            frames = sorted(row["frames"])
            width = max(len(str(frames[0])), 1)
            if row.get("raw_label"):
                # 骨架是用户自己在参数里写的（$F / $F4 原样），别改他写的位数
                name = row["raw_label"]
            elif "$F" in name:
                name = name.replace("$F", "$F%d" % width)
            name = "%s  ×%d" % (name, row["count"])
            tip_lines.append("帧范围：%d - %d" % (frames[0], frames[-1]))
            if row["missing"]:
                tip_lines.append("缺 %d 帧" % row["missing"])
        elif row["is_seq"]:
            name = "%s  [$F]" % name

        refs = row["refs"]
        ref_text = refs[0] if refs else ""
        if len(refs) > 1:
            ref_text = "%s 等 %d 处" % (refs[0], len(refs))

        if row["missing"] == 0:
            state = "找到"
        elif row["missing"] == row["count"]:
            state = "缺失"
        else:
            state = "缺 %d/%d" % (row["missing"], row["count"])

        item = QtWidgets.QTreeWidgetItem(parent, [
            name,
            classify.shorten(row["directory"], 44),
            human_size(row["size"]),
            classify.shorten(ref_text, 30),
            state,
        ])
        item.setFlags(_ITEM_FLAGS)
        item.setCheckState(0, _UNCHECKED if row["missing"] else _CHECKED)
        item.setData(0, _USERROLE, row["key"])

        tip_lines.insert(0, "完整路径：%s%s" % (
            row["sample"], "   （这是一段序列）" if row["is_seq"] else ""))
        tip_lines.append("所在目录：%s" % (row["directory"] or "—"))
        if row["is_seq"]:
            tip_lines.append("序列帧数：%d（清单里合并成一行）" % row["count"])
        if refs:
            tip_lines.append("引用位置（%d 处）：" % len(refs))
            tip_lines.extend("    " + r for r in refs[:12])
            if len(refs) > 12:
                tip_lines.append("    … 还有 %d 处" % (len(refs) - 12))
        if row.get("hda_refs"):
            if row.get("visible_refs"):
                tip_lines.append("另有 %d 处引用来自 HDA 内部（灰节点），已归到外层节点。"
                                 % row["hda_refs"])
            else:
                tip_lines.append("⚠ 只有 HDA 内部（灰节点）在用它，那里的路径改不了；"
                                 "只要它还在 $HIP 下面，包内结构不变就能继续用。")
                if row.get("folded"):
                    tip_lines.append("（磁盘上没这个文件，所以默认折叠了；"
                                     "左侧开关可以把它放出来看）")
        if row["ambiguous"]:
            tip_lines.append("⚠ 有同名文件在别的目录，靠「所在目录」区分，别搞混。")
        item.setToolTip(0, "\n".join(tip_lines))
        item.setToolTip(_COL_DIR, row["directory"])

        if row["ambiguous"]:
            for col in (_COL_FILE, _COL_DIR):
                item.setForeground(col, QtGui.QBrush(_WARN))
            f = item.font(_COL_DIR)
            f.setBold(True)
            item.setFont(_COL_DIR, f)
        if row["missing"]:
            item.setForeground(_COL_STATE, QtGui.QBrush(_RED))
        else:
            item.setForeground(_COL_STATE, QtGui.QBrush(_GRAY))
        return item

    def set_dependencies(self, files):
        """files: [{"path":..., "size":..., "refs": [节点路径...], "status":...}]

        每项可能带 `hda_only=True`（只被锁定 HDA 内部的灰节点引用）——
        默认折叠不显示，勾上左边那个开关才列出来。
        """
        self._deps_raw = list(files or [])
        self._refresh_dependencies()

    def _refresh_dependencies(self):
        """按当前开关把清单重画一遍（扫描完、切「显示灰节点引用」时都走这里）。"""
        show_hda = True
        try:
            show_hda = bool(self.cb_hda_only.isChecked())
        except Exception:                                  # noqa: BLE001
            pass

        shown, folded = [], []
        for raw in self._deps_raw:
            # 只有「只被 HDA 内部引用 + 磁盘上没有」的才折叠；
            # 磁盘上真有的（缓存）跟普通素材一样正常显示可选。
            (folded if raw.get("folded") else shown).append(raw)
        self._folded = folded
        # 折了几「行」要按清单的行来算（一段 120 帧的序列只算一行）
        self._folded_rows = self._make_rows(folded)
        files = list(self._deps_raw) if show_hda else shown

        self._rows = self._make_rows(files)
        self._row_by_key = {r["key"]: r for r in self._rows}
        self.dep_tree.blockSignals(True)
        self.dep_tree.clear()

        if not self._rows:
            if self._folded_rows and not show_hda:
                # 扫到的东西全在 HDA 内部：别显示「还没扫描」误导人
                placeholder = QtWidgets.QTreeWidgetItem(
                    self.dep_tree, ["扫到的都在 HDA 内部（灰节点）里，而且磁盘上都没有："
                                    "已折叠 %d 行，勾左侧开关查看" % len(self._folded_rows),
                                    "", "", "", ""])
                placeholder.setForeground(0, QtGui.QBrush(_GRAY))
                placeholder.setFlags(enum_of(Qt, "NoItemFlags"))
                self.summary_label.setText(
                    "共 0 行　·　已折叠 %d 行（只被 HDA 内部引用、磁盘上没有）"
                    % len(self._folded_rows))
                self._set_kind_placeholder("已折叠")
                self.dep_tree.blockSignals(False)
                return
            placeholder = QtWidgets.QTreeWidgetItem(
                self.dep_tree, ["点下面的「扫描依赖」开始分析工程…", "", "", "", ""])
            placeholder.setForeground(0, QtGui.QBrush(_GRAY))
            placeholder.setFlags(enum_of(Qt, "NoItemFlags"))
            self.summary_label.setText("还没扫描")
            self._set_kind_placeholder("还没扫描")
            self.dep_tree.blockSignals(False)
            return

        order = {name: i for i, name in enumerate(classify.GROUP_ORDER)}
        self._rows.sort(key=lambda r: (order.get(r["group"], len(order)),
                                       r["name"].lower()))

        total_bytes = sum(r["size"] for r in self._rows)
        missing_rows = sum(1 for r in self._rows if r["missing"])
        ambiguous = sum(1 for r in self._rows if r["ambiguous"])

        groups, counts = {}, {}
        for row in self._rows:
            groups.setdefault(row["group"], []).append(row)
            counts[(row["group"], row["ext"])] = \
                counts.get((row["group"], row["ext"]), 0) + 1

        for grp in sorted(groups, key=lambda g: (order.get(g, len(order)), g)):
            rows = groups[grp]
            top = QtWidgets.QTreeWidgetItem(
                self.dep_tree, ["%s（%d）" % (grp, len(rows)), "",
                                human_size(sum(r["size"] for r in rows)), "", ""])
            f = top.font(0)
            f.setBold(True)
            top.setFont(0, f)
            top.setFlags(_TRISTATE_FLAGS)
            top.setCheckState(0, _CHECKED)
            for row in rows:
                self._add_dep_item(top, row)
            top.setExpanded(True)

        summary = "共 %d 项　·　合计 %s　·　缺失 %d" % (
            len(self._rows), human_size(total_bytes), missing_rows)
        if ambiguous:
            summary += "　·　同名 %d" % ambiguous
        if self._folded_rows and not show_hda:
            summary += "　·　已折叠 %d 行（只被 HDA 内部引用、磁盘上没有）" % (
                len(self._folded_rows),)
        self.summary_label.setText(summary)

        self._rebuild_kind_tree(counts)
        self.dep_tree.blockSignals(False)
        self._apply_filter()

    def folded_stats(self):
        """(折叠掉的清单行数, 折叠掉的文件个数) —— 状态栏要用。"""
        return len(self._folded_rows), len(self._folded)

    def _apply_filter(self):
        text = self.search_edit.text().strip().lower()
        root = self.dep_tree.invisibleRootItem()
        for i in range(root.childCount()):
            top = root.child(i)
            top_hit = bool(text) and text in top.text(0).lower()
            shown = 0
            for j in range(top.childCount()):
                child = top.child(j)
                hit = (not text) or top_hit or any(
                    text in child.text(c).lower() for c in range(5))
                child.setHidden(not hit)
                shown += 1 if hit else 0
            top.setHidden(shown == 0)

    def _set_visible_checked(self, state):
        root = self.dep_tree.invisibleRootItem()
        for i in range(root.childCount()):
            top = root.child(i)
            if top.isHidden():
                continue
            for j in range(top.childCount()):
                child = top.child(j)
                if not child.isHidden():
                    child.setCheckState(0, _CHECKED if state else _UNCHECKED)

    def _on_dep_activated(self, item, column):
        """双击某项素材：把「引用它的节点」交给功能层去跳。

        跳到哪、怎么跳（一处直接跳 / 多处弹窗挑）由 controller 决定，
        界面只负责把素材路径和节点列表递出去。
        """
        if item is None or item.parent() is None:      # 点到大类标题不管
            return
        row = self._row_by_key.get(item.data(0, _USERROLE))
        if not row:
            return
        refs = list(row["refs"])
        if not refs:
            self.set_status("这一项没记到引用节点（可能是 HDA 来源或未落盘的参数）")
            return
        self.dependencyActivated.emit(row["sample"], refs)

    def _filter_only_missing(self):
        """「只看缺失」：切到按状态筛。"""
        current = self.search_edit.text().strip()
        self.search_edit.setText("" if current == "缺失" else "缺失")

    def selected_dependencies(self):
        """清单里被勾上的项，每个带它实际包含的文件列表。"""
        out = []
        root = self.dep_tree.invisibleRootItem()
        for i in range(root.childCount()):
            top = root.child(i)
            for j in range(top.childCount()):
                item = top.child(j)
                if item.checkState(0) != _CHECKED:
                    continue
                row = self._row_by_key.get(item.data(0, _USERROLE))
                if not row:
                    continue
                out.append({
                    "path": row["sample"],
                    "files": list(row["files"]),
                    "directory": row["directory"],
                    "group": row["group"],
                    "ext": row["ext"],
                    "is_sequence": row["is_seq"],
                    "missing": row["missing"],
                    "refs": list(row["refs"]),
                    "size": row["size"],
                })
        return out

    # ================================================================ 对外接口
    def set_hip_info(self, path="", size=0, mtime="", modified=False, version=""):
        self.hip_path_edit.setText(path or "")
        bits = []
        if size:
            bits.append("大小 %s" % human_size(size))
        if mtime:
            bits.append("修改于 %s" % mtime)
        bits.append("有未保存修改" if modified else "已保存")
        if version:
            bits.append("Houdini %s" % version)
        self.hip_meta.setText("　·　".join(bits) if path else "—")
        if path and not self.pack_name_edit.text().strip():
            self.pack_name_edit.setText(
                os.path.splitext(os.path.basename(path))[0] + "_pack")

    def set_status(self, text):
        self.status_label.setText(text)

    def set_progress(self, value, maximum=100):
        self.progress.setRange(0, maximum)
        self.progress.setValue(value)

    def append_log(self, text):
        """没有日志面板了，最新一条信息显示在底部状态栏。"""
        self.set_status(text)

    def set_busy(self, busy):
        """干活期间把「扫描 / 打包」按钮按掉，避免连点。

        只是禁用按钮，窗口本身还能动（能看进度、能拖、能关）。
        """
        for button in (self.btn_scan, self.btn_pack):
            try:
                button.setEnabled(not busy)
            except Exception:                              # noqa: BLE001
                pass

    def collect_options(self):
        """把界面上的选择收成一个 dict —— 功能层直接吃这个。"""
        groups, exts = self._selected_kinds()
        return {
            "hip_path": self.hip_path_edit.text().strip(),
            "include_backup": self.cb_backup.isChecked(),
            "asset_groups": sorted(groups),
            "asset_exts": sorted(exts),
            "rewrite_paths": self.mode_group.checkedId() == 0,
            "layout_policy": self.conflict_group.checkedId(),
            "assets_root": self.assets_root_edit.text().strip(),
            "otl_loader": self.cb_otl.isChecked(),
            "zip": self.cb_zip.isChecked(),
            "open_after": self.cb_open.isChecked(),
            "output_dir": self.output_dir_edit.text().strip(),
            "pack_name": self.pack_name_edit.text().strip(),
            "files": self.selected_dependencies(),
        }


class PackProgressDialog(QtWidgets.QDialog):
    """打包进度框（非模态）。

    为什么是**非模态**：模态框（exec_）会连 Houdini 一起锁住，用户就真的一动不能
    动了（2026-10-16 用户原话「期间 houdini 是卡死状态不能动」）。这里只 show()，
    干活的函数一边跑一边往里灌进度、并且持续 processEvents，所以：
    进度条在走、Houdini 也能点、想中止随时按「取消」。

    用法（controller 里）：
        dlg = PackProgressDialog(win); dlg.show()
        dlg.set_phase("复制素材"); dlg.set_percent(30); dlg.set_detail("xxx.bgeo")
        if dlg.is_canceled(): ...        # 复制 / 子进程都会定时问这个
        dlg.close()
    """

    #: 点了「取消」或关掉窗口
    canceled = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("正在打包")
        self.resize(480, 150)
        self.setMinimumWidth(420)
        self.setWindowModality(enum_of(Qt, "NonModal"))
        self.setAttribute(enum_of(Qt, "WA_DeleteOnClose"), False)

        self._canceled = False

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(8)

        self.phase_label = QtWidgets.QLabel("准备…")
        self.phase_label.setObjectName("Summary")
        root.addWidget(self.phase_label)

        self.bar = QtWidgets.QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(True)
        self.bar.setFixedHeight(18)
        root.addWidget(self.bar)

        self.detail_label = QtWidgets.QLabel("")
        self.detail_label.setObjectName("Hint")
        self.detail_label.setWordWrap(True)
        self.detail_label.setMinimumHeight(30)
        root.addWidget(self.detail_label)

        bar = QtWidgets.QHBoxLayout()
        bar.addStretch(1)
        self.btn_cancel = QtWidgets.QPushButton("取消")
        self.btn_cancel.setFixedWidth(90)
        self.btn_cancel.clicked.connect(self._on_cancel)
        bar.addWidget(self.btn_cancel)
        root.addLayout(bar)

        self.setStyleSheet(_STYLE)

    # ------------------------------------------------------------ 对外
    def set_phase(self, text):
        self.phase_label.setText(text or "")

    def set_detail(self, text):
        self.detail_label.setText(text or "")

    def set_percent(self, value):
        """0~100。传 None 表示「说不准」，走来回滚动的忙动画。"""
        if value is None:
            self.set_busy(True)
            return
        try:
            value = int(max(0, min(100, value)))
        except (TypeError, ValueError):
            return
        if self.bar.minimum() != 0 or self.bar.maximum() != 100:
            self.bar.setRange(0, 100)
        self.bar.setValue(value)

    def set_busy(self, busy=True):
        """不确定进度的阶段（比如等 hython 子进程）用来回滚动表示「还在跑」。"""
        if busy:
            self.bar.setRange(0, 0)
        else:
            self.bar.setRange(0, 100)

    def is_canceled(self):
        return bool(self._canceled)

    def finish(self, text="完成"):
        """收尾：进度拉满、取消按钮变关闭。"""
        self.set_busy(False)
        self.bar.setValue(100)
        self.phase_label.setText(text)
        self.detail_label.setText("")
        try:
            self.btn_cancel.setText("关闭")
            self.btn_cancel.setEnabled(True)
            self.btn_cancel.clicked.disconnect(self._on_cancel)
        except Exception:                                  # noqa: BLE001
            pass
        self.btn_cancel.clicked.connect(self.close)

    # ------------------------------------------------------------ 内部
    def _on_cancel(self):
        if self._canceled:
            return
        self._canceled = True
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.setText("正在停止…")
        self.phase_label.setText("正在停止…")
        self.detail_label.setText("已经复制的文件会留在输出目录里")
        self.canceled.emit()

    def closeEvent(self, event):
        """直接关窗口 = 取消。"""
        if not self._canceled:
            self._canceled = True
            try:
                self.canceled.emit()
            except Exception:                              # noqa: BLE001
                pass
        try:
            super(PackProgressDialog, self).closeEvent(event)
        except Exception:                                  # noqa: BLE001
            pass

    def keyPressEvent(self, event):
        if event.key() == enum_of(Qt, "Key_Escape"):
            self._on_cancel()
            return
        super(PackProgressDialog, self).keyPressEvent(event)


class NodeJumpDialog(QtWidgets.QDialog):
    """一份素材被多处引用时，弹出来让用户挑一个节点跳过去。

    纯界面：不认识 hou。外面把节点信息喂进来（见 `set_nodes`），
    双击 / 回车 / 点按钮都会发 `nodeActivated(节点路径)`，跳不跳由功能层决定。

    做成**非模态**是故意的：模态框会把 Houdini 整个卡住，
    那样跳过去也看不成、更没法接着挑下一个节点。
    """

    #: 双击（或回车）了列表里的某一项 -> 节点路径
    nodeActivated = Signal(str)

    def __init__(self, parent=None, asset=""):
        super().__init__(parent)
        self.setWindowTitle("这个素材被多处引用")
        self.resize(620, 340)
        self.setWindowModality(enum_of(Qt, "NonModal"))
        self.setAttribute(enum_of(Qt, "WA_DeleteOnClose"), False)

        self._rows = []                 # [{"path", "type", "parms", "exists"}]

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        self.head = QtWidgets.QLabel("")
        self.head.setObjectName("Summary")
        self.head.setWordWrap(True)
        root.addWidget(self.head)

        hint = QtWidgets.QLabel("双击哪个就跳到哪个（或选中后回车）")
        hint.setObjectName("Hint")
        root.addWidget(hint)

        self.filter_edit = QtWidgets.QLineEdit()
        self.filter_edit.setPlaceholderText("过滤节点路径 / 类型 / 参数…")
        self.filter_edit.textChanged.connect(self._apply_filter)
        root.addWidget(self.filter_edit)

        self.list = QtWidgets.QTreeWidget()
        self.list.setColumnCount(4)
        self.list.setHeaderLabels(["节点", "类型", "引用参数", "状态"])
        self.list.setAlternatingRowColors(True)
        self.list.setUniformRowHeights(True)
        self.list.setRootIsDecorated(False)
        self.list.setSelectionMode(
            enum_of(QtWidgets.QAbstractItemView, "ExtendedSelection"))
        header = self.list.header()
        header.setSectionResizeMode(0, _RESIZE_CONTENTS)
        header.setSectionResizeMode(1, _RESIZE_CONTENTS)
        header.setSectionResizeMode(2, _STRETCH)
        header.setSectionResizeMode(3, _RESIZE_CONTENTS)
        self.list.setColumnWidth(0, 250)
        self.list.setColumnWidth(1, 110)
        self.list.setColumnWidth(3, 70)
        self.list.itemDoubleClicked.connect(self._activate_item)
        root.addWidget(self.list, 1)

        bar = QtWidgets.QHBoxLayout()
        bar.addStretch(1)
        self.btn_jump = QtWidgets.QPushButton("跳到选中")
        self.btn_jump.setObjectName("Primary")
        self.btn_jump.clicked.connect(self._activate_current)
        self.btn_close = QtWidgets.QPushButton("关闭")
        self.btn_close.clicked.connect(self.close)
        bar.addWidget(self.btn_jump)
        bar.addWidget(self.btn_close)
        root.addLayout(bar)

        self.setStyleSheet(_STYLE)
        self.set_asset(asset)
        enable_ime(self)

    def showEvent(self, event):
        """跟主窗口一样：显示后把输入法开关补回来（过滤框才能打中文）。"""
        try:
            super(NodeJumpDialog, self).showEvent(event)
        except Exception:                              # noqa: BLE001
            pass
        enable_ime(self)
        # 这个框是临时弹窗，用定时器盯着不划算，改成「拿到焦点就补一次」
        try:
            self.filter_edit.installEventFilter(self)
        except Exception:                              # noqa: BLE001
            pass

    def eventFilter(self, obj, event):
        """过滤框拿到焦点时补一次输入法开关（Houdini 会在之后把它关掉）。"""
        try:
            if obj is self.filter_edit and \
                    event.type() == enum_of(QtCore, "FocusIn"):
                enable_ime(self.filter_edit)
        except Exception:                              # noqa: BLE001
            pass
        return super(NodeJumpDialog, self).eventFilter(obj, event)

    # ------------------------------------------------------------ 数据
    def set_asset(self, asset):
        """asset: 素材路径（或序列的第一帧），只用于显示在标题上。"""
        name = os.path.basename(asset or "")
        if not name:
            self.head.setText("选一个引用它的节点")
            self.setWindowTitle("引用这个素材的节点")
            return
        self.setWindowTitle("%s —— 被这些节点引用" % name)
        self.head.setText(name)
        self.head.setToolTip(asset or "")

    def set_nodes(self, nodes):
        """nodes: [{"path", "type", "parms": [...], "exists": bool}]"""
        self._rows = list(nodes or [])
        self.list.blockSignals(True)
        self.list.clear()
        for row in self._rows:
            path = row.get("path") or ""
            parms = row.get("parms") or []
            item = QtWidgets.QTreeWidgetItem(self.list, [
                path,
                row.get("type") or "—",
                "、".join(parms) if parms else "—",
                "" if row.get("exists", True) else "已删除",
            ])
            item.setData(0, _USERROLE, path)
            item.setToolTip(0, path)
            if parms:
                item.setToolTip(2, "\n".join(parms))
            if not row.get("exists", True):
                item.setForeground(0, QtGui.QBrush(_RED))
                item.setForeground(3, QtGui.QBrush(_RED))
            self.list.addTopLevelItem(item)
        self.list.blockSignals(False)
        if self._rows:
            self.list.setCurrentItem(self.list.topLevelItem(0))
        self._apply_filter()

    # ------------------------------------------------------------ 交互
    def _apply_filter(self):
        text = self.filter_edit.text().strip().lower()
        for i in range(self.list.topLevelItemCount()):
            item = self.list.topLevelItem(i)
            hit = (not text) or any(
                text in (item.text(c) or "").lower() for c in range(4))
            item.setHidden(not hit)

    def _visible_count(self):
        return sum(0 if self.list.topLevelItem(i).isHidden() else 1
                   for i in range(self.list.topLevelItemCount()))

    def _activate_item(self, item, column=0):
        if item is None:
            return
        path = item.data(0, _USERROLE)
        if path:
            self.nodeActivated.emit(str(path))
            self.raise_()
            self.activateWindow()

    def _activate_current(self):
        item = self.list.currentItem()
        if item is None or item.isHidden():
            for i in range(self.list.topLevelItemCount()):
                cand = self.list.topLevelItem(i)
                if not cand.isHidden():
                    item = cand
                    break
        self._activate_item(item)

    def keyPressEvent(self, event):
        key = event.key()
        if key in (enum_of(Qt, "Key_Return"), enum_of(Qt, "Key_Enter")):
            self._activate_current()
            return
        if key == enum_of(Qt, "Key_Escape"):
            self.close()
            return
        super(NodeJumpDialog, self).keyPressEvent(event)


def enable_ime(widget):
    """把这个窗口 / 控件（含它里面所有输入框）的**输入法开关**打开。

    为什么需要这玩意（2026-10-16 用户报「输入框打不出中文，只能粘贴」）：
    Houdini 自己的输入框走它那套原生 IME，所以**它把整棵控件树的
    `Qt.WA_InputMethodEnabled` 都关掉了**（实测：Houdini 主窗口、里面 92 个
    QLineEdit 全是 False）。而 Qt 的 Windows 输入法上下文在决定「要不要帮你
    起拼音」时问的就是这个属性 —— 关着就压根不起输入法，于是只能粘贴。

    我们的输入框是**新建时 True、`show()` / 被激活之后变成 False**
    （逐步打印实测：new=True → show=False）。所以**补一次不够**，
    得在 构建 / show / 每次窗口被激活 时都补一遍（见下面两处调用）。
    """
    try:
        widget.setAttribute(Qt.WA_InputMethodEnabled, True)
    except Exception:                                  # noqa: BLE001
        pass
    for name in ("QLineEdit", "QTextEdit", "QPlainTextEdit"):
        klass = getattr(QtWidgets, name, None)
        if klass is None:
            continue
        try:
            for child in widget.findChildren(klass):
                try:
                    child.setAttribute(Qt.WA_InputMethodEnabled, True)
                except Exception:                      # noqa: BLE001
                    pass
        except Exception:                              # noqa: BLE001
            pass


#: QEvent.WindowActivate（Qt5 / Qt6 写法不同，取不到就置 None，代码里有兜底）
try:
    _EV_WINDOW_ACTIVATE = enum_of(QtCore, "WindowActivate")
except Exception:                                      # noqa: BLE001
    _EV_WINDOW_ACTIVATE = None

__all__ = ["HipPackerWindow", "NodeJumpDialog", "PackProgressDialog",
           "human_size", "enable_ime"]
