# -*- coding: utf-8 -*-
"""改写：把包里那份工程的参数，从「原来的路径」改成「包内的相对路径」。

为什么单独开一个 hython 进程做这事
--------------------------------
改写要 `hou.hipFile.load()`，那会把当前会话整个换掉。要是在你正用的
Houdini 里直接跑，你的场景就没了。所以这里用子进程（hython）打开包里那份
副本，改完保存，主会话一根汗毛都不动。

映射表怎么来的
--------------
scan 阶段记下了每个「参数」的原文（node / parm / raw / 展开后的路径），
plan 阶段算出了每个文件在包里的位置，两者一合就是
`(节点, 参数) -> 新值（$HIP/assets/...）`，照着 set 回去即可。
序列会把帧号还原成 $F4，不然 240 帧会被写死成第一帧。

移动文件 = 移动引用，两边必须对得上
----------------------------------
文件搬走以后工程里的引用必须跟着走，这里有四个容易漏的点，都处理了：

1. **一个参数写了多个路径**（比如 `file` 里 `a.abc b.abc`）：整段替换会把
   没变的那个也冲掉，所以这里按**段**逐个换成新值再拼回去。
2. **没搬进包的文件不改写**：复制失败 / 磁盘上根本没有的文件，包里没有它，
   把参数改成 `$HIP/assets/...` 只会指向一个不存在的地方，比不改更糟。
   所以改写表只认「确实复制成功的」那些（controller 会把名单传进来）。
3. **HDA / OTL 要先装再 load**：包里那份工程如果用到 otls/ 下的 HDA，
   直接 `hipFile.load()` 会先报 incomplete asset definitions，里面的参数
   就改不动了。所以 load 之前先把包内 otls/ 全装一遍。
4. **改完当场复查**：`verify_paths()` 会把包内工程所有文件参数重新展开，
   逐个看「落在包里吗 / 磁盘上有吗」，漏网的写进 manifest，不留哑巴引用。

顺便还会往工程里塞一段「打开时自动加载 otls/」的 python
------------------------------------------------------
Houdini 的 .hip 里可以存一段跟工程绑定的 python（叫 session module，
Window ▸ Python Source Editor 里那块），**打开这个工程时会自动执行**。
打包时往里加一段：把 `$HIP/otls/` 下的 HDA / OTL 全装回来。

为什么需要它：Houdini 默认就会扫 `$HIP/otls`（实测换目录、运行中 File▸Open
都有效），所以正常情况下不加也没事；但如果谁的机器上自定义过
`HOUDINI_OTLSCAN_PATH`（渲染农场很常见）又没带 `&`，默认路径就丢了，
工程打开会报 "incomplete asset definitions"。装了这段就等于上了保险。
实测：HDA 放非标准目录时，加了这段脚本后那条警告消失。
"""

import json
import os
import re
import subprocess
import sys
import time

try:                                   # 正常当包用
    from . import classify
except (ImportError, ValueError):      # 被 hython 当脚本直接跑时没有包上下文
    import importlib.util

    _spec = importlib.util.spec_from_file_location(
        "hip_packer_classify",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "classify.py"))
    classify = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(classify)


def _scan_mod():
    """拿到 scan 模块（校验时要复用它的遍历 / 展开逻辑）。

    在 Houdini 里就是 `hip_packer.scan`；被 hython 当脚本跑时没有包，
    退一步按文件路径加载一份（scan.py 自己也做了同样的兜底，见它开头）。
    """
    try:
        from . import scan as mod
        return mod
    except (ImportError, ValueError):
        pass
    try:
        import importlib.util

        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scan.py")
        spec = importlib.util.spec_from_file_location("hip_packer_scan", path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:                                      # noqa: BLE001
        return None


# ---------------------------------------------------------------- 映射表
#: 写进工程的「打开时自动加载 otls/」脚本。用这行注释当标记，
#: 重复打包时不会越加越多；用户自己改过的内容也不会被覆盖（只追加）。
OTL_LOADER_MARK = "# === hip_packer: 打开工程时自动加载 otls/ 里的 HDA / OTL ==="

#: 这段代码会被保存进 .hip，打开工程时自动跑。写得尽量保守：
#: 一句一个 try，任何一步失败都不该影响工程正常打开。
OTL_LOADER_SOURCE = "\n".join([
    OTL_LOADER_MARK,
    "# 打包时加进来的：把本工程 otls/ 下的 HDA / OTL 装回当前环境，",
    "# 免得换机器打开时提示 incomplete asset definitions。",
    "import os as _hp_os",
    "import glob as _hp_glob",
    "import hou as _hp_hou",
    "try:",
    "    _hp_dir = _hp_os.path.join(_hp_hou.expandString('$HIP'), 'otls')",
    "    _hp_exts = ('.hda', '.otl', '.hdalc', '.otlc', '.hdanc', '.otlnc')",
    "    _hp_have = set(_hp_hou.hda.loadedFiles())",
    "    for _hp_f in sorted(_hp_glob.glob(_hp_os.path.join(_hp_dir, '*'))):",
    "        if _hp_os.path.splitext(_hp_f)[1].lower() not in _hp_exts:",
    "            continue",
    "        if _hp_f in _hp_have:",
    "            continue",
    "        try:",
    "            _hp_hou.hda.installFile(_hp_f, change_oplibraries_file=False)",
    "        except Exception:",
    "            pass",
    "except Exception:",
    "    pass",
    "",
])


def install_otl_loader():
    """往当前会话工程的 session module 里加一段「打开时执行」的 python。

    ⚠️ 只在子进程里用（它改的是内存中的工程内容，需要随后 save）。
    返回 True 表示这次真的写进去了，False 表示原本就有（不重复加）。
    """
    import hou

    try:
        current = hou.sessionModuleSource() or ""
    except Exception:                                      # noqa: BLE001
        current = ""
    if OTL_LOADER_MARK in current:
        return False
    hou.appendSessionModuleSource(OTL_LOADER_SOURCE)
    return True


def _rel_index(plan):
    """把 plan.rel_mapping 做成好查的索引（算一次，挂在 plan 上复用）。

    三张表：
      exact  原样查得到（绝大多数）
      folded 忽略大小写（Windows 上盘符 / 目录名大小写经常不一致）
      seqs   按序列骨架查（参数里写的是 $F4，表里存的是 1001、1002…）
    """
    index = getattr(plan, "_rewrite_index", None)
    if index is not None:
        return index
    exact, folded, seqs = {}, {}, {}
    for src, dst in (plan.rel_mapping or {}).items():
        key = os.path.normpath(str(src))
        exact[key] = dst
        folded.setdefault(os.path.normcase(key), (key, dst))
        sk = classify.seq_key(key)
        if sk != key:
            seqs.setdefault(os.path.normcase(sk), (key, dst))
    index = {"exact": exact, "folded": folded, "seqs": seqs}
    try:
        plan._rewrite_index = index
    except Exception:                                      # noqa: BLE001
        pass
    return index


def _normalize_allow(allow):
    """把「允许改写的原路径」集合统一成好比对的样子。

    来源可能是 plan 里的 src（normpath 过的，Windows 上是反斜杠），
    也可能是界面 / 测试里手写的斜杠路径，大小写也未必一致，所以这里
    几种写法都收进来，免得明明复制成功了却被当成「没搬进包」而漏改。
    """
    if allow is None:
        return None
    out = set()
    for item in allow or ():
        text = str(item)
        norm = os.path.normpath(text)
        out.add(text)
        out.add(norm)
        out.add(os.path.normcase(text))
        out.add(os.path.normcase(norm))
    return out


def _lookup_new_value(ref, plan, index=None, allow=None):
    """找到这个参数引用对应的新值；找不到返回 None。

    allow: 允许改写的原始路径集合（= 真的复制进包了的那些）。
           传 None 表示不限制（测试 / 手动调用时用）。
    """
    index = index or _rel_index(plan)
    src = os.path.normpath(str(ref.get("path") or ""))
    hit = None
    if src in index["exact"]:
        hit = (src, index["exact"][src])
    if hit is None:
        hit = index["folded"].get(os.path.normcase(src))
    if hit is None and ref.get("is_sequence"):
        hit = index["seqs"].get(os.path.normcase(classify.seq_key(src)))
    if hit is None:
        return None
    if allow is not None and hit[0] not in allow:
        return None                                        # 没搬进包，别改它
    return hit[1]


def build_rewrite_report(parm_refs, plan, allow=None):
    """算改写表，同时把「为什么没改」的原因也报出来。

    返回 ({(节点, 参数): 新值}, [没改的条目...])
    """
    index = _rel_index(plan)
    allow = _normalize_allow(allow)
    groups = {}                        # 参数 -> 这个参数上所有要替换的段
    skipped = []
    for ref in parm_refs or []:
        node = ref.get("node") or ""
        parm = ref.get("parm") or ""
        key = (node, parm)
        new_raw = _lookup_new_value(ref, plan, index=index, allow=allow)
        if not new_raw:
            skipped.append({
                "node": node, "parm": parm,
                "path": ref.get("path") or "",
                "reason": ("这个文件没复制进包，引用保持原样"
                           if _lookup_new_value(ref, plan, index=index) else
                           "包里没有它的新位置"),
            })
            continue
        if ref.get("is_sequence"):
            new_raw = _restore_frame_token(ref.get("raw") or "", new_raw)
        info = groups.setdefault(key, {"total": 1, "parts": [], "full": ""})
        # 这个参数原本写了几段（有段没搬进包时也得知道，不然会把它冲掉）
        info["total"] = max(info["total"], int(ref.get("segments") or 1))
        info["full"] = info["full"] or ref.get("full") or ref.get("value") or ""
        info["parts"].append({
            "old": ref.get("value") or "",
            "new": new_raw,
        })

    rewrite_map = {}
    for key, info in groups.items():
        parts = info["parts"]
        if len(parts) == 1 and info["total"] == 1:         # 最常见：一个参数一个路径
            rewrite_map[key] = parts[0]["new"]
            continue
        # 一个参数写了多个路径：按段换掉，没搬进包 / 没变的段原样留着
        text = info["full"]
        ok = bool(text)
        for part in parts:
            old, new = part["old"], part["new"]
            if old and old in text:
                text = text.replace(old, new, 1)
            else:                                          # 拼不回去，这个参数先不动
                ok = False
                break
        if ok:
            rewrite_map[key] = text
        else:
            skipped.append({
                "node": key[0], "parm": key[1],
                "path": " | ".join(p["old"] for p in parts),
                "reason": "一个参数里有多个路径，没能安全地逐段替换",
            })
    return rewrite_map, skipped


def build_rewrite_map(parm_refs, plan, allow=None):
    """(scan 的参数引用, 打包计划) -> {(节点路径, 参数名): 新值}"""
    return build_rewrite_report(parm_refs, plan, allow=allow)[0]


def _restore_frame_token(raw, new_raw):
    """新值里的具体帧号换回 $F4：assets/cache.1001.bgeo.sc -> assets/cache.$F4.bgeo.sc"""
    tokens = classify._F_RE.findall(raw or "")
    if not tokens:
        return new_raw
    token = tokens[0]
    directory, name = os.path.split(new_raw.replace("/", os.sep))
    m = classify._NUM_RE.match(name)
    if not m:
        return new_raw
    name = "%s%s%s%s" % (m.group("base"), m.group("sep"), token, m.group("ext"))
    return os.path.join(directory, name).replace(os.sep, "/")


# ---------------------------------------------------------------- 打开工程之前
def preload_pack_otls(hip_path):
    """load 工程**之前**先把包里 otls/ 下的 HDA 装好，返回装了几个。

    为什么要抢在前面：包里那份工程一旦用到这些 HDA，直接 load 的话 Houdini
    在那一刻还找不着定义，节点会变成 incomplete asset definitions，
    里面的参数就读不到了，改写自然落空。
    """
    import hou

    otl_dir = os.path.join(os.path.dirname(os.path.abspath(hip_path or "")),
                           classify.OTL_DIRNAME)
    if not os.path.isdir(otl_dir):
        return 0
    exts = set(classify.EXT_GROUPS.get(classify.HDA, ()))
    try:
        loaded = set(hou.hda.loadedFiles())
    except Exception:                                      # noqa: BLE001
        loaded = set()
    installed = 0
    try:
        names = sorted(os.listdir(otl_dir))
    except Exception:                                      # noqa: BLE001
        return 0
    for name in names:
        if classify.norm_ext(name) not in exts:
            continue
        full = os.path.join(otl_dir, name)
        if full in loaded:
            continue
        try:
            hou.hda.installFile(full, change_oplibraries_file=False)
            installed += 1
        except Exception:                                  # noqa: BLE001
            continue
    return installed


# ---------------------------------------------------------------- 复查
def verify_paths(pack_dir=None):
    """把当前会话里这个工程的所有文件引用重新展开，看看是不是都落在包里。

    返回 {"checked": 查了多少, "inside": 有几个在包内,
          "outside": [还在包外的引用...], "missing": [包里找不到的...],
          "hda_missing": [HDA 文件不在的...]}
    """
    import hou

    scan_mod = _scan_mod()
    if scan_mod is None:
        return {"checked": 0, "inside": 0, "outside": [], "missing": [],
                "hda_missing": [], "error": "加载 scan 模块失败，跳过校验"}

    hip = ""
    try:
        hip = hou.hipFile.path()
    except Exception:                                      # noqa: BLE001
        pass
    pack_dir = os.path.normpath(pack_dir or os.path.dirname(hip or ""))
    pack_low = os.path.normcase(pack_dir)

    outside, missing, hda_missing = [], [], []
    checked = inside = 0

    for node in scan_mod.iter_nodes():
        try:
            node_path = node.path()
        except Exception:                                  # noqa: BLE001
            continue
        for parm, is_list in scan_mod.file_parms(node):
            raw = scan_mod.raw_value(parm)
            if not raw:
                continue
            value, _has_f = scan_mod.expand_value(parm, raw)
            if not value:
                continue
            for one in scan_mod.split_multi(value, is_list):
                if not scan_mod.is_file_like(one):
                    continue
                path = scan_mod.absolutize(one)
                if not path:
                    continue
                checked += 1
                entry = {"node": node_path, "parm": parm.name(),
                         "value": raw, "path": path}
                low = os.path.normcase(path)
                if not (low == pack_low or low.startswith(pack_low + os.sep)):
                    outside.append(entry)
                    continue
                if "$F" in os.path.basename(path):
                    hits, _ = scan_mod.on_disk(path)
                    if hits:
                        inside += 1
                    else:
                        missing.append(entry)
                elif os.path.isfile(path):
                    inside += 1
                else:
                    missing.append(entry)

    # HDA / OTL：节点类型指向的文件还在不在
    try:
        hfs = (hou.getenv("HFS") or "").replace("\\", "/").rstrip("/").lower()
    except Exception:                                      # noqa: BLE001
        hfs = ""
    seen = set()
    for node in scan_mod.iter_nodes():
        try:
            defn = node.type().definition()
        except Exception:                                  # noqa: BLE001
            continue
        if defn is None:
            continue
        try:
            lib = defn.libraryFilePath() or ""
        except Exception:                                  # noqa: BLE001
            continue
        if not lib or lib in ("Embedded", "Unknown"):
            continue
        if lib in seen:
            continue
        seen.add(lib)
        low = lib.replace("\\", "/").lower()
        if hfs and low.startswith(hfs):
            continue
        if not os.path.isfile(lib):
            try:
                node_path = node.path()
            except Exception:                              # noqa: BLE001
                node_path = ""
            hda_missing.append({"node": node_path, "parm": "*",
                                "value": node.type().name(), "path": lib})

    return {"checked": checked, "inside": inside,
            "outside": outside, "missing": missing,
            "hda_missing": hda_missing}


# ---------------------------------------------------------------- 执行改写
def rewrite_hip(hip_path, rewrite_map, save=True, otl_loader=False, verify=True):
    """在当前 Houdini 会话里改写（**会覆盖当前场景**，只给子进程用）。

    otl_loader=True 时会额外往工程里加一段「打开时自动加载 otls/」的 python。
    verify=True 时改完当场复查一遍，结果放在返回值的 "verify" 里。
    """
    import hou

    otls_preloaded = 0
    load_errors = []
    try:
        otls_preloaded = preload_pack_otls(hip_path)
    except Exception as exc:                               # noqa: BLE001
        load_errors.append("预装 otls/ 失败：%s" % exc)

    # ignore_load_warnings：HDA 没装全时 Houdini 会抛 LoadWarning，
    # 但那些节点的参数多半还在，照样能改 —— 不能因为一句警告整包失败。
    try:
        hou.hipFile.load(hip_path, suppress_save_prompt=True,
                         ignore_load_warnings=True)
    except Exception as exc:                               # noqa: BLE001
        load_errors.append("打开包内工程失败：%s" % exc)
        return {"changed": [], "failed": [("$HIP", "hipFile", e)
                                          for e in load_errors],
                "hip": hip_path, "saved": False,
                "error": "；".join(load_errors)}

    by_node = {}
    for (node_path, parm_name), new_value in (rewrite_map or {}).items():
        by_node.setdefault(node_path, {})[parm_name] = new_value

    changed, failed = [], []
    for node_path, mapping in by_node.items():
        node = hou.node(node_path)
        if node is None:
            failed.append((node_path, "*", "节点不存在"))
            continue
        for parm_name, new_value in mapping.items():
            parm = node.parm(parm_name)
            if parm is None:
                failed.append((node_path, parm_name, "参数不存在"))
                continue
            try:
                old = parm.unexpandedString()
            except Exception:                              # noqa: BLE001
                old = ""
            if old == new_value:
                continue
            try:
                parm.set(new_value)
                changed.append({
                    "node": node_path, "parm": parm_name,
                    "old": old, "new": new_value,
                })
            except Exception as exc:                       # noqa: BLE001
                failed.append((node_path, parm_name, str(exc)))

    # 打开时自动加载 otls/ 的脚本
    otl_added = False
    if otl_loader:
        try:
            otl_added = install_otl_loader()
        except Exception as exc:                           # noqa: BLE001
            failed.append(("$HIP", "sessionModule",
                           "写「打开时加载 otls」脚本失败：%s" % exc))

    # 改完当场复查：还有没有引用留在包外 / 指向包里不存在的文件
    checked = None
    if verify:
        try:
            checked = verify_paths(os.path.dirname(os.path.abspath(hip_path)))
        except Exception as exc:                           # noqa: BLE001
            checked = {"error": "复查时出错：%s" % exc}

    if save and (changed or otl_added):
        hou.hipFile.save()
    return {"changed": changed, "failed": failed,
            "hip": hip_path, "saved": bool(save and (changed or otl_added)),
            "otl_loader_added": otl_added,
            "otls_preloaded": otls_preloaded,
            "load_warnings": load_errors,
            "verify": checked}


# ---------------------------------------------------------------- 子进程
def find_hython(hfs=None):
    """找到 hython 可执行文件。"""
    try:
        import hou
        hfs = hfs or hou.getenv("HFS")
    except Exception:                                      # noqa: BLE001
        hfs = hfs or os.environ.get("HFS")
    if not hfs:
        return None
    for rel in ("bin/hython.exe", "bin/hython", "bin/hcmd.exe"):
        cand = os.path.join(hfs, rel.replace("/", os.sep))
        if os.path.isfile(cand):
            return cand
    return None


def _hidden_kwargs():
    """Windows 上启动子进程的参数：不要把 cmd 黑框弹到用户脸前。

    hython 是控制台程序，直接 Popen 会额外开一个控制台窗口
    （2026-10-16 用户报「打包时弹出一个 cmd 命令框」）。
    STARTF_USESHOWWINDOW + CREATE_NO_WINDOW 双保险：老 Python 没有
    CREATE_NO_WINDOW 时，至少 STARTUPINFO 也管一半用。
    """
    if os.name != "nt":
        return {}
    kwargs = {}
    try:
        info = subprocess.STARTUPINFO()
        info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        info.wShowWindow = 0                               # SW_HIDE
        kwargs["startupinfo"] = info
    except Exception:                                      # noqa: BLE001
        pass
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    if flags:
        kwargs["creationflags"] = flags
    return kwargs


def _wait_polling(proc, timeout, on_poll=None, cancel=None):
    """等子进程结束，但**不把调用方（Houdini 界面）堵死**。

    每隔 0.15 秒调一次 on_poll()（界面层拿它刷进度条 / processEvents），
    cancel() 返回 True 就杀掉子进程。返回 (returncode 或 None, 是否取消)。
    """
    deadline = time.time() + max(1.0, float(timeout or 900))
    while proc.poll() is None:
        if on_poll is not None:
            try:
                on_poll()
            except Exception:                              # noqa: BLE001
                pass
        if cancel is not None:
            try:
                if cancel():
                    _kill(proc)
                    return None, True
            except Exception:                              # noqa: BLE001
                pass
        if time.time() > deadline:
            _kill(proc)
            return None, False
        try:
            proc.wait(timeout=0.15)
        except Exception:                                  # noqa: BLE001
            try:                                           # 老 Python 没有 wait(timeout)
                time.sleep(0.15)
            except Exception:                              # noqa: BLE001
                pass
    return proc.returncode, False


def _kill(proc):
    try:
        proc.terminate()
    except Exception:                                      # noqa: BLE001
        pass
    try:
        proc.wait(timeout=5)
        return
    except Exception:                                      # noqa: BLE001
        pass
    try:
        proc.kill()
        proc.wait(timeout=5)
    except Exception:                                      # noqa: BLE001
        pass


def launch(hip_path, rewrite_map, out_json=None, timeout=900, otl_loader=False,
           verify=True, on_poll=None, cancel=None):
    """开一个 hython 子进程去改写，返回结果 dict（失败时带 error）。

    只想加「打开时加载 otls/」脚本、不需要改路径时，
    rewrite_map 传空 dict 即可（此时 otl_loader 必须为 True，否则直接跳过）。
    verify=True 时会顺带复查一遍包内引用（结果在返回值的 "verify" 里）。

    on_poll()  子进程跑着的时候反复调用 —— 界面层用它刷进度条 / 处理事件，
               这样 Houdini 不会「假死」（以前是 subprocess.run 死等，
               这期间整个界面点不动）。
    cancel()   返回 True 就杀掉子进程并返回 error="已取消"。
    """
    import tempfile

    hython = find_hython()
    if not hython:
        return {"ok": False, "error": "找不到 hython（HFS 没设？）"}
    if not rewrite_map and not otl_loader:
        return {"ok": True, "changed": [], "failed": [], "skipped": True}

    work = tempfile.mkdtemp(prefix="hip_packer_")
    map_file = os.path.join(work, "rewrite_map.json")
    result_file = out_json or os.path.join(work, "rewrite_result.json")
    # json 的 key 只能是字符串，把 (节点, 参数) 拼成 "节点\x00参数"
    flat = {"%s\x00%s" % (node, parm): value
            for (node, parm), value in rewrite_map.items()}
    with open(map_file, "w", encoding="utf-8") as fh:
        json.dump(flat, fh, ensure_ascii=False)

    here = os.path.dirname(os.path.abspath(__file__))
    cmd = [hython, os.path.join(here, "rewrite.py"),
           hip_path, map_file, result_file, "1" if otl_loader else "0",
           "1" if verify else "0"]
    # 输出写文件，不用 PIPE：hython 话多，管道满了会把它自己堵死
    out_log = os.path.join(work, "stdout.log")
    err_log = os.path.join(work, "stderr.log")
    try:
        with open(out_log, "wb") as fo, open(err_log, "wb") as fe:
            proc = subprocess.Popen(cmd, stdout=fo, stderr=fe,
                                    **_hidden_kwargs())
            returncode, canceled = _wait_polling(proc, timeout,
                                                 on_poll=on_poll, cancel=cancel)
    except Exception as exc:                               # noqa: BLE001
        return {"ok": False, "error": "启动 hython 失败：%s" % exc,
                "stdout": "", "stderr": str(exc)}

    if canceled:
        return {"ok": False, "error": "已取消", "canceled": True,
                "stdout": "", "stderr": ""}
    if returncode is None:
        return {"ok": False, "error": "子进程超时（%s 秒），包里的工程没改"
                % timeout, "stdout": _tail(out_log), "stderr": _tail(err_log)}

    result = None
    if os.path.isfile(result_file):
        try:
            with open(result_file, encoding="utf-8") as fh:
                result = json.load(fh)
        except Exception as exc:                           # noqa: BLE001
            result = {"ok": False, "error": "读结果失败：%s" % exc}
    if result is None:
        result = {"ok": False, "error": "子进程没写出结果"}
    result.setdefault("ok", False)
    result["stdout"] = _tail(out_log)
    result["stderr"] = _tail(err_log)
    result["returncode"] = returncode
    if result["ok"] and returncode != 0:
        # 活干完才崩的（hython 保存完 hip 退出时偶尔这样），结果是可信的
        result["note"] = ("改写已完成，但子进程退出码是 %d"
                          "（hython 收尾时的老毛病，不影响结果）" % returncode)
    return result


def _tail(path, limit=2000):
    try:
        with open(path, "rb") as fh:
            return fh.read().decode("utf-8", "replace")[-limit:]
    except Exception:                                      # noqa: BLE001
        return ""


def _main(argv):
    """hython 入口：rewrite.py <hip> <map.json> <out.json> [要不要加 otl 脚本]"""
    if len(argv) < 4:
        return 2
    hip_path, map_file, out_file = argv[1], argv[2], argv[3]
    otl_loader = len(argv) > 4 and argv[4] not in ("0", "", "false", "False")
    verify = not (len(argv) > 5 and argv[5] in ("0", "", "false", "False"))
    here = os.path.dirname(os.path.abspath(__file__))
    parent = os.path.dirname(here)
    if parent not in sys.path:
        sys.path.insert(0, parent)

    out = {"ok": False}
    try:
        with open(map_file, encoding="utf-8") as fh:
            flat = json.load(fh)
        # "节点\x00参数" 还原成 (节点, 参数)
        rewrite_map = {tuple(k.split("\x00")): v for k, v in flat.items()}
        result = rewrite_hip(hip_path, rewrite_map, otl_loader=otl_loader,
                             verify=verify)
        result["ok"] = True
        out = result
    except Exception:                                      # noqa: BLE001
        import traceback
        out = {"ok": False, "error": traceback.format_exc()}

    # key 里有 \x00，json.dump 会转义，读取端 split 还原
    out = {k: v for k, v in out.items()}
    with open(out_file, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(_main(sys.argv))
