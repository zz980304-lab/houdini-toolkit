# -*- coding: utf-8 -*-
"""把界面和功能接起来（界面不认识 hou，功能不认识 Qt，这一层负责牵线）。

    win = HipPackerWindow()
    ctrl = HipPackerController(win)      # 接上之后按钮就真能干活了

流程：扫描 -> 规划包内结构 -> 复制 -> 改写副本里的路径 -> 出 manifest/README -> 可选 zip
"""

import os
import time
import traceback

from . import classify
from . import manifest
from . import navigate
from . import plan as plan_mod
from . import rewrite
from . import scan as scan_mod
from . import transfer
from .qt import enum_of


def _version():
    try:
        from . import __version__
        return __version__
    except Exception:                                      # noqa: BLE001
        return ""


class HipPackerController(object):
    """界面 <-> 功能。"""

    def __init__(self, win):
        self.win = win
        self._scan = None            # 上一次扫描结果（改写路径要用）
        self._cancel = False
        self._busy = False
        self._jump_dialog = None     # 「多处引用」弹窗，得自己拿着别被回收
        self._dlg = None             # 打包进度框（打包期间一直开着）
        self._rewrite_t0 = 0.0       # 子进程改写开始的时间，用来显示「已跑 N 秒」

        win.release_placeholder_slots()
        win.scanRequested.connect(self.do_scan)
        win.packRequested.connect(self.do_pack)
        win.btn_pick_hip.clicked.connect(self.pick_hip)
        win.btn_pick_out.clicked.connect(self.pick_output_dir)
        win.btn_close.clicked.connect(self.win.close)
        win.dependencyActivated.connect(self.on_dependency_activated)

        self._refresh_hip()
        # 让人一眼看出功能层真的接上了（否则点按钮没反应时不知道是没接还是坏了）
        try:
            if not (self.win.status_label.text() or "").startswith("已就绪"):
                self.win.set_status("已就绪：点「扫描依赖」开始（v%s）"
                                    % _version())
        except Exception:                                  # noqa: BLE001
            pass

    # ------------------------------------------------------------ 小工具
    def _pump(self):
        """复制大文件时让界面还能动。"""
        try:
            from .qt import QtWidgets
            app = QtWidgets.QApplication.instance()
            if app is not None:
                app.processEvents()
        except Exception:                                  # noqa: BLE001
            pass

    def _progress(self, done, total, path=""):
        self.win.set_progress(done, max(total, 1))
        if path:
            self.win.set_status("复制 %d/%d：%s" % (
                done + 1, total, os.path.basename(path)))
        self._pump()

    def _on_rewrite_poll(self):
        """hython 子进程跑着的时候反复调这个：刷「已跑 N 秒」+ 让界面能喘气。

        以前是 subprocess.run 死等，这期间 Houdini 整个点不动（像卡死）；
        现在改成边等边 processEvents，界面一直活着。
        """
        dlg = self._dlg
        try:
            seconds = time.time() - (self._rewrite_t0 or time.time())
            if dlg is not None:
                dlg.set_detail("已跑 %.0f 秒（后台处理，界面可以正常用）"
                               % seconds)
        except Exception:                                  # noqa: BLE001
            pass
        self._pump()

    def _rewrite_extra(self, options, rewrite_result, rewrite_skipped):
        """改写这一段写进 manifest 的内容（排查引用问题时看这个）。"""
        result = rewrite_result or {}
        verify = result.get("verify") or {}
        extra = {
            "enabled": bool(options.get("rewrite_paths")),
            "changed": len(result.get("changed") or []),
            "error": result.get("error") or "",
            "failed": [{"node": n, "parm": p, "error": e}
                       for n, p, e in (result.get("failed") or [])],
            "not_rewritten": (rewrite_skipped or [])[:200],
            "otls_preloaded": result.get("otls_preloaded") or 0,
        }
        if verify:
            extra["verify"] = {
                "checked": verify.get("checked") or 0,
                "inside": verify.get("inside") or 0,
                "outside": (verify.get("outside") or [])[:200],
                "missing": (verify.get("missing") or [])[:200],
                "hda_missing": (verify.get("hda_missing") or [])[:200],
                "error": verify.get("error") or "",
            }
        return extra

    def _report_verify(self, verify):
        """把「改完之后的复查结果」说清楚：有没有引用还留在包外 / 指向空处。"""
        if not verify:
            return
        if verify.get("error"):
            self.win.set_status("复查没跑起来：%s" % verify["error"])
            return
        outside = verify.get("outside") or []
        missing = verify.get("missing") or []
        hda_missing = verify.get("hda_missing") or []
        self.win.set_status(
            "复查：%d 个引用 · 包内 %d · 还在包外 %d · 指向空处 %d"
            % (verify.get("checked") or 0, verify.get("inside") or 0,
               len(outside), len(missing)))
        for item in outside[:3]:
            self.win.set_status("  仍在包外：%s/%s -> %s"
                                % (item.get("node"), item.get("parm"),
                                   item.get("path")))
        for item in missing[:3]:
            self.win.set_status("  包里找不到：%s/%s -> %s"
                                % (item.get("node"), item.get("parm"),
                                   item.get("path")))
        for item in hda_missing[:3]:
            self.win.set_status("  HDA 不在：%s" % item.get("path"))

    def _fail(self, where, exc):
        self.win.set_status("%s失败：%s" % (where, exc))
        self.win.set_progress(0, 1)

    # ------------------------------------------------------------ 工程信息
    def _refresh_hip(self):
        try:
            hou = scan_mod.require_hou()
        except Exception:                                  # noqa: BLE001
            return
        try:
            info = scan_mod.hip_info()
        except Exception as exc:                           # noqa: BLE001
            self.win.set_status("读工程信息失败：%s" % exc)
            return
        self.win.set_hip_info(path=info["path"], size=info["size"],
                              mtime=info["mtime"], modified=info["modified"],
                              version=info["version"])
        if not info["path"] or not os.path.isfile(info["path"]):
            self.win.set_status("工程还没保存过 —— 建议先保存，再扫描打包")

    def pick_hip(self):
        from .qt import QtWidgets
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self.win, "选择 Houdini 工程", "",
            "Houdini 工程 (*.hip *.hiplc *.hipnc);;所有文件 (*.*)")
        if not path:
            return
        try:
            st = os.stat(path)
            self.win.set_hip_info(
                path=path, size=st.st_size,
                mtime=time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime)),
                modified=False)
        except Exception as exc:                           # noqa: BLE001
            self.win.set_status("读不到这个工程：%s" % exc)

    def pick_output_dir(self):
        from .qt import QtWidgets
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self.win, "打包结果放哪里")
        if path:
            self.win.output_dir_edit.setText(path)

    # ------------------------------------------------------------ 扫描
    def do_scan(self):
        if self._busy:
            return
        self._busy = True
        try:
            self.win.set_status("正在扫描工程…")
            self._pump()
            result = scan_mod.scan_project()
            self._scan = result
            self.win.set_dependencies(result.files)
            stats = result.stats
            msg = ("扫完：%d 个文件 · 缺失 %d · 序列 %d 段 · 用时 %.2fs"
                   % (stats["refs"], stats["missing"], stats["sequences"],
                      stats["seconds"]))
            if stats.get("locked_nodes"):
                msg += "　·　%d 个灰节点（HDA 内部）的引用已归到外层节点" \
                       % stats["locked_nodes"]
            folded_rows, folded_files = 0, 0
            try:
                folded_rows, folded_files = self.win.folded_stats()
            except Exception:                              # noqa: BLE001
                pass
            if stats.get("hda_only_on_disk"):
                msg += "　·　%d 个 HDA 内部引用的缓存照常列出（磁盘上有，可勾选打包）" \
                       % stats["hda_only_on_disk"]
            if folded_rows:
                msg += "　·　折叠 %d 行（只被 HDA 内部引用、磁盘上也没有）" % folded_rows
            if stats.get("hda_only_outside"):
                msg += "　⚠ 其中 %d 个在工程外，HDA 内部路径改不了" \
                       % stats["hda_only_outside"]
            self.win.set_status(msg)
        except Exception as exc:                           # noqa: BLE001
            self.win.set_status("扫描失败：%s" % exc)
            traceback.print_exc()
        finally:
            self._busy = False

    # ------------------------------------------------------------ 双击跳节点
    def on_dependency_activated(self, asset, refs):
        """清单里双击一项素材：一处引用直接跳，多处弹窗让人挑。"""
        refs = [r for r in (refs or []) if r]
        if not refs:
            return
        if len(refs) == 1:
            self.jump_to_node(refs[0], asset)
            return
        self._open_jump_dialog(asset, refs)

    def _open_jump_dialog(self, asset, refs):
        """多处引用：列出来，双击哪个跳哪个。"""
        from .ui import NodeJumpDialog

        parms = self._parms_by_node(asset)
        # HDA 不是靠某个参数引用的（是节点类型本身的定义），参数列换成说明
        otl_note = ""
        try:
            if classify.is_otl(asset):
                otl_note = "HDA 定义（这个节点就是它造出来的）"
        except Exception:                                  # noqa: BLE001
            pass

        nodes = []
        for path in refs:
            info = navigate.describe(path)
            got = sorted(parms.get(path) or ())
            info["parms"] = got if got else ([otl_note] if otl_note else [])
            nodes.append(info)

        alive = sum(1 for n in nodes if n["exists"])
        dlg = NodeJumpDialog(self.win, asset)
        dlg.set_nodes(nodes)
        dlg.nodeActivated.connect(self._on_jump_picked)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        self._jump_dialog = dlg          # 拿着，不然出了这个函数就被回收了

        name = os.path.basename(asset or "")
        self.win.set_status(
            "%s 被 %d 个节点引用%s，双击列表里的节点跳过去"
            % (name, len(nodes),
               "" if alive == len(nodes) else "（其中 %d 个已经删了）"
               % (len(nodes) - alive)))

    def _on_jump_picked(self, node_path):
        self.jump_to_node(str(node_path))

    def jump_to_node(self, node_path, asset=""):
        """在网络编辑器里选中并居中某个节点。"""
        try:
            result = navigate.jump_to_node(node_path)
        except Exception as exc:                           # noqa: BLE001
            self.win.set_status("跳节点失败：%s" % exc)
            return
        self.win.set_status(result.get("message") or "")

    def _parms_by_node(self, asset):
        """这份素材分别在哪些节点的哪些参数上被引用（序列按序列骨架匹配）。"""
        out = {}
        if not self._scan or not asset:
            return out
        try:
            key = classify.seq_key(asset)
        except Exception:                                  # noqa: BLE001
            key = None
        target = os.path.normcase(os.path.normpath(asset))
        for ref in self._scan.parm_refs or []:
            node = ref.get("node")
            if not node:
                continue
            path = ref.get("path") or ""
            if key is not None:
                try:
                    same_seq = classify.seq_key(path) == key
                except Exception:                          # noqa: BLE001
                    same_seq = False
                same_one = (os.path.normcase(os.path.normpath(path)) == target)
                if not (same_seq or same_one):
                    continue
            out.setdefault(node, set()).add(ref.get("parm") or "")
        return out

    # ------------------------------------------------------------ 打包
    def do_pack(self, options):
        if self._busy:
            return
        self._busy = True
        started = time.time()
        ok = False
        try:
            self.win.set_busy(True)
            self._open_progress()
            ok = self._do_pack_inner(options, started)
        except Exception as exc:                           # noqa: BLE001
            self._fail("打包", exc)
            traceback.print_exc()
        finally:
            try:
                if ok and self._dlg is not None:
                    self._dlg.finish("打包完成")
            except Exception:                              # noqa: BLE001
                pass
            self._close_progress()
            self.win.set_busy(False)
            self._busy = False

    # ------------------------------------------------------------ 进度框
    def _open_progress(self):
        """开一个**非模态**进度框（模态会把 Houdini 一起锁死）。"""
        from .ui import PackProgressDialog

        dlg = PackProgressDialog(self.win)
        self._dlg = dlg
        dlg.show()
        dlg.raise_()
        self._pump()
        return dlg

    def _close_progress(self):
        dlg = self._dlg
        self._dlg = None
        if dlg is None:
            return
        try:
            dlg.canceled.disconnect()
        except Exception:                                  # noqa: BLE001
            pass
        try:
            dlg.close()
        except Exception:                                  # noqa: BLE001
            pass
        self._pump()

    def _tick(self, phase, percent, detail=None):
        """更新进度框（阶段 / 百分比 / 当前文件），顺手让界面喘口气。"""
        dlg = self._dlg
        self.win.set_progress(int(percent or 0), 100)
        if dlg is None:
            self._pump()
            return
        try:
            dlg.set_phase(phase)
            dlg.set_percent(percent)
            if detail is not None:
                dlg.set_detail(detail)
        except Exception:                                  # noqa: BLE001
            pass
        self._pump()

    def _canceled(self):
        dlg = self._dlg
        if dlg is None:
            return False
        try:
            return dlg.is_canceled()
        except Exception:                                  # noqa: BLE001
            return False

    def _do_pack_inner(self, options, started):
        hip_path = (options.get("hip_path") or "").strip()
        output_dir = (options.get("output_dir") or "").strip()
        if not hip_path or not os.path.isfile(hip_path):
            self.win.set_status("先选一个已经保存过的工程文件")
            return False
        if not output_dir:
            self.win.set_status("先选输出目录")
            return False

        # 1) 有未保存的修改，先问一句
        try:
            import hou
            if hou.hipFile.hasUnsavedChanges():
                answer = hou.ui.displayMessage(
                    "当前工程有没保存的修改，打包会用**磁盘上已保存的版本**。",
                    buttons=("先保存再打包", "用已保存的版本", "取消"),
                    default_choice=0, close_choice=2,
                    title="工程保存工具")
                if answer == 0:
                    hou.hipFile.save()
                elif answer == 2:
                    self.win.set_status("已取消")
                    return False
        except Exception:                                  # noqa: BLE001
            pass

        # 2) 没扫过就先扫一遍
        if self._scan is None:
            self._tick("先扫描一遍工程…", 2, "这步一般几秒钟")
            self.win.set_status("先扫描一遍工程…")
            self._scan = scan_mod.scan_project()
            self.win.set_dependencies(self._scan.files)

        selected = options.get("files") or []
        if not selected:
            self.win.set_status("清单里一个都没勾，没什么可打包的")
            return False

        # 3) 规划
        self._tick("算包内结构…", 4, "")
        self.win.set_status("算包内结构…")
        pack = plan_mod.make_plan(selected, options, hip_path)

        # 4) 建目录 + 复制工程文件
        transfer.ensure_dir(pack.pack_dir)
        transfer.ensure_dir(pack.assets_dir)
        if not transfer.copy_hip(pack.hip_src, pack.hip_dst):
            self.win.set_status("工程文件复制失败，停在原地")
            return False

        # 5) 复制素材（按字节刷进度，大文件也不会「定住」）
        self._tick("复制素材…", 5, "%d 个文件 · %s" % (
            pack.file_count, plan_mod._human(pack.total_bytes)))
        self.win.set_status("开始复制 %d 个文件…" % pack.file_count)
        base_pct, span = 5.0, 65.0

        def _on_file(done, total, path):
            if path:
                self._tick("复制素材…",
                           base_pct + span * (float(done) / max(total, 1)),
                           "%d/%d　%s" % (min(done + 1, total), total,
                                          os.path.basename(path)))

        def _on_bytes(done, total):
            if not total:
                return
            self._tick("复制素材…",
                       base_pct + span * min(1.0, float(done) / total),
                       "%s / %s" % (plan_mod._human(done),
                                    plan_mod._human(total)))

        report = transfer.copy_all(pack.tasks, on_progress=_on_file,
                                   on_bytes=_on_bytes,
                                   cancel=lambda: self._canceled())
        self.win.set_status(
            "复制完：成功 %d · 跳过（找不到）%d · 失败 %d"
            % (report.copied, report.skipped, len(report.failed)))
        if report.failed:
            for src, _dst, err in report.failed[:3]:
                self.win.set_status("  失败：%s（%s）" % (os.path.basename(src), err))
        if getattr(report, "canceled", False):
            self.win.set_status(
                "已取消 —— 已经复制的文件留在 %s（这份包不完整）" % pack.pack_dir)
            return False

        # 6) 改包里那份副本（子进程做，不动当前会话）：
        #    ① 把参数里的路径改写成 $HIP/...   ② 加一段「打开时自动加载 otls/」的 python
        rewrite_result = None
        rewrite_skipped = []
        need_rewrite = bool(options.get("rewrite_paths"))
        need_otl = bool(options.get("otl_loader")) and pack.otl_count > 0
        if need_rewrite or need_otl:
            todo = []
            if need_rewrite:
                todo.append("改写路径")
            if need_otl:
                todo.append("加 %d 个 HDA/OTL 的自动加载脚本" % pack.otl_count)
            self.win.set_status("改包内工程（%s）… 开 hython 子进程"
                                % "、".join(todo))
            # 这一步是子进程在跑（开工程 + 保存），几十秒很正常，
            # 期间进度条走来回滚、界面照样能点。
            self._rewrite_t0 = time.time()
            self._tick("改包内工程（%s）…" % "、".join(todo), None,
                       "后台开 hython 处理，界面不会卡住")
            # 只改「真的搬进包了」的那些：复制失败 / 磁盘上没有的文件，
            # 改了只会指向包里不存在的位置，比不改更糟。
            rewrite_map, rewrite_skipped = {}, []
            if need_rewrite:
                available = set()
                for task in pack.tasks:
                    if os.path.isfile(task["dst"]):
                        available.add(task["src"])
                        available.add(os.path.normcase(task["src"]))
                rewrite_map, rewrite_skipped = rewrite.build_rewrite_report(
                    self._scan.parm_refs, pack, allow=available)
            rewrite_result = rewrite.launch(
                pack.hip_dst, rewrite_map, otl_loader=need_otl,
                on_poll=self._on_rewrite_poll, cancel=lambda: self._canceled())
            if rewrite_result.get("canceled"):
                self.win.set_status(
                    "已取消 —— 包里的工程还没改完，输出目录：%s" % pack.pack_dir)
                return False
            if self._dlg is not None:
                try:
                    self._dlg.set_busy(False)
                    self._dlg.set_percent(88)
                except Exception:                          # noqa: BLE001
                    pass
            if rewrite_result.get("ok"):
                bits = []
                if need_rewrite:
                    bits.append("改了 %d 个参数"
                                % len(rewrite_result.get("changed") or []))
                    if rewrite_skipped:
                        bits.append("%d 个引用没动（对应文件没进包）"
                                    % len(rewrite_skipped))
                if rewrite_result.get("otl_loader_added"):
                    bits.append("已写入自动加载脚本")
                elif need_otl:
                    bits.append("自动加载脚本已存在，没重复写")
                for warn in (rewrite_result.get("load_warnings") or []):
                    self.win.set_status("  提示：%s" % warn)
                self.win.set_status("包内工程处理完成：%s"
                                    % ("；".join(bits) or "无需改动"))
                self._report_verify(rewrite_result.get("verify"))
            else:
                self.win.set_status(
                    "包内工程处理没成功：%s（包里的工程还是原样）"
                    % (rewrite_result.get("error") or "未知原因"))

        # 7) manifest + README
        self._tick("写说明文件（manifest.json / README.txt）…", 90, "")
        info = None
        try:
            info = scan_mod.hip_info()
        except Exception:                                  # noqa: BLE001
            pass
        extra = {
            "copy_report": {
                "copied": report.copied,
                "skipped": report.skipped,
                "failed": [{"source": s, "error": e} for s, _d, e in report.failed],
            },
            "rewrite": self._rewrite_extra(options, rewrite_result,
                                           rewrite_skipped),
            "otls": {
                "files": pack.otl_count,
                "auto_load": bool(options.get("otl_loader")) and pack.otl_count > 0,
                "script_added": bool((rewrite_result or {}).get("otl_loader_added")),
            },
            "seconds": round(time.time() - started, 2),
        }
        manifest.write_manifest(pack, os.path.join(pack.pack_dir, "manifest.json"),
                                info, options, extra)
        manifest.write_readme(pack, os.path.join(pack.pack_dir, "README.txt"),
                              info, options)

        # 8) zip
        zip_path = ""
        if options.get("zip"):
            self._tick("压缩成 zip…", 92, "压缩比较慢，界面可以正常用")
            self.win.set_status("压缩成 zip…")
            zip_path = pack.pack_dir + ".zip"

            def _on_zip(done, total, path):
                self._tick("压缩成 zip…", 92 + 8.0 * (float(done) / max(total, 1)),
                           "%d/%d" % (done, total))

            try:
                transfer.make_zip(pack.pack_dir, zip_path, on_progress=_on_zip)
                transfer.remove_dir(pack.pack_dir)
            except Exception as exc:                       # noqa: BLE001
                zip_path = ""
                self.win.set_status("压缩失败：%s（包目录还在）" % exc)

        # 9) 收尾
        self.win.set_progress(100, 100)
        target = zip_path or pack.pack_dir
        seconds = time.time() - started
        self.win.set_status(
            "打包完成：%d 个文件 · %s · 用时 %.1fs -> %s"
            % (pack.file_count, plan_mod._human(pack.total_bytes),
               seconds, target))
        # 弹个框告诉用户完了（以前只有状态栏一行字，很容易没看见）
        self._show_finished(pack, report, rewrite_result, options,
                            target, seconds, opened=options.get("open_after"))
        return True

    # ------------------------------------------------------------ 收尾提示
    def _show_finished(self, pack, report, rewrite_result, options, target,
                       seconds, opened=False):
        """打包完成弹框：结果摘要 + 「打开输出目录」按钮。"""
        from .qt import QtWidgets

        lines = [
            "输出：%s" % target,
            "文件：%d 个 · %s" % (pack.file_count,
                                  plan_mod._human(pack.total_bytes)),
            "耗时：%.1f 秒" % seconds,
        ]
        if report is not None:
            tail = []
            if report.skipped:
                tail.append("跳过（磁盘上找不到）%d" % report.skipped)
            if report.failed:
                tail.append("复制失败 %d" % len(report.failed))
            if tail:
                lines.append("复制：成功 %d · %s" % (report.copied,
                                                    " · ".join(tail)))
        rewrite_result = rewrite_result or {}
        if options.get("rewrite_paths"):
            if rewrite_result.get("ok"):
                lines.append("路径改写：改了 %d 个参数 → 都改成 $HIP/… 相对写法"
                             % len(rewrite_result.get("changed") or []))
            elif rewrite_result:
                lines.append("路径改写：没成功（%s）"
                             % (rewrite_result.get("error") or "未知原因"))
        verify = rewrite_result.get("verify") or {}
        if verify and not verify.get("error"):
            lines.append("复查：包内 %d · 还在包外 %d · 指向空处 %d"
                         % (verify.get("inside") or 0,
                            len(verify.get("outside") or []),
                            len(verify.get("missing") or [])))
        if options.get("zip"):
            lines.append("已压缩成 zip（中间目录已删除）")

        box = QtWidgets.QMessageBox(self.win)
        box.setWindowTitle("打包完成")
        box.setIcon(enum_of(QtWidgets.QMessageBox, "Information"))
        box.setText("打包完成")
        box.setInformativeText("\n".join(lines))
        btn_open = box.addButton("打开输出目录",
                                 enum_of(QtWidgets.QMessageBox, "AcceptRole"))
        btn_close = box.addButton("关闭",
                                  enum_of(QtWidgets.QMessageBox, "RejectRole"))
        box.setDefaultButton(btn_open if not opened else btn_close)
        box.setEscapeButton(btn_close)
        try:
            box.exec_()
            clicked = box.clickedButton()
        except Exception:                                  # noqa: BLE001
            clicked = None
        if opened or clicked is btn_open:
            transfer.open_in_explorer(target if os.path.isdir(target)
                                      else os.path.dirname(target))


def attach(win):
    """给一个现成的界面接上功能，返回 controller。"""
    return HipPackerController(win)


__all__ = ["HipPackerController", "attach"]
