# -*- coding: utf-8 -*-
"""最小环境探测，只依赖标准库。

单独拆出来是为了：**在 import PySide2 之前**把 Houdini 的 bin 加进 DLL 搜索路径。
Windows 上 PySide2 的 .pyd 链接的是 HFS/bin 下的 Qt5*.dll，路径没加好就会
"DLL load failed"，而这个动作必须发生在 PySide2 被导入之前。
"""

import os
import sys


def find_hfs():
    """找 Houdini 安装根目录（HFS）。"""
    hfs = os.environ.get("HFS")
    if hfs and os.path.isdir(os.path.join(hfs, "bin")):
        return os.path.abspath(hfs)
    exe_dir = os.path.dirname(os.path.abspath(sys.executable))
    # python.exe 在 HFS/python311/ 下；hython.exe 在 HFS/bin/ 下
    for candidate in (os.path.dirname(exe_dir), exe_dir):
        if candidate and os.path.isdir(os.path.join(candidate, "bin")):
            return candidate
    return None


def ensure_dll_dir(hfs=None):
    """把 <HFS>/bin 加进 DLL 搜索路径，返回 HFS。非 Windows 返回 None。"""
    if not sys.platform.startswith("win"):
        return None
    hfs = hfs or find_hfs()
    if not hfs:
        return None
    bin_dir = os.path.join(hfs, "bin")
    add_dll_dir = getattr(os, "add_dll_directory", None)
    if add_dll_dir is None:
        return hfs
    try:
        add_dll_dir(bin_dir)
    except Exception:                             # noqa: BLE001
        return None
    return hfs
