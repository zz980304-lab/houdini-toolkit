# -*- coding: utf-8 -*-
"""扫描：把工程里所有「文件引用」找出来。

只负责**读**，不改动工程、不改动节点、不写任何文件。
在 Houdini 里这么用：

    from hip_packer import scan
    result = scan.scan_project()
    for f in result.files:
        print(f["path"], f["size"], f["status"], f["refs"])

    result.parm_refs   # 参数级别的引用，改写路径时用（node / parm / 原文 / 展开值）

扫描思路
--------
1. 遍历工程里所有节点（含 locked HDA 内部的子节点），只看**文件引用类型的参数**
   （`hou.stringParmType.FileReference` / `FileReferenceList`）。
2. 参数值先取原文 `unexpandedString()`（里面有 $HIP / $OS / $F4 这些），
   再用 `parm.eval()` 求值 —— 这样 $OS（节点名）之类的上下文变量才会正确展开。
3. 拿到实际路径后去磁盘上查：**带帧号的会整段序列一起捞出来**
   （`cache.1001.bgeo.sc` -> 列出 1001~1240 全部帧），顺便统计大小和缺帧。
4. 同一个文件被多个节点引用时合并，refs 是一份列表（这就是「引用节点」那一列）。
"""

import os
import re
import time

try:                                   # 正常当包用
    from . import classify
except (ImportError, ValueError):      # 被 hython 当脚本直接跑时没有包上下文
    import importlib.util

    _spec = importlib.util.spec_from_file_location(
        "hip_packer_classify",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "classify.py"))
    classify = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(classify)

try:
    import hou
except ImportError:                                       # 只在 Houdini 里有
    hou = None

#: 这些前缀不是磁盘文件（指向 Houdini 内部），直接跳过
_NON_FILE_PREFIXES = ("op:", "opdef:", "oplib:", "temp:", "chop:",
                      "sop:", "obj:", "shop:", "vop:", "cop:", "ptwrap:")

_F_RE = re.compile(r"\$F\d*[a-z]?")
#: 展开变量时用它临时顶替 $F（Houdini 不认识的变量会原样留下，正好保住 $F）
_FRAME_TOKEN = "$__HP_FRAME__"

#: 这些是 Houdini 自己机制产生的路径（PDG 临时目录、USD gallery 等），不是素材
_NOISE_TOKENS = ("pdgtemp", "rendergallery", ".checkpoint.json",
                 "taskgraph", "/tasks/", "hou_crash")

#: 「开关没打开就别扫」的参数：{参数名: (控制它的开关参数…)}。
#: 例：dopnet（SOP Solver 里那个 DOP 网络）的 `explicitcachename` 默认值是
#: `$HIP/checkpoint/cache.$HIPNAME.$OS.$SF.sim`，只要没勾「Cache to Disk」
#: 也没勾「Explicit Cache」，这个文件根本不会生成 —— 扫出来就是一条永远
#: 缺失的假依赖（用户实测就撞上这个：`cache_d_$SF.sim`）。
_GATED_PARMS = {
    "explicitcachename": ("cachetodisk", "explicitcache"),
}


def gated_off(node, parm_name):
    """这个参数是不是「开关关着、值只是占位」？是的话不该算依赖。

    一个开关参数都没有（不是 dopnet 那类节点）时返回 False —— 不认识就别乱跳。
    """
    gates = _GATED_PARMS.get(parm_name)
    if not gates:
        return False
    found = False
    for gate in gates:
        prm = node.parm(gate)
        if prm is None:
            continue
        found = True
        try:
            if prm.eval():
                return False                  # 有一个开着 -> 这个缓存是真在用的
        except Exception:                     # noqa: BLE001
            return False
    return found


class ScanResult(object):
    """一次扫描的结果。"""

    def __init__(self):
        self.hip_path = ""
        self.files = []          # 交给界面的依赖列表
        self.parm_refs = []      # 参数级引用，改写路径时用
        self.stats = {
            "nodes": 0, "parms": 0, "refs": 0,
            "missing": 0, "sequences": 0, "files_on_disk": 0,
            "seconds": 0.0,
        }

    def __repr__(self):
        return "<ScanResult %d 文件 / %d 参数引用 / 缺失 %d>" % (
            len(self.files), len(self.parm_refs), self.stats["missing"])


def require_hou():
    if hou is None:
        raise RuntimeError("scan 模块只能在 Houdini 里用：import hou 失败")
    return hou


# ---------------------------------------------------------------- 节点遍历
def iter_nodes(root=None):
    """遍历工程里所有节点，包括 locked HDA 内部的子节点。"""
    hou = require_hou()
    root = root or hou.node("/")
    if root is None:
        return
    queue = [root]
    seen = set()
    while queue:
        node = queue.pop(0)
        try:
            path = node.path()
        except Exception:                                  # noqa: BLE001
            continue
        if path in seen:
            continue
        seen.add(path)
        yield node
        try:
            children = list(node.children())
        except Exception:                                  # noqa: BLE001
            continue
        queue.extend(children)


def inside_locked_hda(node):
    """这个节点是不是封在**锁定的 HDA** 里（网络里显示成灰的、改不动的那些）。

    用户明确要求：这类节点上的文件引用不用列出来。原因有三：
      1. 它们是 HDA 内部实现，不是场景作者在用的素材；
      2. 那些参数改不动，改写路径必然失败（`parm.set()` 直接抛异常）；
      3. 同一个缓存常被实例上的参数（如 `Output_File`）再引用一次，
         列出来就是一堆重复行。
    """
    try:
        return bool(node.isInsideLockedHDA())
    except Exception:                                      # noqa: BLE001
        return False


def _file_string_types():
    """Houdini 各版本给的枚举名字不一样（20.5 就没有 FileReferenceList），
    所以这里按需取，取不到的忽略。"""
    hou = require_hou()
    names = ("FileReference", "FileReferenceList",
             "FileReferenceDir", "FileReferenceGeometry")
    found = []
    for name in names:
        value = getattr(hou.stringParmType, name, None)
        if value is not None and value not in found:
            found.append(value)
    return found


def file_parms(node):
    """取出节点上所有「文件引用」参数，返回 (parm, 是不是多值)。"""
    hou = require_hou()
    wanted = _file_string_types()
    list_type = getattr(hou.stringParmType, "FileReferenceList", None)
    for parm in node.parms():
        try:
            tpl = parm.parmTemplate()
        except Exception:                                  # noqa: BLE001
            continue
        if tpl.type() != hou.parmTemplateType.String:
            continue
        try:
            stype = tpl.stringType()
        except Exception:                                  # noqa: BLE001
            continue
        if stype not in wanted:
            continue
        yield parm, (list_type is not None and stype == list_type)


# ---------------------------------------------------------------- 路径处理
def raw_value(parm):
    try:
        return parm.unexpandedString() or ""
    except Exception:                                      # noqa: BLE001
        return ""


def expand_value(parm, raw):
    """把参数值展开成实际路径，返回 (路径, 是不是带 $F 的序列)。

    两个关键点：
    1. 临时把 pwd 切到参数所属节点，$OS / $HIPNAME 这类上下文变量才展开得对；
    2. **按 $F 把字符串切成几段分别展开，再把 $F4 原样拼回去** —— 直接
       hou.expandString 的话 $F 会变成当前帧号（0001），磁盘上没这一帧，
       就会多出一条假的「缺失」。
    """
    if not raw:
        return "", False
    if "$" not in raw and "`" not in raw:                  # 纯路径，不用展开
        return raw.strip(), False

    hou = require_hou()
    node = parm.node()
    saved = None
    try:
        saved = hou.pwd()
    except Exception:                                      # noqa: BLE001
        pass

    try:
        if node is not None:
            hou.cd(node.path())
        if _F_RE.search(raw) is None:
            return hou.expandString(raw).strip(), False
        parts = _F_RE.split(raw)
        frames = _F_RE.findall(raw)
        pieces = []
        for i, part in enumerate(parts):
            pieces.append(hou.expandString(part) if part else "")
            if i < len(frames):
                pieces.append(frames[i])                   # $F4 原样保留
        return "".join(pieces).strip(), True
    except Exception:                                      # noqa: BLE001
        try:                                               # 兜底：让参数自己求值
            value = parm.eval()
            if isinstance(value, (list, tuple)):
                value = " ".join(str(v) for v in value)
            return str(value).strip(), False
        except Exception:                                  # noqa: BLE001
            return raw.strip(), False
    finally:
        if saved is not None:
            try:
                hou.cd(saved)
            except Exception:                              # noqa: BLE001
                pass


def split_multi(value, is_list):
    """一个参数里可能写了多个路径（FileReferenceList 用空格 / 分号分隔）。

    普通 FileReference 按理只写一个，但实际工程里手滑写成
    `hero.abc diffuse.png` 的情况也有。不拆的话整串会被当成一个不存在的
    路径，两个文件一起漏掉；所以只要切开后**每段都像文件**（都带扩展名），
    就按多段处理。带空格的单个路径（C:/my docs/a.abc）切完有一段没扩展名，
    不会被误拆。
    """
    if not value:
        return []
    parts = [p for p in re.split(r"[;\s]+", value.strip()) if p]
    if is_list:
        return parts
    if len(parts) > 1 and all(is_file_like(p) and classify.norm_ext(p)
                              for p in parts):
        return parts
    return [value]


def is_houdini_builtin(path):
    """这个路径在 `$HFS` 下面吗 —— 是的话属于 Houdini 自带，不该打进包里。

    典型受害者：`file` 节点的默认值 `$HFS/houdini/geo/defgeo.bgeo`。
    它确实存在（所以「没改过 + 不存在」那条噪音规则抓不到它），
    但换台机器装了 Houdini 就一定有，打进包里纯属占地方。
    """
    if not path:
        return False
    try:
        hfs = (hou.getenv("HFS") or "").replace("\\", "/").rstrip("/")
    except Exception:                                      # noqa: BLE001
        return False
    if not hfs:
        return False
    low = os.path.normpath(path).replace("\\", "/").lower()
    return low == hfs.lower() or low.startswith(hfs.lower() + "/")


def is_file_like(path):
    if not path:
        return False
    low = path.lower()
    if low.startswith(_NON_FILE_PREFIXES):
        return False
    if len(path) < 3:
        return False
    for token in _NOISE_TOKENS:                            # Houdini 自己的机制，不是素材
        if token in low:
            return False
    return True


def absolutize(path):
    """相对路径补成绝对的（相对当前工作目录 / $HIP 由调用方保证已展开）。"""
    if not path:
        return path
    if os.path.isabs(path):
        return os.path.normpath(path)
    try:
        cwd = hou.getenv("HIP") or os.getcwd()
    except Exception:                                      # noqa: BLE001
        cwd = os.getcwd()
    return os.path.normpath(os.path.join(cwd, path))


# ---------------------------------------------------------------- 磁盘查询
def _frame_pattern(name):
    """把文件名变成匹配整段序列的正则；不是序列就返回 None。"""
    if _F_RE.search(name):
        # 按 $F / $F4 / $SF 切开，每段单独 escape，中间用「帧号」连起来
        # （$SF 展开出来是小数 13.0，所以允许带小数点）
        parts = _F_RE.split(name)
        pattern = r"\d+(?:\.\d+)?".join(re.escape(p) for p in parts)
        return re.compile("^" + pattern + "$")
    m = classify._NUM_RE.match(name)
    if m:
        head = re.escape(m.group("base") + m.group("sep"))
        tail = re.escape(m.group("ext"))
        return re.compile("^" + head + r"(?P<num>\d+)" + tail + "$")
    return None


def on_disk(path):
    """查磁盘：返回 (实际存在的文件列表, 是否按序列查的)。

    带帧号的参数会把整段序列都捞出来，比如 cache.1001.bgeo.sc -> 1001~1240。
    """
    directory, name = os.path.split(path)
    if not directory:
        return [], False
    directory = os.path.normpath(directory)
    pattern = _frame_pattern(name)
    if pattern is None:
        if os.path.isfile(path):
            return [path], False
        return [], False
    try:
        entries = os.listdir(directory)
    except Exception:                                      # noqa: BLE001
        return [], True
    hits = []
    for entry in entries:
        m = pattern.match(entry)
        if m and os.path.isfile(os.path.join(directory, entry)):
            hits.append(os.path.join(directory, entry))
    # 按帧号排序
    def key(p):
        name = os.path.basename(p)
        num = 0
        m = pattern.match(name)
        if m:
            try:
                num = int(m.group("num"))
            except Exception:                              # noqa: BLE001
                digits = re.findall(r"\d+", name)
                num = int(digits[0]) if digits else 0
        return (num, name)
    return sorted(hits, key=key), True


# ---------------------------------------------------------------- 主流程
def scan_project(root=None, on_progress=None):
    """扫一遍工程，返回 ScanResult。"""
    hou = require_hou()
    started = time.time()
    result = ScanResult()
    result.hip_path = hou.hipFile.path()

    by_path = {}          # 实际路径 -> 条目
    parm_refs = []
    node_count = 0
    locked_nodes = 0
    parm_count = 0

    for node in iter_nodes(root):
        node_count += 1
        grey = inside_locked_hda(node)
        if grey:
            locked_nodes += 1
        try:
            node_path = node.path()
        except Exception:                                  # noqa: BLE001
            continue
        # 灰节点（在锁定 HDA 里）对外显示成它外面那层实例：
        # 清单里不出现 `/…/Cache_poly_Fast1/render` 这种内部路径。
        ref_path = node_path
        if grey:
            owner = visible_owner(node)
            if owner is not None:
                try:
                    ref_path = owner.path()
                except Exception:                          # noqa: BLE001
                    ref_path = node_path
        for parm, is_list in file_parms(node):
            if gated_off(node, parm.name()):               # 开关关着，值只是占位
                continue
            parm_count += 1
            raw = raw_value(parm)
            if not raw:
                continue
            value, has_f = expand_value(parm, raw)
            if not value:
                continue
            segments = split_multi(value, is_list)
            for index, one in enumerate(segments):
                if not is_file_like(one):
                    continue
                if is_houdini_builtin(one):
                    continue                               # Houdini 自带的，不打包
                path = absolutize(one)
                if not path or os.path.isdir(path):
                    continue                               # 目录型引用先不收

                # Houdini 自带的默认参数（比如 OBJ 上那个 $OS.$F.vdb）也会命中，
                # 但那不是真的引用。规则：**没被改过 + 磁盘上也没有** -> 跳过。
                try:
                    at_default = bool(parm.isAtDefault())
                except Exception:                          # noqa: BLE001
                    at_default = False
                if at_default and not os.path.isfile(path):
                    if not on_disk(path)[0]:
                        continue

                is_seq = has_f or bool(_F_RE.search(one))
                group, ext = classify.classify(path, forced_sequence=is_seq)

                # 灰节点的参数**不记进 parm_refs**：锁定 HDA 里的 parm.set() 会直接抛
                # 异常，记了也改不动，不如一开始就别让 rewrite 看到它。
                if grey:
                    pass
                else:
                    parm_refs.append({
                        "node": node_path,
                        "parm": parm.name(),
                        "raw": raw,
                        # value 是这一个（第 index 个）路径，full 是整个参数展开后的值。
                        # 一个参数里写了多个路径时，改写得按段替换再拼回去（见 rewrite）。
                        "value": one,
                        "full": value,
                        "index": index,
                        "segments": len(segments),
                        "path": path,
                        "is_sequence": is_seq,
                    })

                entry = by_path.get(path)
                if entry is None:
                    try:
                        size = os.path.getsize(path) if os.path.isfile(path) else 0
                    except Exception:                      # noqa: BLE001
                        size = 0
                    entry = {
                        "path": path,
                        "size": size,
                        "refs": [],
                        "status": "找到" if os.path.isfile(path) else "缺失",
                        "category": group,
                        "ext": ext,
                        "sequence": is_seq,
                        "visible_refs": 0,                 # 外面（非灰）节点的引用次数
                        "hda_refs": 0,                     # 灰节点（HDA 内部）的引用次数
                    }
                    by_path[path] = entry
                if grey:
                    entry["hda_refs"] = entry.get("hda_refs", 0) + 1
                else:
                    entry["visible_refs"] = entry.get("visible_refs", 0) + 1
                if ref_path not in entry["refs"]:
                    entry["refs"].append(ref_path)

    # 先补一类漏的：参数值写的是**一个具体帧号**（不是 `$F`）时，
    # 磁盘上多半是一整段序列 —— 典型来源是 `\`chs("../sopoutput")\`` 这种
    # 「把文件名算出来」的写法（Houdini 自带 File Cache / Pyro 的缓存就走这条）。
    # 不展开的话打包只会带走那一帧，119 帧缓存全丢。
    # 做法：先把它换成带 `$F` 的占位（`…_v1.$F4.bgeo.sc`），交给下面统一展开。
    for path, entry in list(by_path.items()):
        if entry["sequence"] or _F_RE.search(os.path.basename(path)):
            continue
        if not classify._NUM_RE.match(os.path.basename(path)):
            continue                                  # 名字里没有帧号，单帧就是单帧
        files, _ = on_disk(path)
        if len(files) < 2:                            # 就它自己一个，别硬当序列
            continue
        pat = classify.seq_pattern(path)
        if not pat:
            continue
        num = classify._NUM_RE.match(os.path.basename(path))
        width = len(num.group("num")) if num else 4      # 位数照抄原来的（0072 -> $F4）
        placeholder = os.path.join(pat[0], pat[1].replace("$F", "$F%d" % width))
        del by_path[path]
        entry["path"] = placeholder
        entry["sequence"] = True
        by_path[placeholder] = entry

    # 序列：按 $F 模式把磁盘上整段帧捞出来，替换掉那个带 $F 的占位条目
    for placeholder, entry in list(by_path.items()):
        # `$F` / `$F4` / `$SF`（DOP 模拟帧）都算，别只认 `$F`
        if not entry["sequence"] or not _F_RE.search(placeholder):
            continue
        files, _ = on_disk(placeholder)
        if not files:
            entry["status"] = "缺失"                       # 一帧都没有
            continue
        del by_path[placeholder]
        result.stats["sequences"] += 1

        # 序列的「骨架」：这一整段帧共用它做分组 key。
        # ⚠ 不能交给界面靠文件名去猜 —— `Cache_poly_Fast1.9.bgeo.sc` 与
        # `Cache_poly_Fast1.10.bgeo.sc` 位数不同，猜出来是两段，清单里就会
        # 出现「×111」加一串单位数帧的碎行（2026-10-16 用户实测就是这个）。
        # 骨架直接来自参数里的 `$F` 写法，天然统一。
        pattern = classify.seq_pattern(placeholder)
        seq_key = (pattern[0] + "|" + pattern[1]) if pattern else placeholder
        seq_label = os.path.basename(placeholder)          # 用户自己写的（$F / $F4 原样）

        for f in files:
            try:
                size = os.path.getsize(f)
            except Exception:                              # noqa: BLE001
                size = 0
            sub = by_path.get(f)
            if sub is None:
                sub = {
                    "path": f,
                    "size": size,
                    "refs": list(entry["refs"]),
                    "status": "找到",
                    "category": entry["category"],
                    "ext": entry["ext"],
                    "sequence": True,
                    "seq_key": seq_key,
                    "seq_label": seq_label,
                    "visible_refs": entry.get("visible_refs", 0),
                    "hda_refs": entry.get("hda_refs", 0),
                }
                by_path[f] = sub
            else:
                sub["sequence"] = True
                sub.setdefault("seq_key", seq_key)
                sub.setdefault("seq_label", seq_label)
                sub["visible_refs"] = sub.get("visible_refs", 0) + \
                    entry.get("visible_refs", 0)
                sub["hda_refs"] = sub.get("hda_refs", 0) + entry.get("hda_refs", 0)
                for r in entry["refs"]:
                    if r not in sub["refs"]:
                        sub["refs"].append(r)

    # HDA / OTL：节点类型是从哪个文件来的（原生自带的会被 hda_sources 滤掉）
    hda = hda_sources(root)
    for path, refs in hda.items():
        entry = by_path.get(path)
        if entry is None:
            try:
                size = os.path.getsize(path) if os.path.isfile(path) else 0
            except Exception:                              # noqa: BLE001
                size = 0
            entry = {
                "path": path,
                "size": size,
                "refs": [],
                "status": "找到" if os.path.isfile(path) else "缺失",
                "category": classify.HDA,
                "ext": classify.norm_ext(path),
                "sequence": False,
            }
            by_path[path] = entry
        else:
            entry["category"] = classify.HDA             # 兜底：确保归到 HDA 类
        for ref in refs:
            if ref not in entry["refs"]:
                entry["refs"].append(ref)

    # ①「只被 HDA 内部（灰节点）引用」：有灰节点的引用，却没有外层可见节点的引用。
    # ② 只有 ① **且磁盘上根本没有**的才折叠（默认不显示）。
    #
    # 为什么 ② 还要加「不存在」这一条（2026-10-16 用户亲自纠正过一次）：
    # 光按 ① 折叠会把用户真正的数据一起折掉 —— File Cache / Pyro 的缓存
    # （Houdini 自带的 filecache HDA 里那个内部 rop 才是真正写缓存的地方）、
    # 以及用户自己 HDA 里那个 ROP 写出来的 `OS.bgeo.sc`，统统只被灰节点引用，
    # 但它们是真真切切落在磁盘上的缓存，必须列出来、必须能打包。
    # 磁盘上没有的那些（第三方 HDA 自带的 `pointlight.bgeo` 之类）才是纯噪音。
    for entry in by_path.values():
        entry["hda_only"] = bool(entry.get("hda_refs")) and \
            not entry.get("visible_refs")
        entry["folded"] = bool(entry["hda_only"] and entry.get("status") != "找到")

    result.files = sorted(by_path.values(),
                          key=lambda e: (e["category"], e["path"].lower()))
    result.parm_refs = parm_refs

    hda_only = [e for e in result.files if e.get("hda_only")]
    folded = [e for e in hda_only if e.get("folded")]

    # 只被 HDA 内部（灰节点）引用、又**在工程外**的文件：
    # 打包时会被搬到 assets/ 下，而 HDA 内部那个参数改不了（锁定），
    # 打开包时可能指空 —— 值得提醒一句。
    hip_dir = ""
    try:
        hip_dir = os.path.normpath(hou.getenv("HIP") or "")
    except Exception:                                      # noqa: BLE001
        hip_dir = ""
    risky = []
    for entry in result.files:
        if entry.get("hda_only") and hip_dir:
            if not _is_under(entry["path"], hip_dir):
                risky.append(entry["path"])

    result.stats.update({
        "nodes": node_count,
        "locked_nodes": locked_nodes,
        "parms": parm_count,
        "refs": len(by_path),
        "missing": sum(1 for e in result.files if e["status"] == "缺失"),
        "files_on_disk": sum(1 for e in result.files if e["status"] == "找到"),
        "hda_files": len(hda),
        "hda_only": len(hda_only),                 # 只被灰节点引用（不管存不存在）
        "hda_only_on_disk": sum(1 for e in hda_only if e["status"] == "找到"),
        "hda_only_paths": [e["path"] for e in hda_only][:8],
        "folded": len(folded),                     # 其中默认折叠的（磁盘上没有）
        "folded_paths": [e["path"] for e in folded][:8],
        "hda_only_outside": len(risky),
        "hda_only_outside_paths": risky[:5],
        "seconds": round(time.time() - started, 2),
    })
    if on_progress:
        on_progress(result.stats)
    return result


def visible_owner(node):
    """往上找第一个「不灰」的祖先 —— 灰节点（在锁定 HDA 里）对外要显示成它的实例。

    清单里给人看的引用节点路径用这个，这样 `…/axiom_solver1/volumeVisualize_density`
    会显示成 `/obj/geo1/axiom_solver1`（用户真正能双击跳过去的那个）。
    注意：**只影响显示**，HDA 文件本身的收集不受影响（文件还是得打包）。
    """
    cur = node
    seen = 0
    while cur is not None and inside_locked_hda(cur) and seen < 32:
        cur = cur.parent()
        seen += 1
    return cur


def _is_under(path, root):
    """path 在 root 目录下面吗（用来判断素材是不是在工程里）。"""
    if not path or not root:
        return False
    try:
        p = os.path.normcase(os.path.normpath(path))
        r = os.path.normcase(os.path.normpath(root)).rstrip("\\/")
        return p == r or p.startswith(r + os.sep)
    except Exception:                                      # noqa: BLE001
        return False


def hda_sources(root=None):
    """场景里用到的 HDA / OTL **文件**，返回 {文件路径: [用到它的节点路径...]}。

    节点类型来自哪个文件，问的是 `node.type().definition().libraryFilePath()`：
      * 定义存在 .hip 里的 -> 返回 "Embedded"，跳过（不用打包）
      * Houdini 自带的 -> 装在 $HFS 下面，跳过（换台机器也一定有）
      * 其它（自己攒的 otls、第三方插件包、用户目录 otls）-> 收进来

    这些文件会由 plan 放进包里的 otls/，再由那段「打开时自动加载」的脚本装回去。
    """
    hou = require_hou()
    hfs = ""
    try:
        hfs = (hou.getenv("HFS") or "").replace("\\", "/").rstrip("/").lower()
    except Exception:                                      # noqa: BLE001
        hfs = ""

    found = {}
    for node in iter_nodes(root):
        try:
            defn = node.type().definition()
        except Exception:                                  # noqa: BLE001
            continue
        if defn is None:
            continue
        try:
            lib = defn.libraryFilePath() or ""
        except Exception:                                  # noqa: BLE001
            continue
        if not lib or lib in ("Embedded", "Unknown"):
            continue
        path = os.path.normpath(lib)
        low = path.replace("\\", "/").lower()
        if hfs and low.startswith(hfs):                    # Houdini 自带的
            continue
        if not classify.is_otl(path):
            continue
        try:
            node_path = node.path()
        except Exception:                                  # noqa: BLE001
            continue
        # 灰节点显示成它外面那层实例（用户能看到的那个），不然清单里全是 HDA 内部路径
        owner = visible_owner(node)
        try:
            if owner is not None:
                node_path = owner.path()
        except Exception:                                  # noqa: BLE001
            pass
        refs = found.setdefault(path, [])
        if node_path not in refs:
            refs.append(node_path)
    return found


def hip_info():
    """当前工程文件的信息（大小 / 修改时间 / 有没有保存）。"""
    hou = require_hou()
    path = hou.hipFile.path()
    info = {
        "path": path,
        "size": 0,
        "mtime": "",
        "modified": bool(hou.hipFile.hasUnsavedChanges()),
        "version": "%d.%d.%d" % hou.applicationVersion()[:3],
    }
    if path and os.path.isfile(path):
        try:
            st = os.stat(path)
            info["size"] = st.st_size
            info["mtime"] = time.strftime("%Y-%m-%d %H:%M",
                                          time.localtime(st.st_mtime))
        except Exception:                                  # noqa: BLE001
            pass
    return info


__all__ = ["ScanResult", "scan_project", "hip_info", "iter_nodes",
           "file_parms", "on_disk", "hda_sources", "require_hou"]
