# -*- coding: utf-8 -*-
"""搬运：真正往磁盘上写东西的那一层（复制 / 压缩 / 删中间目录）。

不依赖 hou、不依赖 Qt，纯 IO，所以可以单独测试、也能被 hython 直接调。
进度靠回调往外报，界面层拿去刷进度条。
"""

import os
import shutil
import zipfile

#: 大文件分块复制的块大小。整块 copy2 一个 250 MB 的缓存时会把界面「定住」
#: 好几秒（Houdini 看起来像死了），分块 + 回调就能边复制边刷进度条。
_CHUNK = 1024 * 1024 * 2


class CopyReport(object):
    def __init__(self):
        self.copied = 0
        self.skipped = 0
        self.failed = []
        self.bytes = 0
        self.canceled = False

    def __repr__(self):
        return "<CopyReport 复制 %d / 跳过 %d / 失败 %d>" % (
            self.copied, self.skipped, len(self.failed))


def ensure_dir(path):
    if path:
        os.makedirs(path, exist_ok=True)


def copy_one(src, dst, overwrite=True, chunk_cb=None):
    """复制一个文件，返回复制的字节数。

    chunk_cb(已复制字节数) 给了就分块复制并逐块回调（界面好刷进度、不卡），
    不给就整块 copy2（快一点，适合脚本里用）。
    """
    ensure_dir(os.path.dirname(dst))
    if os.path.exists(dst):
        if not overwrite:
            return 0
        try:
            if (os.path.getsize(src) == os.path.getsize(dst)
                    and abs(os.path.getmtime(src) - os.path.getmtime(dst)) < 1):
                return 0                                   # 一样，不用再复制
        except Exception:                                  # noqa: BLE001
            pass
    if chunk_cb is None:
        shutil.copy2(src, dst)
    else:
        done = 0
        with open(src, "rb") as fsrc:
            with open(dst, "wb") as fdst:
                while True:
                    buf = fsrc.read(_CHUNK)
                    if not buf:
                        break
                    fdst.write(buf)
                    done += len(buf)
                    chunk_cb(done)
        try:
            shutil.copystat(src, dst)                      # 时间/属性照抄
        except Exception:                                  # noqa: BLE001
            pass
    try:
        return os.path.getsize(dst)
    except Exception:                                      # noqa: BLE001
        return 0


def _plan_bytes(tasks):
    """先算一遍总共要搬多少字节（用于按字节刷进度条）。"""
    total = 0
    for task in tasks or []:
        src = task.get("src") or ""
        if not src or not os.path.isfile(src):
            continue
        size = task.get("size") or 0
        if not size:
            try:
                size = os.path.getsize(src)
            except Exception:                              # noqa: BLE001
                size = 0
        total += size
    return total


def copy_all(tasks, on_progress=None, overwrite=True, cancel=None,
             on_bytes=None):
    """按 plan.tasks 批量复制。

    on_progress(done, total, path)   每复制一个文件报一次
    on_bytes(done_bytes, total_bytes) 按字节报（大文件也能看着进度走）
    cancel()                         返回 True 就中断
    """
    report = CopyReport()
    total = len(tasks or [])
    total_bytes = _plan_bytes(tasks) if on_bytes else 0
    for index, task in enumerate(tasks or []):
        if cancel is not None and cancel():
            report.canceled = True
            break
        src, dst = task["src"], task["dst"]
        if on_progress is not None:
            on_progress(index, total, src)
        if not os.path.isfile(src):
            report.skipped += 1
            continue
        base = report.bytes
        if on_bytes is not None:
            def _chunk(n, _base=base):
                on_bytes(_base + n, total_bytes)
            cb = _chunk
        else:
            cb = None
        try:
            report.bytes = base + copy_one(src, dst, overwrite, chunk_cb=cb)
            report.copied += 1
        except Exception as exc:                           # noqa: BLE001
            report.failed.append((src, dst, str(exc)))
        if on_bytes is not None:
            on_bytes(report.bytes, total_bytes)
    if on_progress is not None:
        on_progress(total, total, "")
    if on_bytes is not None:
        on_bytes(report.bytes, total_bytes)
    return report


def copy_hip(hip_src, hip_dst):
    """把工程文件本身复制进包里。"""
    if not hip_src or not os.path.isfile(hip_src):
        return False
    ensure_dir(os.path.dirname(hip_dst))
    shutil.copy2(hip_src, hip_dst)
    return True


def make_zip(pack_dir, zip_path, on_progress=None):
    """把整个包压成 zip。"""
    pack_dir = os.path.normpath(pack_dir)
    ensure_dir(os.path.dirname(zip_path))
    if os.path.exists(zip_path):
        os.remove(zip_path)
    files = []
    for root, _dirs, names in os.walk(pack_dir):
        for name in names:
            full = os.path.join(root, name)
            files.append(full)
    total = len(files)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for i, full in enumerate(files):
            if on_progress is not None:
                on_progress(i, total, full)
            zf.write(full, os.path.relpath(full, pack_dir))
    return zip_path


def remove_dir(path):
    """删掉中间目录（打完 zip 之后用）。"""
    try:
        shutil.rmtree(path)
        return True
    except Exception:                                      # noqa: BLE001
        return False


def open_in_explorer(path):
    """在资源管理器里打开（Windows）。"""
    try:
        if os.path.isdir(path):
            os.startfile(path)                             # noqa: S606
        elif os.path.isfile(path):
            os.startfile(os.path.dirname(path))            # noqa: S606
        return True
    except Exception:                                      # noqa: BLE001
        return False


__all__ = ["CopyReport", "copy_all", "copy_one", "copy_hip", "make_zip",
           "remove_dir", "open_in_explorer", "ensure_dir"]
