# -*- coding: utf-8 -*-
"""规划：算出「每个文件该复制到包里的哪个位置」。

只做计算，不碰磁盘、不依赖 hou，所以可以单独测试：

    from hip_packer import plan
    p = plan.make_plan(files, options, hip_path)
    for t in p.tasks:
        print(t["src"], "->", t["dst"])

素材怎么放
----------
* **默认没有 assets 这一层**：素材目录直接落在工程旁边（`包/xxx.hip` + `包/geo/…`），
  跟平时自己在工程目录里干活的习惯一致。想统一收进一个子目录，
  在界面「素材根目录」里填个名字就行（填 assets 就回到老样子）。
* **工程内**的素材：本来就有目录结构，原样照搬（$HIP/geo/... 还放 geo/...）。
* **工程外**的素材：没有「原来的结构」可言，按类型归类到子目录 ——
  贴图/图片进 `image/`、几何缓存进 `cache/`、视频进 `mov/`、音频进 `audio/`，
  认不出来的进 `misc/`。（规则在 classify.pack_subdir()，改那里就行。）
  这样跨盘引用不会在包里长出 D:\\cache\\… 那种又深又没用的路径。
* **HDA / OTL**：不管工程内还是工程外，一律平铺进**工程根**下的 `otls/`。
  Houdini 默认会扫 `$HIP/otls`，再配合工程里那段「打开时自动加载」的脚本
  （见 rewrite.OTL_LOADER_SOURCE），换机器打开就不会出现坏节点。

难点是重名：两个 filecache 都输出 cache.bgeo.sc，放进同一个子目录就撞了，
所以这里统一安排目标路径 + 冲突后缀（cache_1.bgeo.sc），并把对应关系记进
mapping —— 后面改写工程参数和写 manifest 都靠它。
"""

import os
import re

try:                                   # 正常当包用
    from . import classify
except (ImportError, ValueError):      # 被当脚本直接跑时没有包上下文
    import importlib.util

    _spec = importlib.util.spec_from_file_location(
        "hip_packer_classify",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "classify.py"))
    classify = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(classify)

#: 布局策略（跟界面上「素材在包里怎么放」三个选项一一对应）
KEEP_INSIDE_FLATTEN_OUTSIDE = 0     # 工程内保留结构，工程外按类型分子目录（默认）
FLATTEN_ALL = 1                     # 全部平铺
KEEP_ALL = 2                        # 全部保留原始完整路径

_ILLEGAL = re.compile(r'[<>:"|?*\x00-\x1f]')


class PackPlan(object):
    """一次打包的完整安排。"""

    def __init__(self):
        self.pack_dir = ""
        self.assets_dir = ""     # 素材往哪放；没设 assets_root 时 == pack_dir
        self.assets_root = ""    # 素材子目录名（空 = 不用子目录，直接放工程旁边）
        self.otls_dir = ""       # 工程根下的 otls/（HDA / OTL 专用）
        self.hip_src = ""
        self.hip_dst = ""
        self.tasks = []          # [{"src","dst","size","group","ext","refs",...}]
        self.mapping = {}        # 原绝对路径 -> 包内绝对路径
        self.rel_mapping = {}    # 原绝对路径 -> 写进工程参数的值（$HIP/...）
        self.conflicts = []      # 被改名过的文件，写进 manifest 备查
        self.total_bytes = 0

    @property
    def file_count(self):
        return len(self.tasks)

    @property
    def otl_count(self):
        """包里带了多少个 HDA / OTL（决定要不要往工程里加自动加载脚本）。"""
        return sum(1 for t in self.tasks if t.get("in_otls"))

    def __repr__(self):
        return "<PackPlan %d 文件 / %s>" % (len(self.tasks),
                                            _human(self.total_bytes))


def _human(num):
    size = float(num or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024.0 or unit == "TB":
            return "%.1f %s" % (size, unit) if unit != "B" else "%d B" % size
        size /= 1024.0


def _safe_name(name):
    return _ILLEGAL.sub("_", name).strip() or "unnamed"


def _inside_hip(path, hip_dir):
    """这个文件是不是在工程目录里面。"""
    if not hip_dir:
        return False
    try:
        a = os.path.normcase(os.path.abspath(path))
        b = os.path.normcase(os.path.abspath(hip_dir))
    except Exception:                                      # noqa: BLE001
        return False
    return a == b or a.startswith(b + os.sep)


def _drive_prefix(path):
    """跨盘/UNC 路径转成安全的目录名：D:\\a -> D/a，//server/share -> server_share。"""
    drive, rest = os.path.splitdrive(os.path.normpath(path))
    parts = []
    if drive:
        parts.append(drive.rstrip(":\\/").replace(":", "") or "drive")
    elif rest.startswith("\\\\"):
        rest = rest.lstrip("\\")
    for p in rest.replace("\\", "/").split("/"):
        if p and p != ":":
            parts.append(_safe_name(p))
    return "/".join(parts)


def _target_rel(src, hip_dir, policy, group=None, ext=None):
    """算出素材在 assets 目录里放哪：返回相对路径（用 / 分隔）。

    工程内（在 $HIP 下面）的文件才有「目录结构」可言；工程外的按类型归类。
    """
    name = os.path.basename(src)
    if policy == KEEP_ALL:
        return _drive_prefix(src)
    if policy == FLATTEN_ALL:
        return name
    # KEEP_INSIDE_FLATTEN_OUTSIDE：工程内的照搬结构，工程外的按类型分子目录
    if _inside_hip(src, hip_dir):
        try:
            rel = os.path.relpath(src, hip_dir)
        except Exception:                                  # noqa: BLE001
            rel = name
        return rel.replace("\\", "/")
    return classify.pack_subdir(src, group=group, ext=ext) + "/" + name


def _dedupe(dst, used, seq_suffix, seq_key):
    """目标路径撞了就加 _1 / _2。同一段序列共用同一个后缀，别改得参差不齐。"""
    directory, name = os.path.split(dst)
    m = classify._NUM_RE.match(name)
    if m and seq_key is not None:
        # 序列：编号夹在中间（cache.1001.bgeo.sc），所以按 base / sep / num / ext 拆开拼
        if seq_key not in seq_suffix:
            n = 1
            while True:
                cand = os.path.join(directory, "%s_%d%s%s%s" % (
                    m.group("base"), n, m.group("sep"),
                    m.group("num"), m.group("ext")))
                if cand not in used:
                    break
                n += 1
            seq_suffix[seq_key] = n
        n = seq_suffix[seq_key]
        return os.path.join(directory, "%s_%d%s%s%s" % (
            m.group("base"), n, m.group("sep"), m.group("num"), m.group("ext")))

    # 双后缀（.bgeo.sc）要整体当后缀，不然会变成 cache.bgeo_1.sc
    ext = classify.norm_ext(name)
    base = name[:len(name) - len(ext)] if ext else name
    n = 1
    while True:
        cand = os.path.join(directory, "%s_%d%s" % (base, n, ext))
        if cand not in used:
            return cand
        n += 1


def make_plan(files, options, hip_path):
    """算出整个包的安排。

    files:   scan 的依赖列表，或界面 selected_dependencies() 的结果
    options: 界面 collect_options() 的结果
    hip_path: 当前工程文件路径
    """
    output_dir = (options.get("output_dir") or "").strip()
    pack_name = (options.get("pack_name") or "").strip()
    if not pack_name:
        pack_name = os.path.splitext(os.path.basename(hip_path or "pack"))[0] or "pack"
    # 留空 = 素材直接放在工程旁边（用户的默认要求：不要多一层 assets/）
    assets_root = (options.get("assets_root") or "").strip().strip("\\/")
    policy = options.get("layout_policy", KEEP_INSIDE_FLATTEN_OUTSIDE)

    plan = PackPlan()
    plan.assets_root = assets_root
    plan.pack_dir = os.path.normpath(os.path.join(output_dir, pack_name))
    plan.assets_dir = (os.path.join(plan.pack_dir, assets_root) if assets_root
                       else plan.pack_dir)
    plan.otls_dir = os.path.join(plan.pack_dir, classify.OTL_DIRNAME)
    plan.hip_src = hip_path or ""
    if plan.hip_src:
        plan.hip_dst = os.path.join(plan.pack_dir,
                                    os.path.basename(plan.hip_src))
    hip_dir = os.path.dirname(hip_path) if hip_path else ""

    used = set()
    seq_suffix = {}
    for item in files or []:
        src = os.path.normpath(str(item.get("path") or ""))
        if not src:
            continue
        group = item.get("group") or ""
        ext = item.get("ext") or ""
        # HDA / OTL 一律平铺进工程根下的 otls/（不走 assets）
        in_otls = classify.is_otl(src)
        if in_otls:
            dst = os.path.normpath(os.path.join(plan.otls_dir,
                                                os.path.basename(src)))
            rel_dir = classify.OTL_DIRNAME
        else:
            rel_dir = _target_rel(src, hip_dir, policy, group=group, ext=ext)
            dst = os.path.normpath(os.path.join(plan.assets_dir,
                                                rel_dir.replace("/", os.sep)))
        seq_key = classify.seq_key(src) if item.get("is_sequence") else None
        if dst in used:
            dst = _dedupe(dst, used, seq_suffix, seq_key)
        used.add(dst)

        size = item.get("size") or 0
        if os.path.isfile(src) and not size:
            try:
                size = os.path.getsize(src)
            except Exception:                              # noqa: BLE001
                size = 0

        plan.tasks.append({
            "src": src,
            "dst": dst,
            "size": size,
            "group": group,
            "ext": ext,
            "is_sequence": bool(item.get("is_sequence")),
            "missing": bool(item.get("missing")) or not os.path.isfile(src),
            "refs": list(item.get("refs") or []),
            "in_otls": in_otls,
        })
        plan.total_bytes += size
        plan.mapping[src] = dst
        # 只有真的因为撞名改过名字的才算（换目录不算）
        if os.path.basename(dst) != os.path.basename(src):
            plan.conflicts.append((src, dst))

    # 写进工程参数的值：$HIP 开头，换机器也能开
    for src, dst in plan.mapping.items():
        try:
            rel = os.path.relpath(dst, plan.pack_dir).replace("\\", "/")
        except Exception:                                  # noqa: BLE001
            rel = os.path.basename(dst)
        plan.rel_mapping[src] = "$HIP/" + rel
    return plan


__all__ = ["PackPlan", "make_plan",
           "KEEP_INSIDE_FLATTEN_OUTSIDE", "FLATTEN_ALL", "KEEP_ALL"]
