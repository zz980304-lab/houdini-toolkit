# -*- coding: utf-8 -*-
"""开发用：把界面渲染成 PNG，不需要打开 Houdini。

借用 Houdini 自带 Python 与它自带的 PySide2，配合原生平台 + WA_DontShowOnScreen
（窗口不弹出来，但字体正常，见下面「坑」）。

用法（Git Bash，<HFS> 换成你的 Houdini 安装目录）：
    HFS="<HFS>"
    PYTHONPATH="<HFS>/python311/Lib/site-packages-forced;<本工具目录>"
    "<HFS>/python311/python.exe" -m hip_packer._preview 输出.png

    只渲染某一个 Tab：末位再加个 0/1/2。
    不带参数时在当前目录生成 hip_packer_ui_tab0/1/2.png。

坑：QT_QPA_PLATFORM=offscreen 在 Windows 上没有字体库，渲出来一个字都没有，
    所以这里默认走原生平台 + WA_DontShowOnScreen。
"""

import os
import sys

# 预览用的假数据，纯占位，不含任何真实盘符。
# 不写 category，让界面用 classify.py 自己归类 —— 顺便验证分类逻辑。
DEMO_HIP = "//studio/projects/cf_shot/sh050/fx/sh050_fx_v012.hip"


def _seq(directory, base, ext, start, end, each_size, refs, missing=()):
    """造一段序列（预览里会被合并成清单的一行）。"""
    out = []
    for frame in range(start, end + 1):
        out.append(dict(
            path="%s/%s.%04d.%s" % (directory, base, frame, ext),
            size=0 if frame in missing else each_size,
            refs=[refs],
            status="缺失" if frame in missing else "找到",
        ))
    return out


DEMO_DEPS = []
# —— 用户举的重名场景：两个 filecache 都输出 $OS/cache.bgeo.sc ——
DEMO_DEPS += _seq("$HIP/geo/filecache1", "cache", "bgeo.sc", 1001, 1240,
                  2831155, "/obj/geo1/filecache1")
DEMO_DEPS += _seq("$HIP/geo/filecache2", "cache", "bgeo.sc", 1001, 1240,
                  1048576, "/obj/geo2/filecache2", missing=(1180,))
# —— 各种几何格式分开列 ——
DEMO_DEPS += [
    dict(path="$HIP/geo/sh050_fx_v012.bgeo.sc", size=178257920,
         refs=["/obj/fx_sim/out_cache1"], status="找到"),
    dict(path="//studio/ref/character/hero_rig_v06.abc", size=125829120,
         refs=["/obj/ref_geo/alembic1", "/obj/ref_geo/alembic2"], status="找到"),
    dict(path="$JOB/cache/sh050/sh050_vel_v010.vdb", size=268435456,
         refs=["/obj/pyro/import_vel1"], status="找到"),
    dict(path="$JOB/usd/sh050_layout.usd", size=4194304,
         refs=["/stage/asset_import1"], status="找到"),
    # —— 贴图：各种格式单独列 ——
    dict(path="$JOB/tex/wood_diff_4k.exr", size=51380224,
         refs=["/mat/redshift/wood/tex0"], status="找到"),
    dict(path="$JOB/tex/studio_env_4k.hdr", size=67108864,
         refs=["/obj/env_light1"], status="找到"),
    dict(path="$JOB/tex/metal_norm_2k.png", size=8388608,
         refs=["/mat/mantra/metal/normalmap"], status="找到"),
    dict(path="$HIP/tex/logo_alpha.jpg", size=131072,
         refs=["/img/comp1/file1"], status="缺失"),
    dict(path="$JOB/tex/grunge.rat", size=20971520,
         refs=["/mat/mantra/grunge/map"], status="找到"),
    dict(path="$JOB/tex/wood_diff_4k.tx", size=15728640,
         refs=["/mat/arnold/wood/tex0"], status="找到"),
    # —— HDA ——
    dict(path="$HOUDINI_PATH/otls/fx_utils.hda", size=786432,
         refs=["/obj/fx_sim/fx_blast1"], status="找到"),
    dict(path="$HIP/../assets/cf_shot_tools.hdanc", size=1310720,
         refs=["/obj/geo1/cf_scatter1"], status="找到"),
    # —— 参考与其它：音频 / fbx / obj ——
    dict(path="$HIP/audio/sh050_hit_01.wav", size=3145728,
         refs=["/obj/audio/chopnet1"], status="找到"),
    dict(path="//studio/ref/props/barrel_01.fbx", size=5242880,
         refs=["/obj/ref_geo/file1"], status="找到"),
    dict(path="//studio/ref/props/crate_02.obj", size=2097152,
         refs=["/obj/ref_geo/file2"], status="找到"),
    # —— 插件自己的格式，认不出来 ——
    dict(path="$JOB/sim/sh050_kraken_v003.simcache", size=94371840,
         refs=["/obj/kraken_solver1"], status="找到"),
    dict(path="$HIP/lut/custom_tone.cube", size=524288,
         refs=["/img/comp1/lut1"], status="找到"),
]
# —— 渲染输出：图片序列 + 视频 ——
DEMO_DEPS += _seq("$HIP/render/sh050/beauty", "sh050_beauty", "exr", 1001, 1240,
                  12582912, "/out/arnold1")
DEMO_DEPS += [
    dict(path="$HIP/render/sh050/sh050_preview_v03.mov", size=314572800,
         refs=["/out/ffmpeg1"], status="找到"),
]


def _hfs():
    from ._env import find_hfs
    return find_hfs()


def _setup_env():
    """在创建 QApplication 之前调用：告诉 Qt 去哪找平台插件。

    默认走原生平台 + WA_DontShowOnScreen（窗口不真的弹出来，字体正常）。
    offscreen 平台在 Windows 上没有字体库，渲染出来会一个字都没有，
    所以只在显式设置 HIP_PACKER_PREVIEW_OFFSCREEN=1 时用。
    """
    from ._env import ensure_dll_dir
    hfs = ensure_dll_dir()
    if not hfs:
        return None
    os.environ.setdefault("QT_PLUGIN_PATH", os.path.join(hfs, "bin", "Qt_plugins"))
    if os.environ.get("HIP_PACKER_PREVIEW_OFFSCREEN") == "1":
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    return hfs


def _pick_font():
    """挑一个带中文的字体，免得中文渲染成方框。"""
    from .qt import QtGui
    try:
        families = set(QtGui.QFontDatabase.families())
    except Exception:                                                # noqa: BLE001
        return None
    for name in ("Microsoft YaHei UI", "Microsoft YaHei", "PingFang SC",
                 "Noto Sans CJK SC", "Source Han Sans SC", "Segoe UI"):
        if name in families:
            font = QtGui.QFont(name)
            font.setPointSize(9)
            return font
    return None


def _apply_dark(app):
    """模拟 Houdini 的深色主题，方便看配色和层次。"""
    from .qt import QtGui, enum_of
    app.setStyle("Fusion")
    pal = QtGui.QPalette()
    for role, color in (
        ("Window", "#3a3a3a"), ("WindowText", "#e6e6e6"),
        ("Base", "#2e2e2e"), ("AlternateBase", "#343434"),
        ("ToolTipBase", "#2e2e2e"), ("ToolTipText", "#e6e6e6"),
        ("Text", "#e6e6e6"), ("Button", "#3f3f3f"), ("ButtonText", "#e6e6e6"),
        ("BrightText", "#ff6b6b"), ("Link", "#5ba7e8"),
        ("Highlight", "#4a80c8"), ("HighlightedText", "#ffffff"),
        ("PlaceholderText", "#8a8a8a"),
    ):
        try:
            pal.setColor(enum_of(QtGui.QPalette, role), QtGui.QColor(color))
        except Exception:                                            # noqa: BLE001
            pass
    app.setPalette(pal)


def _fill_demo(win):
    win.set_hip_info(path=DEMO_HIP, size=19588710, mtime="2026-10-15 17:32",
                     modified=True, version="20.5.401")
    win.set_dependencies(DEMO_DEPS)
    win.output_dir_edit.setText("//studio/publish/sh050/pack")
    win.set_status("界面预览（Qt %s）—— 功能还没接" % _binding())
    win.set_progress(0)


def _binding():
    from .qt import BINDING
    return BINDING


def render(out_path, tab=None):
    _setup_env()
    from .qt import QtWidgets, Qt, enum_of
    from .ui import HipPackerWindow

    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv)
    _apply_dark(app)
    font = _pick_font()
    if font is not None:
        app.setFont(font)

    win = HipPackerWindow()
    _fill_demo(win)
    win.resize(1240, 720)
    # 让控件完成布局与绘制，但不真的显示到屏幕上
    try:
        win.setAttribute(enum_of(Qt, "WA_DontShowOnScreen"), True)
    except Exception:                                                # noqa: BLE001
        pass
    win.show()
    for _ in range(4):
        app.processEvents()

    tabs = win.findChild(QtWidgets.QTabWidget)
    indices = [tab] if tab is not None else list(range(tabs.count()))
    saved = []
    for idx in indices:
        tabs.setCurrentIndex(idx)
        app.processEvents()
        path = out_path if len(indices) == 1 else _with_suffix(out_path, "_tab%d" % idx)
        win.grab().save(path)
        saved.append(path)
    return saved


def _with_suffix(path, suffix):
    base, ext = os.path.splitext(path)
    return base + suffix + (ext or ".png")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    out = argv[0] if argv else os.path.join(os.getcwd(), "hip_packer_ui.png")
    tab = int(argv[1]) if len(argv) > 1 else None
    for path in render(out, tab):
        print("[preview] %s  ->  %s  (Qt: %s)" % (_hfs(), path, _binding()))
    return 0


if __name__ == "__main__":
    sys.exit(main())
