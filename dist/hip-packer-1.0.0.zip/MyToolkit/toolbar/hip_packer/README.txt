工程保存工具（hip_packer）
==========================

功能：把当前 Houdini 工程连同它引用的素材一起打包带走，
       可选把工程里的路径改写成相对 $HIP 的写法（换机器 / 换盘直接能开）。
       挂在工具架「我的工具」里，按钮名就是「工程保存工具」。

这个目录是自包含的：整个复制到别的机器 / 别的盘都能直接用，
里面不写任何绝对路径，靠 HOUDINI_PATH 相对定位。

------------------------------------------------------------
目录
------------------------------------------------------------
  hip_packer/
    classify.py    素材分类 + 文件序列识别（纯逻辑，不依赖 Qt / hou）
    scan.py        扫描工程里的文件引用（**只读**，需要 hou）
    plan.py        算包内结构、处理重名（纯计算，可单测）
    transfer.py    复制 / 压缩 / 删目录 / 打开资源管理器（纯 IO）
    rewrite.py     改写包内工程副本的路径（跑在 **hython 子进程** 里）
    manifest.py    生成 manifest.json（机器读）和 README.txt（人读）
    qt.py          Qt 绑定兼容层（PySide2 / PySide6 / hutil.Qt）
    ui.py          界面（**不 import hou**）
    controller.py  把上面这些接到界面上
  README.txt       本文件（怎么用）
  代码说明书.md     **改代码前必读**：每个文件/每段代码干嘛的、改了要更新它

------------------------------------------------------------
要改代码？先看这里
------------------------------------------------------------
  1. 打开「代码说明书.md」，找到你要改的那个模块那一节
  2. 改代码（一次只改一类事）
  3. 改完跑说明书第 8 节的验证
  4. **回头把「代码说明书.md」对应章节 + 文末变更记录更新掉**

------------------------------------------------------------
怎么用
------------------------------------------------------------
  Houdini 工具架 →「我的工具」→「工程保存工具」，或 Python Shell：

      import os, sys
      for _d in os.environ.get("HOUDINI_PATH", "").split(os.pathsep):
          _c = os.path.join(_d, "toolbar", "hip_packer")
          if os.path.isdir(os.path.join(_c, "hip_packer")):
              sys.path.append(_c); break
      from hip_packer import show
      show()

  界面上四步：
    1. 确认「当前工程」（没保存过就先保存）
    2. 点「扫描依赖」→ 右边列出工程引用的所有素材
    3. 左边勾要带走的格式，右边可以再逐个挑
    4. 填「输出到」和「包名」→ 点「开始打包」

  产出（素材和工程文件平级，**没有 assets 这一层**，2026-10-16 改）：
    包名/
      xxx.hip              工程副本（路径已改写的话是 $HIP/... 相对写法）
      otls/                工程用到的 HDA / OTL（Houdini 默认会扫这里）
      geo/  cache/  image/  mov/  audio/  misc/     素材
        （工程内的素材保留原来的目录结构；工程外的按类型归类到上面这些子目录）
      manifest.json        完整依赖清单：原路径 / 包内路径 / 引用节点
      README.txt           人看的说明

    想让素材统一收进一个子目录（比如回到老的 assets/ 样子），
    在「输出设置 → 素材根目录」里填个名字就行；留空 = 现在这种同层结构。

  打包过程（2026-10-16 改）：
    会弹一个进度框显示当前在干嘛（算结构 / 复制素材 / 改包内工程 / 压缩），
    复制的是「已复制的 MB / 总共多少 MB」，随时可以按「取消」。
    打包期间 Houdini 可以正常用（改写工程那一步是后台 hython 子进程，
    不会再弹出命令行窗口）。完成后会弹一个提示框，上面有
    「打开输出目录」按钮，点一下就能看结果。

  HDA / OTL 怎么加载（2026-10-15 加）
    Houdini 默认就会扫 $HIP/otls，所以正常打开工程就会自动加载。
    另外打包时还能往工程里写一段「打开时自动执行」的 python
    （界面「输出设置 → 其它」里那个勾，默认开），它会再把 otls/ 下的
    文件装一遍。为什么需要它：万一对方机器自定义过 HOUDINI_OTLSCAN_PATH
    （渲染农场很常见）又没带 &，默认扫描路径就没了，工程打开会报
    incomplete asset definitions。实测：装了这段脚本，那种环境下也能干净打开。

------------------------------------------------------------
功能层怎么单独调用（不通过界面）
------------------------------------------------------------
  from hip_packer import scan, plan, transfer, rewrite, manifest

  res = scan.scan_project()                 # 扫描
  files = res.files                         # 依赖列表
  res.parm_refs                             # 参数级引用（改写路径要用）

  options = {"output_dir": "D:/out", "pack_name": "shot050",
             "assets_root": "", "layout_policy": 0,      # 空 = 素材和工程同层
             "rewrite_paths": True, "otl_loader": True,
             "zip": False, "open_after": False}
  p = plan.make_plan(files, options, hou.hipFile.path())
  transfer.copy_hip(p.hip_src, p.hip_dst)
  transfer.copy_all(p.tasks)
  rmap = rewrite.build_rewrite_map(res.parm_refs, p)
  rewrite.launch(p.hip_dst, rmap, otl_loader=p.otl_count > 0)
  manifest.write_manifest(p, p.pack_dir + "/manifest.json")
  manifest.write_readme(p, p.pack_dir + "/README.txt")

  # 想让界面不卡死 / 能按取消，加两个回调（界面就是这么调的）：
  transfer.copy_all(p.tasks, on_bytes=lambda d, t: print(d, t),
                    cancel=lambda: False)
  rewrite.launch(p.hip_dst, rmap, on_poll=lambda: None,
                 cancel=lambda: False)

------------------------------------------------------------
几个关键设计（改代码前先看，不然容易踩回去）
------------------------------------------------------------
1. **$F 不能让 Houdini 展开**。直接用 expandString，cache.$F4.bgeo.sc 会变成
   cache.0001.bgeo.sc（当前帧），磁盘上没这一帧就多出一条假的「缺失」。
   现在的做法：按 $F 把字符串切成几段分别展开，再把 $F4 原样拼回去。

2. **序列判定看「同目录连号 >= 2」**，不看单个文件名。
   否则 hero_rig_v06.abc、barrel_01.fbx、sh050_vel_v010.vdb 会被当成序列。

3. **没被改过的默认参数 + 磁盘上也找不到** → 跳过。
   Houdini 自带参数（比如 OBJ 上那个 $OS.$F.vdb）会混进来当噪音。

4. **改写路径在 hython 子进程里做**。改写要 hou.hipFile.load()，那会换掉当前
   会话；在用户正用的 Houdini 里直接跑等于把人场景清空。

5. **映射表建立在「参数原文」上**：(节点, 参数) -> 新值($HIP/assets/...)，
   序列会把帧号还原成 $F4，不然 240 帧会被写死成第一帧。

6. 打包用的是**磁盘上已保存的 .hip**，不用内存里的会话，所以不会碰你的场景。
   有未保存修改时会弹一下让你选。

7. **工程外的素材按类型分子目录**，不照搬原路径（2026-10-15 改）。
   贴图/图片进 image/、几何缓存进 cache/、视频进 mov/、音频进 audio/、其它进 misc/。
   规则在 `classify.py` 的 `pack_subdir()`（改它就换归类）。
   工程内的素材不受影响，还是保留原来的目录结构。

8. **HDA / OTL 一律进工程根下的 otls/**，不管它原来在哪个盘、是不是工程内的。
   这是 Houdini 的默认扫描目录，配合内嵌脚本就是双保险。
   "自己攒的 otl、第三方插件的 hda、用户目录 otls" 会算进来，
   装在 $HFS 下面的 Houdini 自带 HDA 会被排除（换机器也一定有）。
   来源是 `scan.hda_sources()`（问的是 node.type().definition().libraryFilePath()）。

9. **别把「打开时执行」的脚本写坏**。它存在 .hip 里，用
   `hou.appendSessionModuleSource()` 写进去，**打开工程时会真的执行**，
   语法错了会直接抛 hou.OperationFailed（写成一行行 join，别用字符串拼 \n）。

------------------------------------------------------------
开发用
------------------------------------------------------------
  把界面渲成 PNG（不用开 Houdini）：
    HFS="E:/Houdini20.5.401" \
    PYTHONPATH="<HFS>/python311/Lib/site-packages-forced;<本目录>" \
    "<HFS>/python311/python.exe" -m hip_packer._preview 输出.png

  离线跑完整流程（headless，不碰任何 Houdini 会话）：
    "<HFS>/bin/hython.exe" <脚本>       # 见 F:\WorkBuddy\Claw\.workbuddy\hython_pack_test.py

------------------------------------------------------------
.shelf 中文编码铁律（改 My_Tool.shelf 前务必看）
------------------------------------------------------------
Houdini 读 .shelf 里的文字（label 和 CDATA 里的脚本内容都算）时，
会把内容当成「latin-1 写下来的 UTF-8 字节」再解一次：

  * 声明 UTF-8 + 正常中文        -> Houdini 里中文**整个消失**
  * 声明 UTF-8 + 双重编码的乱码  -> Houdini 显示正常，但文件是乱码（原来是这种）
  * 声明 ISO-8859-1 + 正常中文   -> **两边都正常**（现在用的方案）

所以：保持 My_Tool.shelf 现在的写法，别把声明改回 UTF-8，
也别用记事本「另存为」（会加 BOM 或转 ANSI，中文又会没）。

------------------------------------------------------------
双击依赖清单里的素材（2026-10-16 已做）
------------------------------------------------------------
  单处引用 → 直接在当前网络里选中并居中；多处引用 → 弹一个小窗列出节点，
  双击哪个跳哪个。跳转是只读操作，不改你的工程。
